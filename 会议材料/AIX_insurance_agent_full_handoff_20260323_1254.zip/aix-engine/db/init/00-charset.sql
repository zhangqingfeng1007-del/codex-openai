-- Force UTF-8 for all init scripts
ALTER DATABASE aix_engine CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
SET NAMES utf8mb4;
