-- ============================================================
-- AIX保险智能测算引擎 - 种子数据插入
-- 此脚本将 JSON 配置文件内容导入 MySQL
-- ============================================================

SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

USE aix_engine;

-- ============================================================
-- admin_config 表：按 section_key 分节插入
-- ============================================================

INSERT INTO admin_config (section_key, config_data, description) VALUES
('scenarioParams', '{
  "pessimistic": {"wageGrowthRate": 0.01, "inflationRate": 0.04, "returnRate": 0.02},
  "neutral": {"wageGrowthRate": 0.03, "inflationRate": 0.03, "returnRate": 0.03},
  "optimistic": {"wageGrowthRate": 0.05, "inflationRate": 0.015, "returnRate": 0.08}
}', '三情景参数（悲观/中性/乐观）'),

('actuarialParams', '{
  "employeeAccountInterestRate": 0.0397,
  "baseLifeExpectancy": {"male": 76, "female": 80},
  "healthLifespanAdjustmentYears": {"good": 3, "average": 0, "poor": -3},
  "healthMortalityAdjustment": {"good": -0.15, "average": 0, "poor": 0.3},
  "monteCarloReturnStdDev": 0.08,
  "monteCarloInflationStdDev": 0.02
}', '精算参数'),

('financialScoringRules', '{
  "weights": {"surplusRatio": 0.30, "debtRatio": 0.25, "assetAdequacy": 0.25, "ssLevel": 0.20},
  "thresholds": {"surplusRatioExcellent": 0.3, "surplusRatioPoor": 0.0, "debtRatioSafe": 0.3, "debtRatioDanger": 0.5, "assetAdequacyMonths": 6, "gradeHigh": 80, "gradeMedium": 60, "gradeLow": 40}
}', '财务评分规则与权重'),

('educationSavingsRate', '{"conservative": 0.03, "aggressive": 0.05}', '教育储蓄收益率'),

('educationInflation', '{"domestic": 0.05, "overseas": 0.03}', '教育通胀率'),

('exchangeRates', '{
  "USD": 7.25, "GBP": 9.20, "AUD": 4.80, "CAD": 5.35,
  "SGD": 5.40, "HKD": 0.93, "JPY": 0.048, "EUR": 7.90,
  "THB": 0.20, "CHF": 8.10
}', '汇率表'),

('retirementExpenseDefaults', '{
  "tier1": {
    "low":  {"monthlyLiving": 5000, "otherAnnual": 10000, "activeMonthlyResidence": 3000, "semiCareMonthlyNursing": 8000, "fullCareMonthlyNursing": 15000},
    "mid":  {"monthlyLiving": 8000, "otherAnnual": 30000, "activeMonthlyResidence": 5000, "semiCareMonthlyNursing": 12000, "fullCareMonthlyNursing": 22000},
    "high": {"monthlyLiving": 15000, "otherAnnual": 80000, "activeMonthlyResidence": 10000, "semiCareMonthlyNursing": 20000, "fullCareMonthlyNursing": 35000}
  },
  "tier2": {
    "low":  {"monthlyLiving": 3500, "otherAnnual": 8000, "activeMonthlyResidence": 2000, "semiCareMonthlyNursing": 6000, "fullCareMonthlyNursing": 10000},
    "mid":  {"monthlyLiving": 6000, "otherAnnual": 20000, "activeMonthlyResidence": 3500, "semiCareMonthlyNursing": 9000, "fullCareMonthlyNursing": 16000},
    "high": {"monthlyLiving": 10000, "otherAnnual": 50000, "activeMonthlyResidence": 7000, "semiCareMonthlyNursing": 15000, "fullCareMonthlyNursing": 25000}
  },
  "tier3": {
    "low":  {"monthlyLiving": 2500, "otherAnnual": 5000, "activeMonthlyResidence": 1500, "semiCareMonthlyNursing": 4000, "fullCareMonthlyNursing": 7000},
    "mid":  {"monthlyLiving": 4000, "otherAnnual": 12000, "activeMonthlyResidence": 2500, "semiCareMonthlyNursing": 6000, "fullCareMonthlyNursing": 10000},
    "high": {"monthlyLiving": 7000, "otherAnnual": 30000, "activeMonthlyResidence": 5000, "semiCareMonthlyNursing": 10000, "fullCareMonthlyNursing": 18000}
  }
}', '养老支出默认值矩阵（城市等级×消费层级）'),

('medicalCostData', '{
  "criticalIllness": {"tier1": 500000, "tier2": 400000, "tier3": 300000},
  "dailyIllness": {"tier1": 15000, "tier2": 10000, "tier3": 8000},
  "socialSecurityReimbursement": {"employee": 0.65, "civil_servant": 0.80, "resident": 0.45, "none": 0},
  "hospitalTierCost": {
    "public": {"label": "公立医院", "suggestedCoverage": 1000000},
    "vip": {"label": "特需门诊", "suggestedCoverage": 2000000},
    "private": {"label": "私立医院", "suggestedCoverage": 3000000},
    "international": {"label": "外资昂贵医院", "suggestedCoverage": 5000000}
  }
}', '医疗费用数据（按城市等级和医院类型）'),

('retirementPolicy', '{
  "employeeContributionRate": 0.08,
  "employerContributionRate": 0.16,
  "occupationalAnnuityPersonalRate": 0.04,
  "occupationalAnnuityEmployerRate": 0.08
}', '养老缴费比例'),

('interestCategories', '{
  "categories": [
    {"key":"sports","label":"体育类","description":"游泳、篮球、足球、网球、乒乓球、高尔夫","defaultAnnualCostByTier":{"1":30000,"2":20000,"3":12000}},
    {"key":"arts","label":"艺术类","description":"钢琴、小提琴、美术、舞蹈、声乐","defaultAnnualCostByTier":{"1":30000,"2":20000,"3":12000}},
    {"key":"academic","label":"学科竞赛","description":"数学奥赛、编程、机器人竞赛","defaultAnnualCostByTier":{"1":25000,"2":18000,"3":10000}},
    {"key":"language","label":"语言类","description":"英语外教、小语种、托福/雅思备考","defaultAnnualCostByTier":{"1":30000,"2":22000,"3":14000}},
    {"key":"travel","label":"游学/营地","description":"国内研学、海外夏令营、短期交流项目","defaultAnnualCostByTier":{"1":50000,"2":35000,"3":20000}},
    {"key":"tech","label":"科技/编程","description":"乐高、机器人、Python编程、无人机","defaultAnnualCostByTier":{"1":20000,"2":15000,"3":10000}},
    {"key":"tutoring","label":"学科补习","description":"语数英课外辅导、在线教育平台","defaultAnnualCostByTier":{"1":40000,"2":28000,"3":18000}}
  ]
}', '兴趣培养类目管理');
