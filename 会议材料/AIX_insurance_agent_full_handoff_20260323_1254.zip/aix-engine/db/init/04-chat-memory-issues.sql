-- AIX 对话记忆与问题反馈表
-- v2.1 新增：MemGPT 分层记忆 + 问题反馈

USE aix_engine;

-- ----------------------------
-- L1 核心记忆（绑定客户档案）
-- ----------------------------
CREATE TABLE IF NOT EXISTS chat_memories (
  id VARCHAR(36) NOT NULL DEFAULT (UUID()),
  profile_id VARCHAR(36) NOT NULL COMMENT '关联 profiles.id',
  basic_info JSON COMMENT '基本信息：年龄/性别/职业/城市',
  financial_status JSON COMMENT '财务状况：收入/资产',
  existing_insurance JSON COMMENT '已有保险',
  preferences JSON COMMENT '偏好：关注病种/预算/保障类型',
  purchased_products JSON COMMENT '已购产品',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_memory_profile (profile_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='用户核心记忆（L1）';

-- ----------------------------
-- L2 回溯记忆（对话摘要）
-- ----------------------------
CREATE TABLE IF NOT EXISTS chat_summaries (
  id BIGINT NOT NULL AUTO_INCREMENT,
  profile_id VARCHAR(36) NOT NULL COMMENT '关联 profiles.id',
  summary TEXT NOT NULL COMMENT '本次对话关键摘要',
  recommendation TEXT COMMENT '本次给出的产品建议',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_summary_profile (profile_id),
  KEY idx_summary_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='对话摘要（L2 回溯记忆）';

-- ----------------------------
-- 问题反馈
-- ----------------------------
CREATE TABLE IF NOT EXISTS chat_issues (
  id BIGINT NOT NULL AUTO_INCREMENT,
  profile_id VARCHAR(36) COMMENT '关联 profiles.id，可为空（未建档用户）',
  issue_type VARCHAR(50) NOT NULL COMMENT 'unknown_product | unanswerable_question | data_missing',
  user_query TEXT COMMENT '触发问题的用户原话',
  description TEXT COMMENT 'AI 对问题的描述',
  is_resolved TINYINT(1) NOT NULL DEFAULT 0 COMMENT '0=未处理 1=已处理',
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_issues_type (issue_type),
  KEY idx_issues_resolved (is_resolved),
  KEY idx_issues_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci COMMENT='AI 发现的问题反馈';
