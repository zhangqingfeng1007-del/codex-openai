-- ============================================================
-- AIX保险智能测算引擎 - MySQL 8 完整建表脚本
-- ============================================================

SET NAMES utf8mb4;
SET CHARACTER SET utf8mb4;

USE aix_engine;

-- 1. 客户档案
CREATE TABLE IF NOT EXISTS profiles (
  id VARCHAR(36) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  data JSON NOT NULL COMMENT '会话完整数据',
  INDEX idx_profiles_updated (updated_at DESC)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 2. 会话管理
CREATE TABLE IF NOT EXISTS sessions (
  id VARCHAR(36) PRIMARY KEY,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  scenario ENUM('pessimistic','neutral','optimistic') NOT NULL DEFAULT 'neutral',
  data JSON NOT NULL,
  expires_at DATETIME NOT NULL,
  INDEX idx_sessions_expires (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3. 城市配置
CREATE TABLE IF NOT EXISTS city_config (
  code VARCHAR(32) PRIMARY KEY,
  name VARCHAR(50) NOT NULL,
  tier INT NOT NULL,
  social_avg_wage_monthly DECIMAL(10,2) NOT NULL,
  social_avg_wage_growth_rate DECIMAL(6,4) NOT NULL,
  ss_wage_floor DECIMAL(10,2) NOT NULL,
  ss_wage_ceiling DECIMAL(10,2) NOT NULL,
  resident_basic_pension DECIMAL(10,2) NOT NULL,
  civil_servant_transition_coeff DECIMAL(6,4) NOT NULL,
  monthly_cost DECIMAL(10,2) DEFAULT NULL,
  data_year INT NOT NULL,
  is_estimated BOOLEAN NOT NULL DEFAULT FALSE,
  is_overseas BOOLEAN NOT NULL DEFAULT FALSE,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_city_tier (tier)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4. 管理员配置（按section_key分节存储）
CREATE TABLE IF NOT EXISTS admin_config (
  section_key VARCHAR(64) PRIMARY KEY,
  config_data JSON NOT NULL,
  description VARCHAR(200) DEFAULT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  updated_by VARCHAR(50) DEFAULT 'system'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5. 保险产品库
CREATE TABLE IF NOT EXISTS products (
  id VARCHAR(10) PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  product_type VARCHAR(50) NOT NULL,
  scenario_tags JSON NOT NULL,
  min_age INT NOT NULL DEFAULT 0,
  max_age INT NOT NULL DEFAULT 99,
  payment_modes JSON NOT NULL,
  highlights TEXT NOT NULL,
  status ENUM('active','discontinued') NOT NULL DEFAULT 'active',
  discontinued_at DATETIME DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_products_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 6. 养老政策表
CREATE TABLE IF NOT EXISTS pension_policy (
  section_key VARCHAR(64) PRIMARY KEY,
  policy_data JSON NOT NULL,
  description VARCHAR(200) DEFAULT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 7. 教育成本配置
CREATE TABLE IF NOT EXISTS education_cost_config (
  config_key VARCHAR(64) PRIMARY KEY,
  config_data JSON NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 8. 学校数据库
CREATE TABLE IF NOT EXISTS school_data (
  id VARCHAR(36) PRIMARY KEY,
  region_type ENUM('domestic','overseas') NOT NULL,
  school_type VARCHAR(50) NOT NULL,
  country VARCHAR(50) DEFAULT NULL,
  name VARCHAR(200) NOT NULL,
  detail_data JSON NOT NULL,
  updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_school_region_type (region_type, school_type)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 9. 报告任务追踪（异步）
CREATE TABLE IF NOT EXISTS report_tasks (
  id VARCHAR(36) PRIMARY KEY,
  session_id VARCHAR(36) NOT NULL,
  status ENUM('pending','processing','completed','failed') NOT NULL DEFAULT 'pending',
  input_data JSON NOT NULL,
  product_result JSON DEFAULT NULL,
  report_content LONGTEXT DEFAULT NULL,
  error_message TEXT DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME DEFAULT NULL,
  INDEX idx_report_session (session_id),
  INDEX idx_report_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 10. 审计日志（§11 配置修改记录）
CREATE TABLE IF NOT EXISTS audit_log (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  action VARCHAR(50) NOT NULL COMMENT '操作类型: config_update, profile_delete, ...',
  target_type VARCHAR(50) NOT NULL COMMENT '对象类型: admin_config, city_config, product, profile',
  target_id VARCHAR(100) DEFAULT NULL COMMENT '对象ID',
  operator VARCHAR(50) DEFAULT 'system' COMMENT '操作人',
  before_value JSON DEFAULT NULL COMMENT '修改前值',
  after_value JSON DEFAULT NULL COMMENT '修改后值',
  ip_address VARCHAR(45) DEFAULT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX idx_audit_action (action),
  INDEX idx_audit_target (target_type, target_id),
  INDEX idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
