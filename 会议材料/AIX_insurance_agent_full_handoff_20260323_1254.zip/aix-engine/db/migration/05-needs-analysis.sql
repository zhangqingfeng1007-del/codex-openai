-- 需求分析报告表
-- 数据库：aix_engine
-- 执行方式：docker compose exec -T mysql mysql -u root -proot_secret aix_engine < db/migration/05-needs-analysis.sql

USE aix_engine;

CREATE TABLE IF NOT EXISTS insurance_need_reports (
  id                   VARCHAR(36)  NOT NULL DEFAULT (UUID()),
  profile_id           VARCHAR(36)  NOT NULL,
  birth_date           VARCHAR(7)   COMMENT '出生年月，格式 YYYY-MM（用于计算精确年龄）',
  age                  INT          COMMENT '生成报告时的实际年龄',
  gender               VARCHAR(10)  COMMENT 'male / female',
  annual_income        INT          COMMENT '年收入（元，可选）',
  budget_annual        INT          COMMENT '年预算（元，可由年收入推算）',
  family_structure     VARCHAR(500) COMMENT '家庭结构（用户自由描述）',
  health_status        VARCHAR(500) COMMENT '健康状况（用户自由描述）',
  existing_coverage    TEXT         COMMENT '已有保障描述',
  primary_concern      VARCHAR(200) COMMENT '主要顾虑 / 关注险种',
  preferred_company    VARCHAR(100) COMMENT '偏好保险公司（可空）',
  report_json          JSON         NOT NULL COMMENT '完整需求报告（generate_needs_report 工具参数）',
  recommended_products JSON         COMMENT 'Top3 产品评分结果',
  created_at           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_needs_profile (profile_id),
  KEY idx_needs_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
