#!/usr/bin/env python3
"""AIX 精算服务 Java vs TypeScript 对比测试"""

import json
import requests
import sys

OLD = "http://localhost:3099/api/v1"
NEW = "http://localhost:3001/api/v1"

PASS = 0
FAIL = 0
WARN = 0


def flatten(obj, prefix=""):
    items = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            items.update(flatten(v, f"{prefix}{k}."))
    elif isinstance(obj, list):
        items[prefix.rstrip(".")] = f"[list:{len(obj)}]"
    elif isinstance(obj, (int, float)):
        items[prefix.rstrip(".")] = obj
    elif isinstance(obj, str):
        items[prefix.rstrip(".")] = obj
    else:
        items[prefix.rstrip(".")] = str(obj)
    return items


def compare(name, old_resp, new_resp, tolerance=0.01):
    global PASS, FAIL, WARN

    old_ok = old_resp.get("success")
    new_ok = new_resp.get("success")

    if not old_ok:
        print(f"  ⚠️  旧后端失败: {str(old_resp)[:200]}")
        WARN += 1
        return
    if not new_ok:
        print(f"  ❌ 新后端失败: {str(new_resp)[:200]}")
        FAIL += 1
        return

    old_flat = flatten(old_resp["data"])
    new_flat = flatten(new_resp["data"])

    diffs = []
    for k in sorted(set(list(old_flat.keys()) + list(new_flat.keys()))):
        ov = old_flat.get(k, "MISSING")
        nv = new_flat.get(k, "MISSING")
        if isinstance(ov, (int, float)) and isinstance(nv, (int, float)):
            if abs(ov - nv) > tolerance:
                diffs.append(f"    {k}: old={ov:.4f} new={nv:.4f} diff={abs(ov-nv):.4f}")
        elif isinstance(ov, str) and isinstance(nv, str):
            if ov.startswith("[list:") and nv.startswith("[list:"):
                if ov != nv:
                    diffs.append(f"    {k}: old={ov} new={nv}")
            # 跳过文本差异（detail/grade等中文描述可能微调）
        elif ov == "MISSING":
            pass  # 新后端多返回字段不算错
        elif nv == "MISSING":
            diffs.append(f"    {k}: 新后端缺少此字段 (old={ov})")

    if diffs:
        print(f"  ❌ DIFF ({len(diffs)} 项差异):")
        for d in diffs[:10]:
            print(d)
        FAIL += 1
    else:
        print(f"  ✅ PASS")
        PASS += 1


def post(base, path, payload):
    try:
        r = requests.post(f"{base}{path}", json=payload, timeout=30)
        return r.json()
    except Exception as e:
        return {"success": False, "error": str(e)}


def get(base, path):
    try:
        r = requests.get(f"{base}{path}", timeout=10)
        return r.json()
    except Exception as e:
        return {"success": False, "error": str(e)}


# ============================================================
print("═" * 55)
print("     AIX 精算对比测试：Java vs TypeScript")
print("═" * 55)
print()

# ── TEST 1-3: 退休年龄 ──
tests_retirement = [
    ("TEST 1: 退休年龄 — 35岁男性职工",
     {"customer": {"age": 35, "gender": "male", "socialSecurityType": "employee"}}),
    ("TEST 2: 退休年龄 — 40岁女性干部",
     {"customer": {"age": 40, "gender": "female", "femaleIdentityType": "cadre", "socialSecurityType": "employee"}}),
    ("TEST 3: 退休年龄 — 50岁女性工人",
     {"customer": {"age": 50, "gender": "female", "femaleIdentityType": "worker", "socialSecurityType": "employee"}}),
]

for name, payload in tests_retirement:
    print(f"▶ {name}")
    old_r = post(OLD, "/calc/pension/retirement-age", payload)
    new_r = post(NEW, "/calc/pension/retirement-age", payload)
    compare(name, old_r, new_r, tolerance=0.5)

# ── TEST 4-5: 财务评分 ──
print()
tests_financial = [
    ("TEST 4: 财务评分 — 标准双薪家庭",
     {"financial": {"personalMonthlyIncome": 15000, "spouseMonthlyIncome": 10000,
                    "totalFamilyMonthlyIncome": 25000, "fixedMonthlyExpense": 8000,
                    "mortgageMonthly": 5000, "otherLoanMonthly": 1000, "availableAssets": 800000},
      "socialSecurityType": "employee", "spouseSocialSecurityType": "employee"}),
    ("TEST 5: 财务评分 — 高负债低资产",
     {"financial": {"personalMonthlyIncome": 8000, "totalFamilyMonthlyIncome": 8000,
                    "fixedMonthlyExpense": 6000, "mortgageMonthly": 4000,
                    "otherLoanMonthly": 2000, "availableAssets": 50000},
      "socialSecurityType": "resident"}),
]

for name, payload in tests_financial:
    print(f"▶ {name}")
    old_r = post(OLD, "/calc/financial/score", payload)
    new_r = post(NEW, "/calc/financial/score", payload)
    compare(name, old_r, new_r, tolerance=0.01)

# ── TEST 6-7: 保障需求 ──
print()
tests_insurance = [
    ("TEST 6: 保障需求 — 35岁有1子女",
     {"customerAge": 35, "gender": "male", "monthlyIncome": 15000,
      "totalFamilyMonthlyIncome": 25000, "retirementAge": 63, "totalDebt": 2000000,
      "liquidAssets": 800000, "existingLifeCoverage": 500000,
      "existingCriticalIllnessCoverage": 200000, "existingMedicalCoverage": 500000,
      "annualExpense": 96000, "socialSecurityType": "employee", "cityTier": 1,
      "hasChildren": True, "childrenCount": 1, "remainingEducationCost": 600000,
      "hospitalPreference": "public"}),
    ("TEST 7: 保障需求 — 28岁单身无子女",
     {"customerAge": 28, "gender": "female", "monthlyIncome": 8000,
      "totalFamilyMonthlyIncome": 8000, "retirementAge": 58, "totalDebt": 0,
      "liquidAssets": 100000, "existingLifeCoverage": 0,
      "existingCriticalIllnessCoverage": 0, "existingMedicalCoverage": 0,
      "annualExpense": 60000, "socialSecurityType": "employee", "cityTier": 2,
      "hasChildren": False, "childrenCount": 0, "remainingEducationCost": 0,
      "hospitalPreference": "vip"}),
]

for name, payload in tests_insurance:
    print(f"▶ {name}")
    old_r = post(OLD, "/calc/insurance/needs", payload)
    new_r = post(NEW, "/calc/insurance/needs", payload)
    compare(name, old_r, new_r, tolerance=0.01)

# ── TEST 8-9: 养老缺口 ──
print()
tests_pension = [
    ("TEST 8: 养老缺口 — 北京35岁男性",
     {"customer": {"age": 35, "gender": "male", "cityWork": "beijing", "monthlyIncome": 15000,
                   "yearsPaid": 10, "socialSecurityType": "employee", "hasSpouse": False,
                   "retirementAge": 63, "children": []},
      "cityRetire": "beijing", "health": "average",
      "expense": {"activeLivingType": "own_home", "activeMonthlyResidence": 0,
                  "monthlyLiving": 6000, "otherAnnual": 30000, "medicalTier": "mid",
                  "leisureTier": "mid", "semiCareMonthlyNursing": 10000,
                  "fullCareMonthlyNursing": 18000},
      "reserve": {"enterpriseAnnuityBalance": 0, "enterpriseAnnuityMonthly": 0,
                  "personalPensionBalance": 50000, "personalPensionAnnual": 12000,
                  "otherSavings": 200000, "otherMonthlySaving": 3000},
      "scenario": "neutral",
      "scenarioParams": {"wageGrowthRate": 0.03, "inflationRate": 0.03, "returnRate": 0.03}}),
    ("TEST 9: 养老缺口 — 上海40岁女性悲观",
     {"customer": {"age": 40, "gender": "female", "femaleIdentityType": "cadre",
                   "cityWork": "shanghai", "monthlyIncome": 20000, "yearsPaid": 15,
                   "socialSecurityType": "employee", "hasSpouse": True, "retirementAge": 58,
                   "spouse": {"age": 42, "gender": "male", "monthlyIncome": 25000,
                              "yearsPaid": 18, "socialSecurityType": "employee"},
                   "children": []},
      "cityRetire": "shanghai", "health": "good", "spouseHealth": "average",
      "expense": {"activeLivingType": "own_home", "activeMonthlyResidence": 0,
                  "monthlyLiving": 8000, "otherAnnual": 50000, "medicalTier": "high",
                  "leisureTier": "high", "semiCareMonthlyNursing": 15000,
                  "fullCareMonthlyNursing": 25000},
      "reserve": {"enterpriseAnnuityBalance": 100000, "enterpriseAnnuityMonthly": 1500,
                  "personalPensionBalance": 80000, "personalPensionAnnual": 12000,
                  "otherSavings": 500000, "otherMonthlySaving": 5000},
      "scenario": "pessimistic",
      "scenarioParams": {"wageGrowthRate": 0.01, "inflationRate": 0.04, "returnRate": 0.02}}),
]

for name, payload in tests_pension:
    print(f"▶ {name}")
    old_r = post(OLD, "/calc/pension/gap", payload)
    new_r = post(NEW, "/calc/pension/gap", payload)
    compare(name, old_r, new_r, tolerance=1.0)

# ── TEST 10: 产品推荐 ──
print()
print("▶ TEST 10: 产品推荐 — 35岁有养老+教育需求")
payload = {
    "customer": {"age": 35, "gender": "male", "cityWork": "beijing", "monthlyIncome": 15000,
                 "hasSpouse": True, "children": [{"age": 5}]},
    "pensionResult": {"pensionGap": 500000},
    "educationResult": {"familyTotal": 400000},
    "insuranceResult": {"lifeInsuranceGap": 1000000, "criticalIllnessGap": 300000, "medicalGap": 500000},
    "financialResult": {"total": 75}
}
old_r = post(OLD, "/report/products", payload)
new_r = post(NEW, "/report/products", payload)
compare("product-recommendation", old_r, new_r, tolerance=0.01)

# ── 边界测试 ──
print()
print("── 边界用例 ──")

print("▶ TEST 11: 边界 — 22岁0年缴费")
old_r = post(OLD, "/calc/pension/retirement-age",
             {"customer": {"age": 22, "gender": "male", "socialSecurityType": "employee"}})
new_r = post(NEW, "/calc/pension/retirement-age",
             {"customer": {"age": 22, "gender": "male", "socialSecurityType": "employee"}})
compare("retirement-age-22", old_r, new_r, tolerance=0.5)

print("▶ TEST 12: 边界 — 无社保保障需求")
old_r = post(OLD, "/calc/insurance/needs",
             {"customerAge": 45, "gender": "male", "monthlyIncome": 5000,
              "totalFamilyMonthlyIncome": 5000, "retirementAge": 60, "totalDebt": 0,
              "liquidAssets": 30000, "existingLifeCoverage": 0,
              "existingCriticalIllnessCoverage": 0, "existingMedicalCoverage": 0,
              "annualExpense": 48000, "socialSecurityType": "none", "cityTier": 3,
              "hasChildren": False, "childrenCount": 0, "remainingEducationCost": 0,
              "hospitalPreference": "public"})
new_r = post(NEW, "/calc/insurance/needs",
             {"customerAge": 45, "gender": "male", "monthlyIncome": 5000,
              "totalFamilyMonthlyIncome": 5000, "retirementAge": 60, "totalDebt": 0,
              "liquidAssets": 30000, "existingLifeCoverage": 0,
              "existingCriticalIllnessCoverage": 0, "existingMedicalCoverage": 0,
              "annualExpense": 48000, "socialSecurityType": "none", "cityTier": 3,
              "hasChildren": False, "childrenCount": 0, "remainingEducationCost": 0,
              "hospitalPreference": "public"})
compare("insurance-needs-no-ss", old_r, new_r, tolerance=0.01)

print("▶ TEST 13: 边界 — 居民医保养老缺口")
old_r = post(OLD, "/calc/pension/gap",
             {"customer": {"age": 50, "gender": "female", "cityWork": "chengdu",
                           "monthlyIncome": 4000, "yearsPaid": 20, "socialSecurityType": "resident",
                           "hasSpouse": False, "retirementAge": 55, "children": []},
              "cityRetire": "chengdu", "health": "poor",
              "expense": {"activeLivingType": "rent", "activeMonthlyResidence": 1500,
                          "monthlyLiving": 3000, "otherAnnual": 10000, "medicalTier": "low",
                          "leisureTier": "low", "semiCareMonthlyNursing": 5000,
                          "fullCareMonthlyNursing": 10000},
              "reserve": {"enterpriseAnnuityBalance": 0, "enterpriseAnnuityMonthly": 0,
                          "personalPensionBalance": 0, "personalPensionAnnual": 0,
                          "otherSavings": 80000, "otherMonthlySaving": 500},
              "scenario": "neutral",
              "scenarioParams": {"wageGrowthRate": 0.03, "inflationRate": 0.03, "returnRate": 0.03}})
new_r = post(NEW, "/calc/pension/gap",
             {"customer": {"age": 50, "gender": "female", "cityWork": "chengdu",
                           "monthlyIncome": 4000, "yearsPaid": 20, "socialSecurityType": "resident",
                           "hasSpouse": False, "retirementAge": 55, "children": []},
              "cityRetire": "chengdu", "health": "poor",
              "expense": {"activeLivingType": "rent", "activeMonthlyResidence": 1500,
                          "monthlyLiving": 3000, "otherAnnual": 10000, "medicalTier": "low",
                          "leisureTier": "low", "semiCareMonthlyNursing": 5000,
                          "fullCareMonthlyNursing": 10000},
              "reserve": {"enterpriseAnnuityBalance": 0, "enterpriseAnnuityMonthly": 0,
                          "personalPensionBalance": 0, "personalPensionAnnual": 0,
                          "otherSavings": 80000, "otherMonthlySaving": 500},
              "scenario": "neutral",
              "scenarioParams": {"wageGrowthRate": 0.03, "inflationRate": 0.03, "returnRate": 0.03}})
compare("pension-gap-resident-chengdu", old_r, new_r, tolerance=1.0)

# ── 汇总 ──
print()
print("═" * 55)
print(f"  测试结果汇总: ✅ PASS={PASS}  ❌ FAIL={FAIL}  ⚠️ WARN={WARN}")
print(f"  总计 {PASS+FAIL+WARN} 项测试")
print("═" * 55)

sys.exit(1 if FAIL > 0 else 0)
