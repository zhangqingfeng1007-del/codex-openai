import os
from dotenv import load_dotenv
from fastapi import FastAPI
from app.routers import report
from app.routers import chat

load_dotenv()

app = FastAPI(title="AIX AI Report Service", version="2.0.0")

app.include_router(report.router, prefix="/internal/report")
app.include_router(chat.router, prefix="/internal/chat")


@app.get("/health")
async def health():
    return {"status": "ok", "version": "2.0.0", "service": "AIX-AI"}
