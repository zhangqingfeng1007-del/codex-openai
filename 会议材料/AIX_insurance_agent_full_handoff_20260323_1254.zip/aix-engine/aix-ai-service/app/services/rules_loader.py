"""规则加载器 — RAG 关键字意图匹配，动态注入相关规则片段"""

import os
from pathlib import Path
from functools import lru_cache

RULES_DIR = Path(__file__).parent.parent / "rules"

# 意图 → 规则文件映射
_INTENT_MAP = {
    "question": {
        "keywords": ["请问", "问", "了解", "情况", "告诉", "知道", "什么是", "怎么"],
        "file": "question_rules.md",
    },
    "recommend": {
        "keywords": ["推荐", "选", "哪款", "适合", "买", "购买", "投保", "对比", "比较", "哪个好"],
        "file": "product_rules.md",
    },
    "data": {
        "keywords": ["价格", "保费", "多少钱", "条款", "保额", "数据", "费率", "多少", "覆盖", "病种"],
        "file": "data_rules.md",
    },
}


@lru_cache(maxsize=10)
def _load_rule_file(filename: str) -> str:
    """加载并缓存规则文件内容。"""
    path = RULES_DIR / filename
    if path.exists():
        return path.read_text(encoding="utf-8")
    return ""


def get_relevant_rules(user_message: str) -> str:
    """根据用户消息内容，检索并返回相关规则片段。

    测试版：关键字意图匹配。
    生产版可替换为 embedding 向量检索。
    """
    if not user_message:
        # 无消息时（首次进入）注入问询规则
        return _load_rule_file("question_rules.md")

    matched_intents = set()
    msg_lower = user_message.lower()

    for intent, config in _INTENT_MAP.items():
        if any(kw in msg_lower for kw in config["keywords"]):
            matched_intents.add(intent)

    # 默认始终包含产品规则（核心防幻觉约束）
    matched_intents.add("recommend")

    parts = []
    seen_files = set()
    for intent in ("question", "recommend", "data"):
        if intent in matched_intents:
            fname = _INTENT_MAP[intent]["file"]
            if fname not in seen_files:
                content = _load_rule_file(fname)
                if content:
                    parts.append(content)
                    seen_files.add(fname)

    return "\n\n---\n\n".join(parts)


def get_all_rules() -> str:
    """返回所有规则（用于系统提示词初始化）。"""
    parts = []
    for fname in ("question_rules.md", "product_rules.md", "data_rules.md"):
        content = _load_rule_file(fname)
        if content:
            parts.append(content)
    return "\n\n---\n\n".join(parts)


def reload_rules():
    """清除缓存，重新加载规则文件（热更新）。"""
    _load_rule_file.cache_clear()
