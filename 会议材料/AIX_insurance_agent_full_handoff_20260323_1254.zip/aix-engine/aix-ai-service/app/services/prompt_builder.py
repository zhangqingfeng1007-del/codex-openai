"""构建 Kimi API 的 system/user prompt"""

import json
from typing import Any


def build_prompt(data: dict[str, Any], candidates: list[dict]) -> dict[str, str]:
    c = data.get("customer", {})
    fs = data.get("financialScore", {})
    pension = data.get("pensionResult", {})
    edu = data.get("educationResult", {})
    insurance = data.get("insuranceNeedsResult", {})
    scenario = data.get("scenario", "neutral")

    system = (
        "你是一名专业的中国保险和财务规划顾问。严格基于输入数据分析，禁止编造数据。"
        "输出中文，专业但通俗，每条建议须有明确数字和时间节点。"
    )

    children = c.get("children", [])
    json_data = {
        "客户基本画像": {
            "年龄": c.get("age"),
            "性别": "男" if c.get("gender") == "male" else "女",
            "家庭结构": "已婚" if c.get("hasSpouse") else "单身",
            "子女数量": len(children),
        },
        "财务状况": {
            "家庭月收入": data.get("financial", {}).get("totalFamilyMonthlyIncome"),
            "财务评分": fs.get("total"),
            "收支结余率": fs.get("surplusRatio"),
            "负债压力比": fs.get("debtRatio"),
            "资产储备充足度": fs.get("assetAdequacy"),
            "社保层级": fs.get("ssLevel"),
        },
        "养老规划结论": {
            "养老总需求现值": pension.get("totalNeedPV"),
            "第一支柱": pension.get("tier1PV"),
            "第二支柱": pension.get("tier2PV"),
            "第三支柱": pension.get("tier3PV"),
            "养老缺口": pension.get("pensionGap"),
            "每月需额外储蓄": pension.get("monthlyPMT"),
        } if pension else None,
        "教育规划结论": {
            "家庭教育总成本": edu.get("familyTotal"),
            "月储蓄目标保守": edu.get("monthlyTargetConservative"),
            "月储蓄目标积极": edu.get("monthlyTargetAggressive"),
        } if edu else None,
        "保障需求分析": {
            "寿险缺口": insurance.get("lifeInsuranceGap"),
            "重疾缺口": insurance.get("criticalIllnessGap"),
            "医疗缺口": insurance.get("medicalGap"),
            "教育保障": insurance.get("educationProtectionNeed"),
            "总保障缺口": insurance.get("totalProtectionGap"),
            "优先级": insurance.get("priorityOrder"),
        } if insurance else None,
        "情景": {"optimistic": "乐观", "pessimistic": "悲观"}.get(scenario, "中性"),
    }

    candidate_text = ""
    if candidates:
        lines = [f"- {p['name']}（{p['productType']}）：{p['highlights']}" for p in candidates]
        candidate_text = f"\n\n候选产品列表：\n" + "\n".join(lines)

    user = (
        f"以下是客户的测算数据：\n```json\n{json.dumps(json_data, ensure_ascii=False, indent=2)}\n```"
        f"{candidate_text}\n\n"
        "请生成包含以下五个板块的综合规划报告：\n"
        "1. 家庭财务健康诊断\n"
        "2. 教育规划建议\n"
        "3. 养老规划建议\n"
        "4. 综合优先级建议\n"
        "5. 下一步行动清单（3~5条，含明确数字和时间节点）\n\n"
    )
    if candidates:
        user += "最后从候选产品中选出最多2个最适合的产品，说明个性化推荐理由（结合客户具体数字）。"

    return {"system": system, "user": user}
