"""问题反馈存储 — 记录 AI 发现的数据/能力缺口"""

import os
import aiomysql
from typing import Optional


_MYSQL_CONF = dict(
    host=os.getenv("MYSQL_HOST", "localhost"),
    port=int(os.getenv("MYSQL_PORT", 3306)),
    user=os.getenv("MYSQL_USER", "aix"),
    password=os.getenv("MYSQL_PASSWORD", "aix_secret"),
    db=os.getenv("MYSQL_DATABASE", "aix_engine"),
    charset="utf8mb4",
    autocommit=True,
)

VALID_ISSUE_TYPES = {"unknown_product", "unanswerable_question", "data_missing"}


async def record_issue(
    issue_type: str,
    description: str,
    user_query: str = "",
    profile_id: Optional[str] = None,
) -> bool:
    """将 AI 发现的问题写入 chat_issues 表。"""
    if issue_type not in VALID_ISSUE_TYPES:
        print(f"[issue_reporter] invalid issue_type: {issue_type}")
        return False
    try:
        conn = await aiomysql.connect(**_MYSQL_CONF)
        async with conn.cursor() as cur:
            await cur.execute(
                "INSERT INTO chat_issues (profile_id, issue_type, user_query, description) "
                "VALUES (%s, %s, %s, %s)",
                (profile_id, issue_type, user_query[:1000] if user_query else "", description[:2000])
            )
        conn.close()
        print(f"[issue_reporter] recorded: {issue_type} — {description[:80]}")
        return True
    except Exception as e:
        print(f"[issue_reporter] error: {e}")
        return False
