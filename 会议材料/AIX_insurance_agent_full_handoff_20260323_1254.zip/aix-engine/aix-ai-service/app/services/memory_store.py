"""用户记忆存储 — MemGPT 分层架构

L1 核心记忆（chat_memories）：基本信息/财务/已有保险/偏好，始终注入 prompt
L2 回溯记忆（chat_summaries）：过去对话摘要，最近3条注入 prompt
"""

import os
import json
import aiomysql
from typing import Optional

_MYSQL_CONF = dict(
    host=os.getenv("MYSQL_HOST", "localhost"),
    port=int(os.getenv("MYSQL_PORT", 3306)),
    user=os.getenv("MYSQL_USER", "aix"),
    password=os.getenv("MYSQL_PASSWORD", "aix_secret"),
    db=os.getenv("MYSQL_DATABASE", "aix_engine"),
    charset="utf8mb4",
    autocommit=True,
)


async def _get_conn():
    return await aiomysql.connect(**_MYSQL_CONF)


# ─── L1 核心记忆 ─────────────────────────────────────────────────────────────

async def load_core_memory(profile_id: str) -> dict:
    """读取用户核心记忆，返回 dict（不存在则返回空 dict）。"""
    try:
        conn = await _get_conn()
        async with conn.cursor(aiomysql.DictCursor) as cur:
            await cur.execute(
                "SELECT basic_info, financial_status, existing_insurance, preferences, purchased_products "
                "FROM chat_memories WHERE profile_id = %s",
                (profile_id,)
            )
            row = await cur.fetchone()
        conn.close()
        if not row:
            return {}
        result = {}
        for field in ("basic_info", "financial_status", "existing_insurance", "preferences", "purchased_products"):
            val = row.get(field)
            if val:
                result[field] = json.loads(val) if isinstance(val, str) else val
        return result
    except Exception as e:
        print(f"[memory_store] load_core_memory error: {e}")
        return {}


async def update_core_memory(profile_id: str, field: str, value) -> bool:
    """更新核心记忆中的某个字段（upsert）。"""
    allowed = {"basic_info", "financial_status", "existing_insurance", "preferences", "purchased_products"}
    if field not in allowed:
        return False
    try:
        conn = await _get_conn()
        async with conn.cursor() as cur:
            value_json = json.dumps(value, ensure_ascii=False)
            # 先读取现有数据，合并后写入（如果是 dict/list 则 merge）
            await cur.execute(
                f"SELECT {field} FROM chat_memories WHERE profile_id = %s",
                (profile_id,)
            )
            existing_row = await cur.fetchone()

            if existing_row and existing_row[0]:
                existing = json.loads(existing_row[0]) if isinstance(existing_row[0], str) else existing_row[0]
                if isinstance(existing, dict) and isinstance(value, dict):
                    existing.update(value)
                    value_json = json.dumps(existing, ensure_ascii=False)

            import uuid
            await cur.execute(
                f"""INSERT INTO chat_memories (id, profile_id, {field})
                    VALUES (%s, %s, %s)
                    ON DUPLICATE KEY UPDATE {field} = %s, updated_at = CURRENT_TIMESTAMP""",
                (str(uuid.uuid4()), profile_id, value_json, value_json)
            )
        conn.close()
        return True
    except Exception as e:
        print(f"[memory_store] update_core_memory error: {e}")
        return False


# ─── L2 回溯记忆 ─────────────────────────────────────────────────────────────

async def load_recent_summaries(profile_id: str, limit: int = 3) -> list[dict]:
    """读取最近 N 条对话摘要。"""
    try:
        conn = await _get_conn()
        async with conn.cursor(aiomysql.DictCursor) as cur:
            await cur.execute(
                "SELECT summary, recommendation, created_at FROM chat_summaries "
                "WHERE profile_id = %s ORDER BY created_at DESC LIMIT %s",
                (profile_id, limit)
            )
            rows = await cur.fetchall()
        conn.close()
        return [dict(r) for r in rows]
    except Exception as e:
        print(f"[memory_store] load_recent_summaries error: {e}")
        return []


async def save_summary(profile_id: str, summary: str, recommendation: str = "") -> bool:
    """保存本次对话摘要。"""
    try:
        conn = await _get_conn()
        async with conn.cursor() as cur:
            await cur.execute(
                "INSERT INTO chat_summaries (profile_id, summary, recommendation) VALUES (%s, %s, %s)",
                (profile_id, summary, recommendation)
            )
        conn.close()
        return True
    except Exception as e:
        print(f"[memory_store] save_summary error: {e}")
        return False


# ─── 格式化为提示词文本 ───────────────────────────────────────────────────────

def format_memory_for_prompt(core: dict, summaries: list[dict]) -> str:
    """将记忆数据格式化为系统提示词片段。"""
    parts = []

    if core:
        parts.append("## 关于该用户，你已掌握以下信息（核心记忆）")
        if core.get("basic_info"):
            info = core["basic_info"]
            line = "- 基本信息："
            details = []
            if info.get("age"):
                details.append(f"{info['age']}岁")
            if info.get("gender"):
                details.append("男性" if info["gender"] in ("male", "男") else "女性")
            if info.get("occupation"):
                details.append(info["occupation"])
            if info.get("city"):
                details.append(info["city"])
            parts.append(line + "，".join(details) if details else line + "（已知）")

        if core.get("financial_status"):
            fs = core["financial_status"]
            if fs.get("annual_income"):
                parts.append(f"- 年收入：约 {fs['annual_income']:,} 元")
            if fs.get("budget"):
                parts.append(f"- 保险预算：约 {fs['budget']:,} 元/年")

        if core.get("existing_insurance"):
            parts.append(f"- 已有保险：{json.dumps(core['existing_insurance'], ensure_ascii=False)}")

        if core.get("preferences"):
            prefs = core["preferences"]
            if prefs.get("disease_concerns"):
                parts.append(f"- 关注病种：{prefs['disease_concerns']}")
            if prefs.get("notes"):
                parts.append(f"- 其他偏好：{prefs['notes']}")

        if core.get("purchased_products"):
            parts.append(f"- 已购产品：{json.dumps(core['purchased_products'], ensure_ascii=False)}")

    if summaries:
        parts.append("\n## 过去对话记录（回溯记忆，最近几次）")
        for s in summaries:
            date_str = str(s.get("created_at", ""))[:10]
            parts.append(f"- [{date_str}] {s['summary']}")
            if s.get("recommendation"):
                parts.append(f"  → 当时建议：{s['recommendation']}")

    return "\n".join(parts) if parts else ""
