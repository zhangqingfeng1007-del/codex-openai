"""当 Kimi API 不可用时，生成模板化兜底报告"""

from typing import Any


def fmt_wan(v: Any) -> str:
    if isinstance(v, (int, float)):
        return f"{v / 10000:.1f}万元"
    return "—"


def build_fallback_report(data: dict[str, Any], candidates: list[dict]) -> str:
    c = data.get("customer", {})
    fs = data.get("financialScore", {})
    pension = data.get("pensionResult", {})
    edu = data.get("educationResult", {})
    scenario = data.get("scenario", "neutral")

    age = c.get("age", "—")
    gender = "男" if c.get("gender") == "male" else "女"
    scenario_label = {"optimistic": "乐观", "pessimistic": "悲观"}.get(scenario, "中性")

    report = "# AIX保险综合规划报告\n\n"
    report += "> 本报告基于您填写的数据自动生成（模板模式，AI服务暂不可用）\n\n"

    report += "## 一、家庭财务健康诊断\n\n"
    report += f"- **客户画像**：{age}岁{gender}，{'已婚' if c.get('hasSpouse') else '单身'}\n"
    if fs:
        report += f"- **财务健康评分**：{fs.get('total', '—')} 分（{fs.get('grade', '—')}）\n"
        sr = fs.get("surplusRatio")
        report += f"- **收支结余率**：{sr * 100:.1f}%\n" if isinstance(sr, (int, float)) else ""
        dr = fs.get("debtRatio")
        report += f"- **负债压力比**：{dr * 100:.1f}%\n" if isinstance(dr, (int, float)) else ""
        aa = fs.get("assetAdequacy")
        report += f"- **资产储备充足度**：{aa:.2f}x\n" if isinstance(aa, (int, float)) else ""

    report += "\n## 二、教育规划建议\n\n"
    if edu:
        report += f"- **家庭教育总成本**：{fmt_wan(edu.get('familyTotal'))}\n"
        mc = edu.get("monthlyTargetConservative")
        if isinstance(mc, (int, float)):
            report += f"- **保守月储蓄目标**（年化3%）：{round(mc):,}元/月\n"
    else:
        report += "暂无教育规划数据。\n"

    report += f"\n## 三、养老规划建议（{scenario_label}情景）\n\n"
    if pension:
        report += f"- **养老总需求现值**：{fmt_wan(pension.get('totalNeedPV'))}\n"
        report += f"- **第一支柱（社保）**：{fmt_wan(pension.get('tier1PV'))}\n"
        report += f"- **第二支柱（年金）**：{fmt_wan(pension.get('tier2PV'))}\n"
        report += f"- **第三支柱（个人）**：{fmt_wan(pension.get('tier3PV'))}\n"
        report += f"- **养老缺口**：{fmt_wan(pension.get('pensionGap'))}\n"
        pmt = pension.get("monthlyPMT")
        if isinstance(pmt, (int, float)):
            report += f"- **建议月储蓄**：{round(pmt):,}元/月\n"
    else:
        report += "暂无养老测算数据。\n"

    report += "\n## 四、综合优先级建议\n\n"
    priorities = []
    if pension and isinstance(pension.get("pensionGap"), (int, float)) and pension["pensionGap"] > 0:
        priorities.append("补充养老储蓄（养老缺口较大）")
    if edu and isinstance(edu.get("familyTotal"), (int, float)) and edu["familyTotal"] > 0:
        priorities.append("教育金专项储备")
    if fs and isinstance(fs.get("total"), (int, float)) and fs["total"] < 60:
        priorities.append("提升家庭风险保障（财务评分偏低）")
    if not priorities:
        priorities.append("保持现有规划，适时调整")
    for i, p in enumerate(priorities, 1):
        report += f"{i}. {p}\n"

    report += "\n## 五、下一步行动清单\n\n"
    report += "1. 根据养老缺口，每月额外储蓄并配置稳健型理财产品\n"
    report += "2. 为子女教育设立专项账户，选择中长期投资组合\n"
    report += "3. 审视家庭保险覆盖，确保寿险、重疾险保额充足\n"

    if candidates:
        report += "\n---\n\n## 推荐产品\n\n"
        for p in candidates[:2]:
            report += f"- **{p['name']}**（{p['productType']}）：{p['highlights']}\n"

    report += "\n---\n*以上报告由AIX系统自动生成，仅供参考，不构成投资建议。*\n"
    return report
