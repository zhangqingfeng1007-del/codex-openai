"""Kimi (Moonshot) API SSE 流式客户端"""

import os
import json
from typing import AsyncIterator, AsyncGenerator, Callable, Awaitable, Optional
import httpx


KIMI_API_BASE = os.getenv("KIMI_API_BASE", "https://api.moonshot.cn/v1")
KIMI_API_KEY = os.getenv("KIMI_API_KEY", "")


async def stream_kimi_chat(
    system: str,
    user: str,
    model: str = "kimi-k2.5",
    max_tokens: int = 4096,
    temperature: float = 1.0,
) -> AsyncIterator[str]:
    """
    调用 Kimi API 的 chat/completions (stream=true)，
    逐 chunk 返回 content 文本。
    """
    url = f"{KIMI_API_BASE}/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {KIMI_API_KEY}",
    }
    payload = {
        "model": model,
        "stream": True,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "messages": [
            {"role": "system", "content": system},
            {"role": "user", "content": user},
        ],
    }

    async with httpx.AsyncClient(timeout=300.0) as client:
        async with client.stream("POST", url, json=payload, headers=headers) as response:
            if response.status_code != 200:
                text = await response.aread()
                raise Exception(f"Kimi API error: {response.status_code} {text.decode()}")

            async for line in response.aiter_lines():
                line = line.strip()
                if not line.startswith("data:"):
                    continue
                raw = line[5:].strip()
                if raw == "[DONE]":
                    return
                try:
                    data = json.loads(raw)
                    content = data.get("choices", [{}])[0].get("delta", {}).get("content")
                    if content:
                        yield content
                except json.JSONDecodeError:
                    continue


async def call_kimi_with_tools(
    system: str,
    messages: list[dict],
    tools: list[dict],
    tool_handler: Optional[Callable[[str, dict], Awaitable[str]]] = None,
    model: str = "kimi-k2.5",
    max_tokens: int = 2048,
) -> AsyncGenerator[dict, None]:
    """支持 Function Calling 的对话调用（多轮工具回调）。

    每次 yield 一个 dict：
      {"type": "chunk",     "content": "..."}   — 文字片段
      {"type": "tool_call", "name": "...", "arguments": {...}}  — 工具调用
      {"type": "done"}

    当 Kimi 以 finish_reason=tool_calls 返回时，自动发送工具结果并发起下一轮请求。
    """
    url = f"{KIMI_API_BASE}/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {KIMI_API_KEY}",
    }
    current_messages = [{"role": "system", "content": system}, *messages]

    for _round in range(5):  # 最多5轮工具调用，防止死循环
        payload = {
            "model": model,
            "stream": True,
            "temperature": 1,
            "max_tokens": max_tokens,
            "messages": current_messages,
            "tools": tools,
            "tool_choice": "auto",
        }

        # 收集本轮所有工具调用（流式中分片拼接）和 reasoning_content
        collected_tools: list[dict] = []  # [{id, name, arguments_str}]
        reasoning_content: str = ""
        finish_reason = None

        async with httpx.AsyncClient(timeout=300.0) as client:
            async with client.stream("POST", url, json=payload, headers=headers) as response:
                if response.status_code != 200:
                    text = await response.aread()
                    raise Exception(f"Kimi API error: {response.status_code} {text.decode()}")

                async for line in response.aiter_lines():
                    line = line.strip()
                    if not line.startswith("data:"):
                        continue
                    raw = line[5:].strip()
                    if raw == "[DONE]":
                        break

                    try:
                        data = json.loads(raw)
                        choice = data.get("choices", [{}])[0]
                        delta = choice.get("delta", {})
                        fr = choice.get("finish_reason")
                        if fr:
                            finish_reason = fr

                        # 收集 thinking 内容（回传时必须带上）
                        rc = delta.get("reasoning_content")
                        if rc:
                            reasoning_content += rc

                        # 工具调用（流式分片，按 index 拼接）
                        tool_calls = delta.get("tool_calls")
                        if tool_calls:
                            for tc in tool_calls:
                                idx = tc.get("index", 0)
                                func = tc.get("function", {})
                                # 确保列表足够长
                                while len(collected_tools) <= idx:
                                    collected_tools.append({"id": "", "name": "", "arguments_str": ""})
                                if tc.get("id"):
                                    collected_tools[idx]["id"] = tc["id"]
                                if func.get("name"):
                                    collected_tools[idx]["name"] = func["name"]
                                collected_tools[idx]["arguments_str"] += func.get("arguments", "")
                            continue

                        # 普通文字内容，实时流出
                        content = delta.get("content")
                        if content:
                            yield {"type": "chunk", "content": content}

                    except json.JSONDecodeError:
                        continue

        # 本轮结束：处理工具调用
        if collected_tools and finish_reason == "tool_calls":
            # 1. 发出工具调用事件（供 router 处理 side effects）
            tool_call_msgs = []
            tool_result_msgs = []
            for tc in collected_tools:
                if not tc["name"]:
                    continue
                try:
                    args = json.loads(tc["arguments_str"]) if tc["arguments_str"] else {}
                except json.JSONDecodeError:
                    args = {"raw": tc["arguments_str"]}

                yield {"type": "tool_call", "name": tc["name"], "arguments": args}

                tool_call_msgs.append({
                    "id": tc["id"] or f"call_{tc['name']}",
                    "type": "function",
                    "function": {"name": tc["name"], "arguments": tc["arguments_str"]},
                })
                # 调用 tool_handler 获取真实结果，无 handler 时返回 "ok"
                tool_result = "ok"
                if tool_handler:
                    try:
                        tool_result = await tool_handler(tc["name"], args)
                    except Exception as e:
                        tool_result = f"工具执行失败: {e}"

                tool_result_msgs.append({
                    "role": "tool",
                    "tool_call_id": tc["id"] or f"call_{tc['name']}",
                    "content": tool_result,
                })

            # 2. 将 assistant tool_call 消息 + tool 结果追加到对话历史
            # kimi-k2.5 thinking 模式要求 assistant 消息带 reasoning_content
            if tool_call_msgs:
                assistant_msg: dict = {
                    "role": "assistant",
                    "content": None,
                    "tool_calls": tool_call_msgs,
                }
                if reasoning_content:
                    assistant_msg["reasoning_content"] = reasoning_content
                current_messages.append(assistant_msg)
                current_messages.extend(tool_result_msgs)
            # 继续下一轮，让 Kimi 生成文字回复
            continue

        # 没有纯 tool_calls 轮次（正常结束或混合输出），退出循环
        break

    yield {"type": "done"}


async def stream_kimi_multi(
    messages: list[dict],
    model: str = "kimi-k2.5",
    max_tokens: int = 2048,
    temperature: float = 1.0,
) -> AsyncIterator[str]:
    """多轮对话模式"""
    url = f"{KIMI_API_BASE}/chat/completions"
    headers = {
        "Content-Type": "application/json",
        "Authorization": f"Bearer {KIMI_API_KEY}",
    }
    all_messages = [
        {"role": "system", "content": "你是一名专业的中国保险财务规划顾问。请基于客户已有的测算数据回答问题，给出具体数字建议。"},
        *messages,
    ]
    payload = {
        "model": model,
        "stream": True,
        "temperature": temperature,
        "max_tokens": max_tokens,
        "messages": all_messages,
    }

    async with httpx.AsyncClient(timeout=120.0) as client:
        async with client.stream("POST", url, json=payload, headers=headers) as response:
            if response.status_code != 200:
                text = await response.aread()
                raise Exception(f"Kimi API error: {response.status_code} {text.decode()}")

            async for line in response.aiter_lines():
                line = line.strip()
                if not line.startswith("data:"):
                    continue
                raw = line[5:].strip()
                if raw == "[DONE]":
                    return
                try:
                    data = json.loads(raw)
                    content = data.get("choices", [{}])[0].get("delta", {}).get("content")
                    if content:
                        yield content
                except json.JSONDecodeError:
                    continue
