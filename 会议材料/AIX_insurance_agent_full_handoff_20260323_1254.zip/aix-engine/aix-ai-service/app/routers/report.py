"""AI 报告生成路由 — SSE 流式输出"""

import os
import json
from fastapi import APIRouter, Request
from fastapi.responses import StreamingResponse

from app.services.prompt_builder import build_prompt
from app.services.fallback_report import build_fallback_report
from app.services.kimi_client import stream_kimi_chat, stream_kimi_multi

router = APIRouter()


def sse_event(event: str, data: str) -> str:
    return f"event: {event}\ndata: {data}\n\n"


@router.post("/generate")
async def generate_report(request: Request):
    body = await request.json()
    candidates = body.get("candidates", [])

    async def event_stream():
        kimi_key = os.getenv("KIMI_API_KEY", "")

        # 无 API key 或占位符 → 兜底模板
        if not kimi_key or kimi_key.startswith("your_"):
            fallback = build_fallback_report(body, candidates)
            chunk_size = 80
            for i in range(0, len(fallback), chunk_size):
                yield sse_event("chunk", json.dumps({"content": fallback[i:i + chunk_size]}, ensure_ascii=False))
            yield sse_event("done", "{}")
            return

        # 正常调用 Kimi API
        try:
            prompt = build_prompt(body, candidates)
            async for content in stream_kimi_chat(prompt["system"], prompt["user"]):
                yield sse_event("chunk", json.dumps({"content": content}, ensure_ascii=False))
            yield sse_event("done", "{}")
        except Exception as e:
            yield sse_event("error", json.dumps({"message": str(e)}, ensure_ascii=False))

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.post("/chat")
async def chat(request: Request):
    body = await request.json()
    messages = body.get("messages", [])

    kimi_key = os.getenv("KIMI_API_KEY", "")
    if not kimi_key or kimi_key.startswith("your_"):
        async def no_key():
            yield sse_event("error", json.dumps({"message": "未配置KIMI_API_KEY"}, ensure_ascii=False))
        return StreamingResponse(no_key(), media_type="text/event-stream")

    async def event_stream():
        try:
            async for content in stream_kimi_multi(messages):
                yield sse_event("chunk", json.dumps({"content": content}, ensure_ascii=False))
            yield sse_event("done", "{}")
        except Exception as e:
            yield sse_event("error", json.dumps({"message": str(e)}, ensure_ascii=False))

    return StreamingResponse(
        event_stream(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )
