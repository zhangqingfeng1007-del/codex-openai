package com.aix.actuarial.repository;

import com.aix.actuarial.model.entity.AdminConfigEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AdminConfigRepository extends JpaRepository<AdminConfigEntity, String> {
}
