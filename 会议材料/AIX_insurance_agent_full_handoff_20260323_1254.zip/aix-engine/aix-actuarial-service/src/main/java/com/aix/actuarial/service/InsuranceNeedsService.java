package com.aix.actuarial.service;

import com.aix.actuarial.config.AdminConfigService;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class InsuranceNeedsService {

    private final AdminConfigService adminConfig;

    public InsuranceNeedsService(AdminConfigService adminConfig) {
        this.adminConfig = adminConfig;
    }

    public Map<String, Object> calcInsuranceNeeds(Map<String, Object> input) {
        int customerAge = toInt(input.get("customerAge"));
        int retirementAge = toInt(input.get("retirementAge"));
        int remainingWorkYears = Math.max(retirementAge - customerAge, 0);
        double annualExpense = toDouble(input.get("annualExpense"));
        boolean hasChildren = toBool(input.get("hasChildren"));
        double remainingEducationCost = toDouble(input.get("remainingEducationCost"));
        double totalDebt = toDouble(input.get("totalDebt"));
        double liquidAssets = toDouble(input.get("liquidAssets"));
        double existingLifeCoverage = toDouble(input.get("existingLifeCoverage"));
        double existingCriticalIllnessCoverage = toDouble(input.get("existingCriticalIllnessCoverage"));
        double existingMedicalCoverage = toDouble(input.get("existingMedicalCoverage"));
        int cityTier = toInt(input.get("cityTier"));
        String ssType = (String) input.getOrDefault("socialSecurityType", "employee");
        String hospitalPref = (String) input.getOrDefault("hospitalPreference", "public");
        int childrenCount = toInt(input.get("childrenCount"));

        JsonNode medData = adminConfig.getMedicalCostData();
        String tierKey = "tier" + cityTier;

        // 1. 寿险需求（家庭责任法）
        double livingGap = annualExpense * remainingWorkYears;
        double educationGap = hasChildren ? remainingEducationCost : 0;
        double lifeInsuranceNeed = Math.max(livingGap + educationGap + totalDebt - liquidAssets, 0);
        double lifeInsuranceGap = Math.max(lifeInsuranceNeed - existingLifeCoverage, 0);

        // 2. 重疾险需求
        double criticalIllnessCost = medData.get("criticalIllness").has(tierKey)
                ? medData.get("criticalIllness").get(tierKey).asDouble() : 400000;
        double ssReimbursementRate = medData.get("socialSecurityReimbursement").has(ssType)
                ? medData.get("socialSecurityReimbursement").get(ssType).asDouble() : 0.5;
        double criticalIllnessNeed = Math.max(
                Math.round(criticalIllnessCost * 1.2 - criticalIllnessCost * ssReimbursementRate), 300000);
        double criticalIllnessGap = Math.max(criticalIllnessNeed - existingCriticalIllnessCoverage, 0);

        // 3. 医疗险需求（基于医院偏好）
        JsonNode hospitalData = medData.get("hospitalTierCost").has(hospitalPref)
                ? medData.get("hospitalTierCost").get(hospitalPref)
                : medData.get("hospitalTierCost").get("public");
        double medicalNeed = hospitalData.get("suggestedCoverage").asDouble();
        double medicalGap = Math.max(medicalNeed - existingMedicalCoverage, 0);

        // 4. 教育保障需求
        double educationProtectionNeed = hasChildren ? remainingEducationCost : 0;

        // 总缺口
        double totalProtectionGap = lifeInsuranceGap + criticalIllnessGap + medicalGap + educationProtectionNeed;

        // 优先级排序
        List<Map.Entry<String, Double>> items = new ArrayList<>();
        items.add(Map.entry("critical_illness", criticalIllnessGap));
        items.add(Map.entry("life", lifeInsuranceGap));
        items.add(Map.entry("medical", medicalGap));
        items.add(Map.entry("education", educationProtectionNeed));
        List<String> priorityOrder = items.stream()
                .filter(e -> e.getValue() > 0)
                .sorted((a, b) -> Double.compare(b.getValue(), a.getValue()))
                .map(Map.Entry::getKey)
                .collect(Collectors.toList());

        // 详情说明
        Map<String, String> details = new LinkedHashMap<>();
        String hospitalLabel = hospitalData.has("label") ? hospitalData.get("label").asText() : "公立医院";

        if (lifeInsuranceGap > 0) {
            details.put("life", String.format("家庭责任法：生活费缺口%s + 教育缺口%s + 负债%s − 流动资产%s = 寿险需求%s，已有%s，缺口%s",
                    fmtWan(livingGap), fmtWan(educationGap), fmtWan(totalDebt), fmtWan(liquidAssets),
                    fmtWan(lifeInsuranceNeed), fmtWan(existingLifeCoverage), fmtWan(lifeInsuranceGap)));
        } else {
            details.put("life", String.format("寿险保障充足（已有%s，需求%s）", fmtWan(existingLifeCoverage), fmtWan(lifeInsuranceNeed)));
        }

        if (criticalIllnessGap > 0) {
            details.put("critical_illness", String.format("重疾平均治疗费%s×1.2 − 社保报销(%.0f%%) = 需求%s，已有%s，缺口%s",
                    fmtWan(criticalIllnessCost), ssReimbursementRate * 100,
                    fmtWan(criticalIllnessNeed), fmtWan(existingCriticalIllnessCoverage), fmtWan(criticalIllnessGap)));
        } else {
            details.put("critical_illness", String.format("重疾险保障充足（已有%s，需求%s）",
                    fmtWan(existingCriticalIllnessCoverage), fmtWan(criticalIllnessNeed)));
        }

        if (medicalGap > 0) {
            details.put("medical", String.format("就医偏好：%s，建议医疗险保额%s，已有%s，缺口%s",
                    hospitalLabel, fmtWan(medicalNeed), fmtWan(existingMedicalCoverage), fmtWan(medicalGap)));
        } else {
            details.put("medical", String.format("医疗险保障充足（已有年度额度%s，%s建议%s）",
                    fmtWan(existingMedicalCoverage), hospitalLabel, fmtWan(medicalNeed)));
        }

        if (educationProtectionNeed > 0) {
            details.put("education", String.format("%d名子女剩余教育费用%s，需通过寿险或教育金保障",
                    childrenCount, fmtWan(educationProtectionNeed)));
        } else {
            details.put("education", hasChildren ? "子女教育费用已覆盖" : "无子女，暂不需要教育保障");
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("lifeInsuranceNeed", lifeInsuranceNeed);
        result.put("lifeInsuranceGap", lifeInsuranceGap);
        result.put("criticalIllnessNeed", criticalIllnessNeed);
        result.put("criticalIllnessGap", criticalIllnessGap);
        result.put("medicalNeed", medicalNeed);
        result.put("medicalGap", medicalGap);
        result.put("educationProtectionNeed", educationProtectionNeed);
        result.put("totalProtectionGap", totalProtectionGap);
        result.put("priorityOrder", priorityOrder);
        result.put("details", details);
        return result;
    }

    private String fmtWan(double v) {
        return String.format("%.0f万", v / 10000);
    }

    private int toInt(Object obj) {
        if (obj instanceof Number n) return n.intValue();
        return 0;
    }

    private double toDouble(Object obj) {
        if (obj instanceof Number n) return n.doubleValue();
        return 0;
    }

    private boolean toBool(Object obj) {
        if (obj instanceof Boolean b) return b;
        return false;
    }
}
