package com.aix.actuarial.model.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "admin_config")
public class AdminConfigEntity {
    @Id
    @Column(name = "section_key")
    private String sectionKey;

    @Column(name = "config_data", columnDefinition = "json")
    private String configData;

    private String description;

    @Column(name = "updated_by")
    private String updatedBy;
}
