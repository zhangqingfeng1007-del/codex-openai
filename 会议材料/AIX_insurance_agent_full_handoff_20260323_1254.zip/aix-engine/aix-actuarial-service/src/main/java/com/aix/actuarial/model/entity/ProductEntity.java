package com.aix.actuarial.model.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "products")
public class ProductEntity {
    @Id
    private String id;
    private String name;

    @Column(name = "product_type")
    private String productType;

    @Column(name = "scenario_tags", columnDefinition = "json")
    private String scenarioTags;

    @Column(name = "min_age")
    private Integer minAge;

    @Column(name = "max_age")
    private Integer maxAge;

    @Column(name = "payment_modes", columnDefinition = "json")
    private String paymentModes;

    private String highlights;
    private String status;
}
