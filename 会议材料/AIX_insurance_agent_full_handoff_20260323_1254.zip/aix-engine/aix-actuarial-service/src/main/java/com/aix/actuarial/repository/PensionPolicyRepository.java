package com.aix.actuarial.repository;

import com.aix.actuarial.model.entity.PensionPolicyEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PensionPolicyRepository extends JpaRepository<PensionPolicyEntity, String> {
}
