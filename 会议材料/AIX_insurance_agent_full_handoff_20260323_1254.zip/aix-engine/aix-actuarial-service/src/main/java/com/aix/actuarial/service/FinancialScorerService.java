package com.aix.actuarial.service;

import com.aix.actuarial.config.AdminConfigService;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

@Service
public class FinancialScorerService {

    private final AdminConfigService adminConfig;

    public FinancialScorerService(AdminConfigService adminConfig) {
        this.adminConfig = adminConfig;
    }

    private double lerp(double val, double min, double max, double scoreMin, double scoreMax) {
        if (val <= min) return scoreMin;
        if (val >= max) return scoreMax;
        return scoreMin + (scoreMax - scoreMin) * (val - min) / (max - min);
    }

    public Map<String, Object> calcFinancialScore(Map<String, Object> input) {
        Map<String, Object> financial = asMap(input.get("financial"));
        String ssType = (String) input.get("socialSecurityType");
        String spouseSsType = (String) input.get("spouseSocialSecurityType");

        JsonNode rules = adminConfig.getFinancialScoringRules();
        JsonNode w = rules.get("weights");
        JsonNode t = rules.get("thresholds");

        double totalMonthlyIncome = toDouble(financial.get("totalFamilyMonthlyIncome"));
        double monthlyExpense = toDouble(financial.get("fixedMonthlyExpense"));
        double monthlyDebt = toDouble(financial.get("mortgageMonthly")) + toDouble(financial.get("otherLoanMonthly"));

        // 收支结余率
        double surplusRatio = totalMonthlyIncome > 0
                ? (totalMonthlyIncome - monthlyExpense - monthlyDebt) / totalMonthlyIncome : 0;
        double surplusScore = lerp(surplusRatio,
                t.get("surplusRatioPoor").asDouble(), t.get("surplusRatioExcellent").asDouble(),
                0, w.get("surplusRatio").asDouble() * 100);

        // 负债压力比
        double debtRatio = totalMonthlyIncome > 0 ? monthlyDebt / totalMonthlyIncome : 0;
        double debtScore = lerp(debtRatio,
                t.get("debtRatioSafe").asDouble(), t.get("debtRatioDanger").asDouble(),
                w.get("debtRatio").asDouble() * 100, 0);

        // 资产储备充足度
        int nMonths = t.get("assetAdequacyMonths").asInt();
        double targetExpense = (monthlyExpense + monthlyDebt) * nMonths;
        double availableAssets = toDouble(financial.get("availableAssets"));
        double assetAdequacy = targetExpense > 0 ? availableAssets / targetExpense : 0;
        double assetScore = lerp(assetAdequacy, 0, 1, 0, w.get("assetAdequacy").asDouble() * 100);

        // 社保保障层级
        double ssRank = getSsRank(ssType);
        double spouseRank = spouseSsType != null ? getSsRank(spouseSsType) : 0;
        double ssScoreRaw = ssRank * 0.8 + spouseRank * 0.2;
        double ssWeightedScore = ssScoreRaw * w.get("ssLevel").asDouble();

        String ssLevel;
        if ("employee".equals(ssType) || "civil_servant".equals(ssType)) ssLevel = "high";
        else if ("resident".equals(ssType)) ssLevel = "medium";
        else ssLevel = "low";

        int total = (int) Math.min(100, Math.round(surplusScore + debtScore + assetScore + ssWeightedScore));

        String grade;
        if (total >= t.get("gradeHigh").asInt()) grade = "财务健康，保障规划空间充裕";
        else if (total >= t.get("gradeMedium").asInt()) grade = "基本稳健，存在局部风险点";
        else if (total >= t.get("gradeLow").asInt()) grade = "财务承压，需优先补充保障";
        else grade = "高风险，建议全面规划";

        // 文字解读
        List<String> lines = new ArrayList<>();
        if (surplusRatio < 0.1) lines.add("月度结余率偏低（低于10%），建议控制非必要支出，力争储蓄率达到20%以上。");
        else if (surplusRatio >= t.get("surplusRatioExcellent").asDouble()) lines.add("月度储蓄结余良好，资金积累效率高。");
        if (debtRatio > t.get("debtRatioDanger").asDouble())
            lines.add(String.format("债务负担高风险（超过月收入%.0f%%），建议优先降低负债。", t.get("debtRatioDanger").asDouble() * 100));
        else if (debtRatio > t.get("debtRatioSafe").asDouble()) lines.add("债务负担处于警戒区间，建议避免新增负债。");
        if (assetAdequacy < 0.5) lines.add(String.format("应急储备不足%d个月支出，建议优先建立%d个月流动性缓冲。", nMonths / 2, nMonths));
        else if (assetAdequacy >= 1) lines.add(String.format("应急储备充足，覆盖%d个月以上支出。", nMonths));

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("total", total);
        result.put("surplusRatio", surplusRatio);
        result.put("debtRatio", debtRatio);
        result.put("assetAdequacy", assetAdequacy);
        result.put("ssLevel", ssLevel);
        result.put("detail", String.join(" ", lines));
        result.put("grade", grade);
        return result;
    }

    private double getSsRank(String ssType) {
        return switch (ssType) {
            case "civil_servant", "employee" -> 100;
            case "resident" -> 60;
            default -> 0;
        };
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> asMap(Object obj) {
        return obj instanceof Map ? (Map<String, Object>) obj : Map.of();
    }

    private double toDouble(Object obj) {
        if (obj instanceof Number n) return n.doubleValue();
        return 0;
    }
}
