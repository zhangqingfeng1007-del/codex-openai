package com.aix.actuarial.controller;

import com.aix.actuarial.model.entity.ProductActuarialConfigEntity;
import com.aix.actuarial.repository.ProductActuarialConfigRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/**
 * 精算配置管理接口（供管理后台使用）
 *
 * GET    /api/v1/admin/actuarial/configs          列出所有产品配置
 * GET    /api/v1/admin/actuarial/configs/{id}     查单条
 * POST   /api/v1/admin/actuarial/configs          新增/覆盖配置
 * PUT    /api/v1/admin/actuarial/configs/{id}     更新配置
 * DELETE /api/v1/admin/actuarial/configs/{id}     删除配置
 * GET    /api/v1/admin/actuarial/tables           查询可用精算表列表
 */
@RestController
@RequestMapping("/api/v1/admin/actuarial")
@RequiredArgsConstructor
public class ActuarialAdminController {

    private final ProductActuarialConfigRepository configRepo;
    private final JdbcTemplate jdbcTemplate;

    @GetMapping("/configs")
    public List<ProductActuarialConfigEntity> listConfigs() {
        return configRepo.findAll();
    }

    @GetMapping("/configs/{productId}")
    public ResponseEntity<ProductActuarialConfigEntity> getConfig(@PathVariable String productId) {
        return configRepo.findById(productId)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping("/configs")
    public ProductActuarialConfigEntity saveConfig(@RequestBody ProductActuarialConfigEntity config) {
        return configRepo.save(config);
    }

    @PutMapping("/configs/{productId}")
    public ResponseEntity<ProductActuarialConfigEntity> updateConfig(
            @PathVariable String productId,
            @RequestBody ProductActuarialConfigEntity config
    ) {
        if (!configRepo.existsById(productId)) {
            return ResponseEntity.notFound().build();
        }
        config.setProductId(productId);
        return ResponseEntity.ok(configRepo.save(config));
    }

    @DeleteMapping("/configs/{productId}")
    public ResponseEntity<Void> deleteConfig(@PathVariable String productId) {
        if (!configRepo.existsById(productId)) {
            return ResponseEntity.notFound().build();
        }
        configRepo.deleteById(productId);
        return ResponseEntity.noContent().build();
    }

    /** 返回数据库中已有的精算表名列表（便于前端下拉选择） */
    @GetMapping("/tables")
    public Map<String, Object> listTables() {
        List<String> qxTables = jdbcTemplate.queryForList(
                "SELECT DISTINCT table_name FROM actuarial_qx_table ORDER BY table_name",
                String.class
        );
        List<String> ciTables = jdbcTemplate.queryForList(
                "SELECT DISTINCT table_name FROM actuarial_ci_table ORDER BY table_name",
                String.class
        );
        return Map.of("mortalityTables", qxTables, "ciTables", ciTables);
    }
}
