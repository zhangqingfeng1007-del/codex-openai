package com.aix.actuarial.repository;

import com.aix.actuarial.model.entity.CityConfigEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface CityConfigRepository extends JpaRepository<CityConfigEntity, String> {
    List<CityConfigEntity> findByTier(Integer tier);
}
