package com.aix.actuarial.service;

import com.aix.actuarial.config.AdminConfigService;
import com.aix.actuarial.config.CityConfigService;
import com.aix.actuarial.config.PensionPolicyService;
import com.aix.actuarial.model.entity.CityConfigEntity;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class PensionCalculatorService {

    private final CityConfigService cityConfig;
    private final AdminConfigService adminConfig;
    private final PensionPolicyService pensionPolicy;

    private static final int CURRENT_YEAR = java.time.Year.now().getValue();

    public PensionCalculatorService(CityConfigService cityConfig, AdminConfigService adminConfig, PensionPolicyService pensionPolicy) {
        this.cityConfig = cityConfig;
        this.adminConfig = adminConfig;
        this.pensionPolicy = pensionPolicy;
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> calcPension(Map<String, Object> input) {
        Map<String, Object> customer = (Map<String, Object>) input.get("customer");
        Map<String, Object> expense = (Map<String, Object>) input.get("expense");
        Map<String, Object> reserve = (Map<String, Object>) input.get("reserve");
        Map<String, Object> scenarioParams = (Map<String, Object>) input.get("scenarioParams");
        String cityWork = (String) customer.getOrDefault("cityWork", input.get("cityRetire"));
        String health = (String) input.getOrDefault("health", "average");

        int age = toInt(customer.get("age"));
        String gender = (String) customer.get("gender");
        String ssType = (String) customer.getOrDefault("socialSecurityType", "employee");
        int yearsPaid = toInt(customer.get("yearsPaid"));
        double monthlyIncome = toDouble(customer.get("monthlyIncome"));
        double ssBase = toDouble(customer.get("ssContributionBase"));
        int retAge = customer.containsKey("retirementAge") && customer.get("retirementAge") != null
                ? toInt(customer.get("retirementAge"))
                : ("male".equals(gender) ? 60 : 55);

        double returnRate = toDouble(scenarioParams.get("returnRate"));
        double inflationRate = toDouble(scenarioParams.get("inflationRate"));
        double wageGrowthRate = toDouble(scenarioParams.get("wageGrowthRate"));

        int remYrs = Math.max(0, retAge - age);
        int lifespan = getExpectedLifespan(gender, health);
        int[] phases = getPhaseAges(retAge, health, lifespan);

        // 月养老金
        double mp = calcMonthlyPension(age, gender, ssType, yearsPaid, monthlyIncome,
                ssBase > 0 ? ssBase : monthlyIncome, retAge, cityWork);

        // 第一支柱现值
        int rcvYrs = lifespan - retAge;
        double af = rcvYrs > 0 && returnRate > 0
                ? (1 - Math.pow(1 + returnRate, -rcvYrs)) / returnRate : rcvYrs;
        double tier1PV = mp * 12 * af;

        // 需求现值
        double needPV = calcNeedPV(expense, phases, returnRate, inflationRate);

        // 储备终值
        double[] reserveFV = calcReserveFV(reserve, remYrs, returnRate);
        double tier2PV = reserveFV[0];
        double tier3PV = reserveFV[1];

        // 配偶缺口
        double spGap = 0;
        boolean hasSpouse = toBool(customer.get("hasSpouse"));
        if (hasSpouse && customer.containsKey("spouse") && customer.get("spouse") != null) {
            Map<String, Object> sp = (Map<String, Object>) customer.get("spouse");
            String spGender = (String) sp.get("gender");
            int spAge = toInt(sp.get("age"));
            int spRetAge = sp.containsKey("retirementAge") && sp.get("retirementAge") != null
                    ? toInt(sp.get("retirementAge"))
                    : ("male".equals(spGender) ? 60 : 55);
            String spHealth = input.containsKey("spouseHealth") ? (String) input.get("spouseHealth") : "average";
            int spRem = Math.max(0, spRetAge - spAge);
            int spLife = getExpectedLifespan(spGender, spHealth);
            int[] spPhases = getPhaseAges(spRetAge, spHealth, spLife);
            double spMp = calcMonthlyPension(spAge, spGender,
                    (String) sp.getOrDefault("socialSecurityType", "employee"),
                    toInt(sp.get("yearsPaid")), toDouble(sp.get("monthlyIncome")),
                    toDouble(sp.get("ssContributionBase")), spRetAge, cityWork);
            int spRcv = spLife - spRetAge;
            double spAf = spRcv > 0 && returnRate > 0
                    ? (1 - Math.pow(1 + returnRate, -spRcv)) / returnRate : spRcv;
            double spT1 = spMp * 12 * spAf;
            Map<String, Object> spExpense = input.containsKey("spouseExpense")
                    ? (Map<String, Object>) input.get("spouseExpense") : null;
            double spNeed = spExpense != null ? calcNeedPV(spExpense, spPhases, returnRate, inflationRate) : 0;
            Map<String, Object> spReserve = input.containsKey("spouseReserve")
                    ? (Map<String, Object>) input.get("spouseReserve") : null;
            double[] spRes = spReserve != null ? calcReserveFV(spReserve, spRem, returnRate) : new double[]{0, 0};
            spGap = spNeed - spT1 - spRes[0] - spRes[1];
        }

        double totalReservePV = tier1PV + tier2PV + tier3PV;
        double pensionGap = needPV - totalReservePV + Math.max(0, spGap);
        int wm = remYrs * 12;
        double mr = Math.pow(1 + returnRate, 1.0 / 12) - 1;
        double monthlyPMT = pensionGap > 0 && wm > 0 ? pensionGap * mr / (Math.pow(1 + mr, wm) - 1) : 0;

        // 现金流表
        List<Map<String, Object>> cashFlow = buildCashFlow(customer, mp, lifespan, scenarioParams, expense, phases);

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("retirementAge", retAge);
        result.put("expectedLifespan", lifespan);
        result.put("totalNeedPV", needPV);
        result.put("tier1PV", tier1PV);
        result.put("tier2PV", tier2PV);
        result.put("tier3PV", tier3PV);
        result.put("totalReservePV", totalReservePV);
        result.put("pensionGap", pensionGap);
        result.put("monthlyPMT", monthlyPMT);
        result.put("monthlyPension", mp);
        result.put("annualCashFlow", cashFlow);
        return result;
    }

    private int getExpectedLifespan(String gender, String health) {
        JsonNode params = adminConfig.getActuarialParams();
        int base = "male".equals(gender)
                ? params.get("baseLifeExpectancy").get("male").asInt()
                : params.get("baseLifeExpectancy").get("female").asInt();
        int adj = params.get("healthLifespanAdjustmentYears").has(health)
                ? params.get("healthLifespanAdjustmentYears").get(health).asInt() : 0;
        return base + adj;
    }

    private int[] getPhaseAges(int retirementAge, String health, int lifespan) {
        int activeEnd, semiEnd;
        switch (health) {
            case "good" -> { activeEnd = 78; semiEnd = 83; }
            case "poor" -> { activeEnd = 72; semiEnd = 77; }
            default ->     { activeEnd = 75; semiEnd = 80; }
        }
        return new int[]{
                retirementAge,
                Math.min(activeEnd, lifespan),
                Math.min(semiEnd, lifespan),
                lifespan
        };
    }

    private double calcMonthlyPension(int age, String gender, String ssType, int yearsPaid,
                                       double monthlyIncome, double ssContributionBase,
                                       int retirementAge, String cityCode) {
        CityConfigEntity city = cityConfig.getByCode(cityCode);
        int remainingYears = Math.max(0, retirementAge - age);
        int totalYears = yearsPaid + remainingYears;
        if ("none".equals(ssType)) return 0;

        if ("resident".equals(ssType)) {
            double monthly = ssContributionBase * 0.08 / 12;
            double bal = monthly * 12 * yearsPaid * Math.pow(1 + 0.03, remainingYears / 2.0);
            return city.getResidentBasicPension().doubleValue() + bal / 139;
        }

        double ssBase = Math.min(Math.max(ssContributionBase, city.getSsWageFloor().doubleValue()),
                city.getSsWageCeiling().doubleValue());
        double avgWage = cityConfig.getProjectedSocialAvgWage(cityCode, CURRENT_YEAR, CURRENT_YEAR + remainingYears);
        double ci = Math.min(Math.max(ssBase / city.getSocialAvgWageMonthly().doubleValue(), 0.6), 3.0);
        double basicPension = avgWage * (1 + ci) / 2 * totalYears * 0.01;

        double rate = pensionPolicy.getAccountInterestRate(CURRENT_YEAR);
        double mr = Math.pow(1 + rate, 1.0 / 12) - 1;
        int wm = remainingYears * 12;
        double mc = ssBase * 0.08;
        double futureBal = mc * yearsPaid * 12 * Math.pow(1 + rate, remainingYears)
                + (wm > 0 ? mc * (Math.pow(1 + mr, wm) - 1) / mr : 0);

        Integer divisor = pensionPolicy.getAnnuityDivisor(retirementAge);
        int div = divisor != null ? divisor : 139;
        double personal = futureBal / div;

        double occ = 0;
        if ("civil_servant".equals(ssType)) {
            double mo = ssBase * 0.12;
            double occFV = wm > 0 ? mo * (Math.pow(1 + mr, wm) - 1) / mr : 0;
            occ = occFV / div;
        }
        return basicPension + personal + occ;
    }

    private double calcNeedPV(Map<String, Object> expense, int[] phases, double returnRate, double inflationRate) {
        String medTier = (String) expense.getOrDefault("medicalTier", "mid");
        String leisTier = (String) expense.getOrDefault("leisureTier", "mid");
        double med = "low".equals(medTier) ? 1 : "mid".equals(medTier) ? 2.5 : 5;
        double leis = "low".equals(leisTier) ? 1 : "mid".equals(leisTier) ? 2.5 : 4;

        double monthlyLiving = toDouble(expense.get("monthlyLiving"));
        double otherAnnual = toDouble(expense.get("otherAnnual"));
        double activeRes = toDouble(expense.get("activeMonthlyResidence"));
        double semiNursing = toDouble(expense.get("semiCareMonthlyNursing"));
        double fullNursing = toDouble(expense.get("fullCareMonthlyNursing"));

        double activeMo = activeRes + 1000 * med + 1000 * leis + monthlyLiving + otherAnnual / 12;
        double semiMo = semiNursing + 2000 * med + monthlyLiving * 0.8 + otherAnnual / 12;
        double fullMo = fullNursing + 3000 * med + monthlyLiving * 0.6;

        double pv = 0;
        int offset = 0;
        // 活跃期
        int activeYrs = Math.max(0, phases[1] - phases[0]);
        for (int y = 1; y <= activeYrs; y++) {
            pv += activeMo * 12 * Math.pow(1 + inflationRate, offset + y - 1) / Math.pow(1 + returnRate, offset + y);
        }
        offset += activeYrs;
        // 半自理期
        int semiYrs = Math.max(0, phases[2] - phases[1]);
        for (int y = 1; y <= semiYrs; y++) {
            pv += semiMo * 12 * Math.pow(1 + inflationRate, offset + y - 1) / Math.pow(1 + returnRate, offset + y);
        }
        offset += semiYrs;
        // 护理期
        int fullYrs = Math.max(0, phases[3] - phases[2]);
        for (int y = 1; y <= fullYrs; y++) {
            pv += fullMo * 12 * Math.pow(1 + inflationRate, offset + y - 1) / Math.pow(1 + returnRate, offset + y);
        }
        return pv;
    }

    private double[] calcReserveFV(Map<String, Object> reserve, int yrs, double r) {
        double mr = Math.pow(1 + r, 1.0 / 12) - 1;
        int wm = yrs * 12;
        double existFV = (toDouble(reserve.get("personalPensionBalance")) + toDouble(reserve.get("otherSavings")))
                * Math.pow(1 + r, yrs);
        double entFV = toDouble(reserve.get("enterpriseAnnuityBalance")) * Math.pow(1 + r, yrs)
                + (wm > 0 ? toDouble(reserve.get("enterpriseAnnuityMonthly")) * (Math.pow(1 + mr, wm) - 1) / mr : 0);
        double ppFV = yrs > 0 && r > 0
                ? toDouble(reserve.get("personalPensionAnnual")) * (Math.pow(1 + r, yrs) - 1) / r : 0;
        double otherFV = wm > 0
                ? toDouble(reserve.get("otherMonthlySaving")) * (Math.pow(1 + mr, wm) - 1) / mr : 0;
        return new double[]{entFV, ppFV + otherFV + existFV};
    }

    @SuppressWarnings("unchecked")
    private List<Map<String, Object>> buildCashFlow(Map<String, Object> customer, double monthlyPension,
                                                     int lifespan, Map<String, Object> scenarioParams,
                                                     Map<String, Object> expense, int[] phases) {
        int age = toInt(customer.get("age"));
        String gender = (String) customer.get("gender");
        double monthlyIncome = toDouble(customer.get("monthlyIncome"));
        int retAge = customer.containsKey("retirementAge") && customer.get("retirementAge") != null
                ? toInt(customer.get("retirementAge")) : ("male".equals(gender) ? 60 : 55);
        double returnRate = toDouble(scenarioParams.get("returnRate"));
        double wageGrowthRate = toDouble(scenarioParams.get("wageGrowthRate"));
        double inflationRate = toDouble(scenarioParams.get("inflationRate"));

        double monthlyLiving = toDouble(expense.get("monthlyLiving"));
        double activeRes = toDouble(expense.get("activeMonthlyResidence"));
        double semiNursing = toDouble(expense.get("semiCareMonthlyNursing"));
        double fullNursing = toDouble(expense.get("fullCareMonthlyNursing"));

        List<Map<String, Object>> rows = new ArrayList<>();
        double bal = 0;
        for (int i = 0; i <= lifespan - age; i++) {
            int curAge = age + i;
            int yr = CURRENT_YEAR + i;
            boolean retired = curAge >= retAge;
            String phase = !retired ? "工作期"
                    : curAge < phases[1] ? "活跃期"
                    : curAge < phases[2] ? "半自理期" : "护理期";
            double salary = retired ? 0 : monthlyIncome * 12 * Math.pow(1 + wageGrowthRate, i);
            double pension = retired ? monthlyPension * 12 : 0;
            double retExp = 0;
            if (retired) {
                double base = "活跃期".equals(phase) ? activeRes + monthlyLiving
                        : "半自理期".equals(phase) ? semiNursing + monthlyLiving * 0.8
                        : fullNursing + monthlyLiving * 0.6;
                retExp = base * 12 * Math.pow(1 + inflationRate, Math.max(0, curAge - retAge));
            }
            double net = salary + pension - retExp;
            bal = bal * (1 + returnRate) + net;

            Map<String, Object> row = new LinkedHashMap<>();
            row.put("year", yr);
            row.put("age", curAge);
            row.put("phase", phase);
            row.put("salaryIncome", salary);
            row.put("pensionIncome", pension);
            row.put("tier2Income", 0);
            row.put("tier3Income", 0);
            row.put("totalIncome", salary + pension);
            row.put("retirementExpense", retExp);
            row.put("netCashFlow", net);
            row.put("cumulativeBalance", bal);
            rows.add(row);
        }
        return rows;
    }

    private int toInt(Object obj) {
        if (obj instanceof Number n) return n.intValue();
        return 0;
    }

    private double toDouble(Object obj) {
        if (obj instanceof Number n) return n.doubleValue();
        return 0;
    }

    private boolean toBool(Object obj) {
        if (obj instanceof Boolean b) return b;
        return false;
    }
}
