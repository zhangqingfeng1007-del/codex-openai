package com.aix.actuarial.controller;

import com.aix.actuarial.service.InsuranceNeedsService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/internal")
public class InsuranceController {

    private final InsuranceNeedsService insuranceService;

    public InsuranceController(InsuranceNeedsService insuranceService) {
        this.insuranceService = insuranceService;
    }

    @PostMapping("/calc/insurance/needs")
    public Map<String, Object> calcInsuranceNeeds(@RequestBody Map<String, Object> input) {
        Map<String, Object> result = insuranceService.calcInsuranceNeeds(input);
        return Map.of("success", true, "data", result);
    }
}
