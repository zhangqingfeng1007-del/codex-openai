package com.aix.actuarial.controller;

import com.aix.actuarial.config.AdminConfigService;
import com.aix.actuarial.config.CityConfigService;
import com.aix.actuarial.config.PensionPolicyService;
import com.aix.actuarial.model.entity.CityConfigEntity;
import org.springframework.web.bind.annotation.*;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/internal/config")
public class ConfigController {

    private final CityConfigService cityConfig;
    private final AdminConfigService adminConfig;
    private final PensionPolicyService pensionPolicy;

    public ConfigController(CityConfigService cityConfig, AdminConfigService adminConfig, PensionPolicyService pensionPolicy) {
        this.cityConfig = cityConfig;
        this.adminConfig = adminConfig;
        this.pensionPolicy = pensionPolicy;
    }

    @GetMapping("/cities")
    public Map<String, Object> getCityList() {
        List<Map<String, Object>> cities = cityConfig.getAll().stream()
                .map(c -> {
                    Map<String, Object> m = new LinkedHashMap<>();
                    m.put("code", c.getCode());
                    m.put("name", c.getName());
                    m.put("tier", c.getTier());
                    m.put("isEstimated", c.getIsEstimated());
                    m.put("isOverseas", c.getIsOverseas() != null && c.getIsOverseas());
                    return m;
                })
                .collect(Collectors.toList());
        return Map.of("success", true, "data", cities);
    }

    @GetMapping("/city/{code}")
    public Map<String, Object> getCityByCode(@PathVariable String code) {
        CityConfigEntity city = cityConfig.getByCode(code);
        Map<String, Object> data = new LinkedHashMap<>();
        data.put("code", city.getCode());
        data.put("name", city.getName());
        data.put("tier", city.getTier());
        data.put("socialAvgWageMonthly", city.getSocialAvgWageMonthly());
        data.put("socialAvgWageGrowthRate", city.getSocialAvgWageGrowthRate());
        data.put("ssWageFloor", city.getSsWageFloor());
        data.put("ssWageCeiling", city.getSsWageCeiling());
        data.put("residentBasicPension", city.getResidentBasicPension());
        data.put("civilServantTransitionCoeff", city.getCivilServantTransitionCoeff());
        data.put("dataYear", city.getDataYear());
        data.put("isEstimated", city.getIsEstimated());
        return Map.of("success", true, "data", data);
    }

    @GetMapping("/scenario-params")
    public Map<String, Object> getScenarioParams() {
        return Map.of("success", true, "data", adminConfig.getScenarioParams());
    }

    @GetMapping("/expense-defaults")
    public Map<String, Object> getExpenseDefaults() {
        return Map.of("success", true, "data", adminConfig.getRetirementExpenseDefaults());
    }

    @GetMapping("/annuity-divisor/{age}")
    public Map<String, Object> getAnnuityDivisor(@PathVariable int age) {
        Integer divisor = pensionPolicy.getAnnuityDivisor(age);
        if (divisor == null) {
            return Map.of("success", true, "data", Map.of("divisor", (Object) null, "message", "计发月数待延迟退休政策公布后更新"));
        }
        return Map.of("success", true, "data", Map.of("divisor", divisor));
    }
}
