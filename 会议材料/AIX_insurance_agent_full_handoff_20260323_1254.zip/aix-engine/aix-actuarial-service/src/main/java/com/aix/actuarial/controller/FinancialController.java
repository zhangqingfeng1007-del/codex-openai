package com.aix.actuarial.controller;

import com.aix.actuarial.service.FinancialScorerService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/internal")
public class FinancialController {

    private final FinancialScorerService scorer;

    public FinancialController(FinancialScorerService scorer) {
        this.scorer = scorer;
    }

    @PostMapping("/calc/financial/score")
    public Map<String, Object> calcFinancialScore(@RequestBody Map<String, Object> input) {
        Map<String, Object> result = scorer.calcFinancialScore(input);
        return Map.of("success", true, "data", result);
    }
}
