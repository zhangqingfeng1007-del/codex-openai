package com.aix.actuarial.config;

import com.aix.actuarial.repository.PensionPolicyRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class PensionPolicyService {

    private final PensionPolicyRepository repo;
    private final ObjectMapper mapper = new ObjectMapper();

    public PensionPolicyService(PensionPolicyRepository repo) {
        this.repo = repo;
    }

    private JsonNode getSection(String key) {
        return repo.findById(key)
                .map(e -> {
                    try { return mapper.readTree(e.getPolicyData()); }
                    catch (Exception ex) { throw new RuntimeException("政策配置解析失败: " + key, ex); }
                })
                .orElseThrow(() -> new IllegalStateException("政策配置不存在: " + key));
    }

    /**
     * 根据退休年龄查计发月数
     */
    @Cacheable(value = "pensionPolicy", key = "'annuityDivisor_' + #retirementAge")
    public Integer getAnnuityDivisor(int retirementAge) {
        JsonNode table = getSection("annuityDivisorTable");
        for (JsonNode row : table) {
            if (row.get("age").asInt() == retirementAge) {
                return row.get("months").asInt();
            }
        }
        return null;
    }

    /**
     * 获取指定年度的个人账户记账利率
     */
    public double getAccountInterestRate(int year) {
        JsonNode rates = getSection("pensionAccountInterestRates");
        JsonNode entry = rates.get(String.valueOf(year));
        if (entry != null) {
            return entry.get("rate").asDouble();
        }
        return 0.0397; // 默认最近一期
    }

    /**
     * 根据出生年份、性别查法定退休年龄
     */
    public double getLegalRetirementAge(int birthYear, String gender, String femaleIdentityType) {
        JsonNode table = getSection("delayedRetirementTable");
        String key;
        if ("male".equals(gender)) {
            key = "male_employee";
        } else if ("cadre".equals(femaleIdentityType)) {
            key = "female_cadre";
        } else {
            key = "female_worker";
        }
        JsonNode groupTable = table.get(key);
        if (groupTable == null) return "male".equals(gender) ? 60.0 : 55.0;

        JsonNode entry = groupTable.get(String.valueOf(birthYear));
        if (entry == null) entry = groupTable.get("default");
        if (entry != null) return entry.get("retirementAge").asDouble();
        return "male".equals(gender) ? 60.0 : 55.0;
    }

    /**
     * 获取缴费比例
     */
    @Cacheable(value = "pensionPolicy", key = "'contributionRates'")
    public JsonNode getContributionRates() {
        return getSection("contributionRates");
    }
}
