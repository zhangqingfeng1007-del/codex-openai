package com.aix.actuarial.service;

import com.aix.actuarial.config.AdminConfigService;
import com.aix.actuarial.config.CityConfigService;
import com.aix.actuarial.model.entity.CityConfigEntity;
import com.fasterxml.jackson.databind.JsonNode;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class EducationCalculatorService {

    private final CityConfigService cityConfig;
    private final AdminConfigService adminConfig;

    // 路径→各阶段学校类型映射
    private static final Map<String, Map<String, String>> PATH_STAGES = Map.of(
            "A", Map.of("preschool", "public", "primary", "public", "junior", "public", "senior", "public", "university", "domestic_public", "graduate", "domestic_public"),
            "B", Map.of("preschool", "public", "primary", "public", "junior", "public", "senior", "public", "university", "domestic_public", "graduate", "overseas_us"),
            "C", Map.of("preschool", "private", "primary", "private", "junior", "private", "senior", "private_top", "university", "domestic_public", "graduate", "overseas_us"),
            "D", Map.of("preschool", "private", "primary", "private", "junior", "private", "senior", "private_top", "university", "overseas_us", "graduate", "overseas_us")
    );

    private static final Map<String, List<String>> PATH_INTERESTS = Map.of(
            "A", List.of("sports", "tutoring"),
            "B", List.of("sports", "arts", "language", "travel", "tutoring"),
            "C", List.of("sports", "arts", "academic", "tech", "tutoring"),
            "D", List.of("sports", "arts", "language", "travel")
    );

    private static final Map<String, Integer> STAGE_AGE = Map.of(
            "preschool", 3, "primary", 6, "junior", 12, "senior", 15, "university", 18, "graduate", 22
    );
    private static final Map<String, Integer> STAGE_DUR = Map.of(
            "preschool", 3, "primary", 6, "junior", 3, "senior", 3, "university", 4, "graduate", 3
    );
    private static final List<String> ALL_STAGES = List.of("preschool", "primary", "junior", "senior", "university", "graduate");

    // 基础年费用表（简化版，与admin-config中interestCategories配合）
    private static final Map<String, Map<String, Double>> ANNUAL_COST_BASE = new LinkedHashMap<>();
    static {
        ANNUAL_COST_BASE.put("preschool", Map.of("public", 12000.0, "private", 80000.0));
        ANNUAL_COST_BASE.put("primary", Map.of("public", 5000.0, "private", 60000.0));
        ANNUAL_COST_BASE.put("junior", Map.of("public", 8000.0, "private", 80000.0));
        ANNUAL_COST_BASE.put("senior", Map.of("public", 10000.0, "private_top", 120000.0));
        ANNUAL_COST_BASE.put("university", Map.of("domestic_public", 25000.0, "overseas_us", 350000.0));
        ANNUAL_COST_BASE.put("graduate", Map.of("domestic_public", 30000.0, "overseas_us", 400000.0));
    }

    public EducationCalculatorService(CityConfigService cityConfig, AdminConfigService adminConfig) {
        this.cityConfig = cityConfig;
        this.adminConfig = adminConfig;
    }

    @SuppressWarnings("unchecked")
    public Map<String, Object> calcEducation(Map<String, Object> input) {
        String cityCode = (String) input.get("cityCode");
        List<Map<String, Object>> children = (List<Map<String, Object>>) input.get("children");
        CityConfigEntity city = cityConfig.getByCode(cityCode);

        double tierMult = switch (city.getTier()) {
            case 1 -> 1.0;
            case 2 -> 0.75;
            default -> 0.55;
        };

        double inflRate = input.containsKey("eduInflationRate")
                ? toDouble(input.get("eduInflationRate")) : 0.05;
        int currentYear = java.time.Year.now().getValue();

        JsonNode savingsRate = adminConfig.getEducationSavingsRate();
        JsonNode interestCatConfig = adminConfig.getInterestCategories();

        List<Map<String, Object>> childResults = new ArrayList<>();
        double familyAcademicTotal = 0, familyInterestTotal = 0;
        double monthlyTargetCons = 0, monthlyTargetAgg = 0;

        for (Map<String, Object> child : children) {
            int childAge = toInt(child.get("age"));
            String path = child.containsKey("educationPath") ? (String) child.get("educationPath") : "A";
            Map<String, String> stageMap = PATH_STAGES.getOrDefault(path, PATH_STAGES.get("A"));

            List<Map<String, Object>> stages = new ArrayList<>();
            for (String stage : ALL_STAGES) {
                int startAge = STAGE_AGE.get(stage);
                int dur = STAGE_DUR.get(stage);
                int alreadyDone = Math.max(0, childAge - startAge);
                if (alreadyDone >= dur) continue;
                int remaining = dur - Math.max(0, alreadyDone);
                String schoolType = stageMap.getOrDefault(stage, "public");
                double annualCost = getAnnualCost(stage, schoolType, tierMult);
                int yearsUntilStart = Math.max(0, startAge - childAge);
                double totalCost = 0;
                for (int y = 0; y < remaining; y++) {
                    totalCost += annualCost * Math.pow(1 + inflRate, yearsUntilStart + y);
                }
                stages.add(Map.of(
                        "stage", stage, "schoolType", schoolType,
                        "remainingYears", remaining, "annualCost", annualCost,
                        "totalCost", totalCost, "startYear", currentYear + yearsUntilStart
                ));
            }

            double academicTotal = stages.stream().mapToDouble(s -> toDouble(s.get("totalCost"))).sum();

            // 兴趣培养
            List<String> interestCats = PATH_INTERESTS.getOrDefault(path, List.of());
            List<Map<String, Object>> interests = new ArrayList<>();
            for (String cat : interestCats) {
                JsonNode catNode = interestCatConfig.get(cat);
                if (catNode == null) continue;
                double annualCost = catNode.get("annualCost").asDouble() * tierMult;
                String untilStage = catNode.get("defaultUntilStage").asText();
                int untilAge = STAGE_AGE.get(untilStage) + STAGE_DUR.get(untilStage);
                int remainYrs = Math.max(0, untilAge - childAge);
                double totalCost = 0;
                for (int y = 0; y < remainYrs; y++) totalCost += annualCost * Math.pow(1 + inflRate, y);
                interests.add(Map.of("category", cat, "annualCost", annualCost, "untilStage", untilStage, "totalCost", totalCost));
            }

            double interestTotal = interests.stream().mapToDouble(i -> toDouble(i.get("totalCost"))).sum();
            double totalCost = academicTotal + interestTotal;

            int univEndAge = 22;
            int monthsToSave = Math.max(1, (univEndAge - childAge) * 12);
            double mc = pmtCalc(totalCost, savingsRate.get("conservative").asDouble(), monthsToSave);
            double ma = pmtCalc(totalCost, savingsRate.get("aggressive").asDouble(), monthsToSave);

            Map<String, Object> childResult = new LinkedHashMap<>();
            childResult.put("childId", child.get("id"));
            childResult.put("educationPath", path);
            childResult.put("stages", stages);
            childResult.put("interests", interests);
            childResult.put("academicTotal", academicTotal);
            childResult.put("interestTotal", interestTotal);
            childResult.put("totalCost", totalCost);
            childResult.put("monthlyTargetConservative", mc);
            childResult.put("monthlyTargetAggressive", ma);
            childResults.add(childResult);

            familyAcademicTotal += academicTotal;
            familyInterestTotal += interestTotal;
            monthlyTargetCons += mc;
            monthlyTargetAgg += ma;
        }

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("children", childResults);
        result.put("familyAcademicTotal", familyAcademicTotal);
        result.put("familyInterestTotal", familyInterestTotal);
        result.put("familyTotal", familyAcademicTotal + familyInterestTotal);
        result.put("monthlyTargetConservative", monthlyTargetCons);
        result.put("monthlyTargetAggressive", monthlyTargetAgg);
        return result;
    }

    private double getAnnualCost(String stage, String schoolType, double tierMult) {
        Map<String, Double> stageTable = ANNUAL_COST_BASE.getOrDefault(stage, Map.of());
        double cost = stageTable.getOrDefault(schoolType, stageTable.getOrDefault("public", 0.0));
        return cost * tierMult;
    }

    private double pmtCalc(double fv, double rateAnnual, int months) {
        if (months <= 0) return 0;
        double r = rateAnnual / 12;
        if (r == 0) return fv / months;
        return fv * r / (Math.pow(1 + r, months) - 1);
    }

    private int toInt(Object obj) {
        if (obj instanceof Number n) return n.intValue();
        return 0;
    }

    private double toDouble(Object obj) {
        if (obj instanceof Number n) return n.doubleValue();
        return 0;
    }
}
