package com.aix.actuarial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cache.annotation.EnableCaching;

@SpringBootApplication
@EnableCaching
public class AixActuarialApplication {
    public static void main(String[] args) {
        SpringApplication.run(AixActuarialApplication.class, args);
    }
}
