package com.aix.actuarial.model.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "pension_policy")
public class PensionPolicyEntity {
    @Id
    @Column(name = "section_key")
    private String sectionKey;

    @Column(name = "policy_data", columnDefinition = "json")
    private String policyData;

    private String description;
}
