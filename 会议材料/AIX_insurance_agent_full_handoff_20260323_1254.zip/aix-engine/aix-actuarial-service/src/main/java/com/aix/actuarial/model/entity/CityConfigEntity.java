package com.aix.actuarial.model.entity;

import jakarta.persistence.*;
import lombok.Data;
import java.math.BigDecimal;

@Data
@Entity
@Table(name = "city_config")
public class CityConfigEntity {
    @Id
    private String code;
    private String name;
    private Integer tier;

    @Column(name = "social_avg_wage_monthly")
    private BigDecimal socialAvgWageMonthly;

    @Column(name = "social_avg_wage_growth_rate")
    private BigDecimal socialAvgWageGrowthRate;

    @Column(name = "ss_wage_floor")
    private BigDecimal ssWageFloor;

    @Column(name = "ss_wage_ceiling")
    private BigDecimal ssWageCeiling;

    @Column(name = "resident_basic_pension")
    private BigDecimal residentBasicPension;

    @Column(name = "civil_servant_transition_coeff")
    private BigDecimal civilServantTransitionCoeff;

    @Column(name = "monthly_cost")
    private BigDecimal monthlyCost;

    @Column(name = "data_year")
    private Integer dataYear;

    @Column(name = "is_estimated")
    private Boolean isEstimated;

    @Column(name = "is_overseas")
    private Boolean isOverseas;
}
