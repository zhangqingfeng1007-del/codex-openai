package com.aix.actuarial.service;

import com.aix.actuarial.model.entity.ProductEntity;
import com.aix.actuarial.repository.ProductRepository;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

@Service
public class RuleEngineService {

    private final ProductRepository productRepo;
    private final ObjectMapper mapper = new ObjectMapper();

    public RuleEngineService(ProductRepository productRepo) {
        this.productRepo = productRepo;
    }

    public Map<String, Object> runRuleEngine(Map<String, Object> input) {
        int customerAge = toInt(input.get("customerAge"));
        double pensionGap = toDouble(input.get("pensionGap"));
        double educationGap = toDouble(input.get("educationGap"));
        int financialScore = toInt(input.get("financialScore"));
        double tier3PV = toDouble(input.get("tier3PV"));
        double totalNeedPV = toDouble(input.get("totalNeedPV"));
        boolean hasChildren = toBool(input.get("hasChildren"));
        boolean hasSpouse = toBool(input.get("hasSpouse"));
        double lifeInsuranceGap = toDouble(input.get("lifeInsuranceGap"));
        double criticalIllnessGap = toDouble(input.get("criticalIllnessGap"));

        Set<String> tags = new LinkedHashSet<>();
        Map<String, String> tagReasons = new LinkedHashMap<>();

        if (pensionGap > 0) {
            tags.add("pension");
            tagReasons.put("pension", String.format("养老缺口 %.0f 万元，需补充养老储备", pensionGap / 10000));
        }
        if (totalNeedPV > 0 && tier3PV / totalNeedPV < 0.2) {
            tags.add("pension");
            tagReasons.putIfAbsent("pension", String.format("第三支柱仅覆盖养老需求 %.0f%%，建议补充", tier3PV / totalNeedPV * 100));
        }
        if (educationGap > 0) {
            tags.add("education");
            tagReasons.put("education", String.format("子女教育总费用 %.0f 万元，建议专项储备", educationGap / 10000));
        }
        if (financialScore < 60) {
            tags.add("protection");
            tagReasons.put("protection", String.format("财务评分 %d 分，家庭风险保障不足，建议优先补齐", financialScore));
        }
        if (hasChildren || hasSpouse) {
            tags.add("life");
            String who = hasChildren && hasSpouse ? "配偶及子女" : hasChildren ? "子女" : "配偶";
            if (lifeInsuranceGap > 0) {
                tagReasons.put("life", String.format("家庭有%s，寿险缺口 %.0f 万元，需补充保障", who, lifeInsuranceGap / 10000));
            } else {
                tagReasons.put("life", String.format("家庭有%s，经济支柱需寿险/重疾险保障", who));
            }
        }
        if (criticalIllnessGap > 0) {
            tags.add("protection");
            tagReasons.putIfAbsent("protection", String.format("重疾保障缺口 %.0f 万元，建议优先配置重疾险", criticalIllnessGap / 10000));
        }
        if (hasChildren || customerAge > 35 || financialScore < 75) {
            tags.add("medical");
            if (hasChildren) tagReasons.put("medical", "家庭有子女，医疗费用风险高，建议补充住院医疗保障");
            else if (customerAge > 35) tagReasons.put("medical", String.format("年龄 %d 岁，医疗风险上升，建议配置百万医疗险", customerAge));
            else tagReasons.put("medical", "财务评分偏低，医疗费用可能对家庭财务造成冲击");
        }

        List<String> matchedTags = new ArrayList<>(tags);

        // 查产品并匹配
        List<ProductEntity> allProducts = getActiveProducts();
        List<Map<String, Object>> candidates = allProducts.stream()
                .filter(p -> customerAge >= p.getMinAge() && customerAge <= p.getMaxAge())
                .filter(p -> {
                    List<String> scenarioTags = parseJsonArray(p.getScenarioTags());
                    return scenarioTags.stream().anyMatch(tags::contains);
                })
                .sorted((a, b) -> {
                    long scoreA = parseJsonArray(a.getScenarioTags()).stream().filter(tags::contains).count();
                    long scoreB = parseJsonArray(b.getScenarioTags()).stream().filter(tags::contains).count();
                    return Long.compare(scoreB, scoreA);
                })
                .map(this::toProductMap)
                .collect(Collectors.toList());

        Map<String, Object> result = new LinkedHashMap<>();
        result.put("candidates", candidates);
        result.put("matchedTags", matchedTags);
        result.put("tagReasons", tagReasons);
        result.put("isEmpty", candidates.isEmpty());
        return result;
    }

    @Cacheable("products")
    public List<ProductEntity> getActiveProducts() {
        return productRepo.findByStatus("active");
    }

    private Map<String, Object> toProductMap(ProductEntity p) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("id", p.getId());
        m.put("name", p.getName());
        m.put("productType", p.getProductType());
        m.put("scenarioTags", parseJsonArray(p.getScenarioTags()));
        m.put("minAge", p.getMinAge());
        m.put("maxAge", p.getMaxAge());
        m.put("paymentModes", parseJsonArray(p.getPaymentModes()));
        m.put("highlights", p.getHighlights());
        m.put("status", p.getStatus());
        return m;
    }

    private List<String> parseJsonArray(String json) {
        try {
            return mapper.readValue(json, new TypeReference<List<String>>() {});
        } catch (Exception e) {
            return List.of();
        }
    }

    private int toInt(Object obj) {
        if (obj instanceof Number n) return n.intValue();
        return 0;
    }

    private double toDouble(Object obj) {
        if (obj instanceof Number n) return n.doubleValue();
        return 0;
    }

    private boolean toBool(Object obj) {
        if (obj instanceof Boolean b) return b;
        return false;
    }
}
