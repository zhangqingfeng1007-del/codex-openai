package com.aix.actuarial.model.entity;

import jakarta.persistence.*;
import lombok.Data;

@Data
@Entity
@Table(name = "product_actuarial_config")
public class ProductActuarialConfigEntity {

    @Id
    @Column(name = "product_id", length = 50)
    private String productId;

    /** 精算数据版本号，随每次定价结果输出，保证可审计、可复现 */
    @Column(name = "assumption_version", length = 20, nullable = false)
    private String assumptionVersion = "2017";

    /** 产品类型，用于精算策略选择：critical_illness / medical / annuity（预留扩展） */
    @Column(name = "product_type", length = 30, nullable = false)
    private String productType = "critical_illness";

    @Column(name = "mortality_table_m", length = 50, nullable = false)
    private String mortalityTableM = "CL1_1013_M";

    @Column(name = "mortality_table_f", length = 50, nullable = false)
    private String mortalityTableF = "CL2_1013_F";

    @Column(name = "ci_table_m", length = 50, nullable = false)
    private String ciTableM = "CI25_Male";

    @Column(name = "ci_table_f", length = 50, nullable = false)
    private String ciTableF = "CI25_Female";

    @Column(name = "pricing_rate", nullable = false)
    private Double pricingRate = 0.035;

    @Column(name = "loading_rate", nullable = false)
    private Double loadingRate = 0.25;

    @Column(name = "benefit_death", nullable = false)
    private Boolean benefitDeath = true;

    @Column(name = "benefit_ci", nullable = false)
    private Boolean benefitCi = true;

    @Column(name = "benefit_minor_ci", nullable = false)
    private Boolean benefitMinorCi = false;

    @Column(name = "benefit_waiver", nullable = false)
    private Boolean benefitWaiver = false;

    @Column(name = "benefit_multiple_ci", nullable = false)
    private Boolean benefitMultipleCi = false;

    @Column(name = "sum_assured", nullable = false)
    private Integer sumAssured = 500000;

    @Column(name = "prem_pay_period", nullable = false)
    private Integer premPayPeriod = 20;
}
