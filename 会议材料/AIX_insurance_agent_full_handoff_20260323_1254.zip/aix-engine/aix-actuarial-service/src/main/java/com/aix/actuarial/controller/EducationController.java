package com.aix.actuarial.controller;

import com.aix.actuarial.service.EducationCalculatorService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/internal")
public class EducationController {

    private final EducationCalculatorService educationCalc;

    public EducationController(EducationCalculatorService educationCalc) {
        this.educationCalc = educationCalc;
    }

    @PostMapping("/calc/education/cost")
    public Map<String, Object> calcEducationCost(@RequestBody Map<String, Object> input) {
        Map<String, Object> result = educationCalc.calcEducation(input);
        return Map.of("success", true, "data", result);
    }
}
