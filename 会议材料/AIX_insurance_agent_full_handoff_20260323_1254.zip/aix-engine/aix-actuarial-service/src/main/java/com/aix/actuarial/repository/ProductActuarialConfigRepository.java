package com.aix.actuarial.repository;

import com.aix.actuarial.model.entity.ProductActuarialConfigEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductActuarialConfigRepository
        extends JpaRepository<ProductActuarialConfigEntity, String> {
}
