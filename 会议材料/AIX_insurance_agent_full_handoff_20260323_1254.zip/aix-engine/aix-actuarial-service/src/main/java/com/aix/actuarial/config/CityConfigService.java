package com.aix.actuarial.config;

import com.aix.actuarial.model.entity.CityConfigEntity;
import com.aix.actuarial.repository.CityConfigRepository;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.List;

@Service
public class CityConfigService {

    private final CityConfigRepository repo;

    public CityConfigService(CityConfigRepository repo) {
        this.repo = repo;
    }

    @Cacheable("cityConfig")
    public List<CityConfigEntity> getAll() {
        return repo.findAll();
    }

    public CityConfigEntity getByCode(String code) {
        return repo.findById(code)
                .orElseGet(() -> repo.findById("other").orElseThrow(
                        () -> new IllegalArgumentException("城市编码不存在: " + code)
                ));
    }

    public List<CityConfigEntity> getByTier(int tier) {
        return repo.findByTier(tier);
    }

    /**
     * 推算退休年份时的社平工资
     */
    public double getProjectedSocialAvgWage(String cityCode, int currentYear, int retireYear) {
        CityConfigEntity city = getByCode(cityCode);
        int years = retireYear - currentYear;
        return city.getSocialAvgWageMonthly().doubleValue()
                * Math.pow(1 + city.getSocialAvgWageGrowthRate().doubleValue(), years);
    }
}
