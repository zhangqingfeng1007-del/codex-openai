package com.aix.actuarial.config;

import com.aix.actuarial.repository.AdminConfigRepository;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

@Service
public class AdminConfigService {

    private final AdminConfigRepository repo;
    private final ObjectMapper mapper = new ObjectMapper();

    public AdminConfigService(AdminConfigRepository repo) {
        this.repo = repo;
    }

    private JsonNode getSection(String key) {
        return repo.findById(key)
                .map(e -> {
                    try { return mapper.readTree(e.getConfigData()); }
                    catch (Exception ex) { throw new RuntimeException("配置解析失败: " + key, ex); }
                })
                .orElseThrow(() -> new IllegalStateException("配置不存在: " + key));
    }

    @Cacheable(value = "adminConfig", key = "'scenarioParams'")
    public JsonNode getScenarioParams() {
        return getSection("scenarioParams");
    }

    @Cacheable(value = "adminConfig", key = "'actuarialParams'")
    public JsonNode getActuarialParams() {
        return getSection("actuarialParams");
    }

    @Cacheable(value = "adminConfig", key = "'financialScoringRules'")
    public JsonNode getFinancialScoringRules() {
        return getSection("financialScoringRules");
    }

    @Cacheable(value = "adminConfig", key = "'educationSavingsRate'")
    public JsonNode getEducationSavingsRate() {
        return getSection("educationSavingsRate");
    }

    @Cacheable(value = "adminConfig", key = "'retirementExpenseDefaults'")
    public JsonNode getRetirementExpenseDefaults() {
        return getSection("retirementExpenseDefaults");
    }

    @Cacheable(value = "adminConfig", key = "'medicalCostData'")
    public JsonNode getMedicalCostData() {
        return getSection("medicalCostData");
    }

    @Cacheable(value = "adminConfig", key = "'interestCategories'")
    public JsonNode getInterestCategories() {
        return getSection("interestCategories");
    }
}
