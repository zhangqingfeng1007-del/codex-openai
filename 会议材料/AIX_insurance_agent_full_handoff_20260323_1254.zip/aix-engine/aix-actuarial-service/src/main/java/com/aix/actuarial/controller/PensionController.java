package com.aix.actuarial.controller;

import com.aix.actuarial.config.PensionPolicyService;
import com.aix.actuarial.service.PensionCalculatorService;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.Map;

@RestController
@RequestMapping("/internal")
public class PensionController {

    private final PensionCalculatorService pensionCalc;
    private final PensionPolicyService pensionPolicy;

    public PensionController(PensionCalculatorService pensionCalc, PensionPolicyService pensionPolicy) {
        this.pensionCalc = pensionCalc;
        this.pensionPolicy = pensionPolicy;
    }

    @PostMapping("/calc/pension/gap")
    public Map<String, Object> calcPensionGap(@RequestBody Map<String, Object> input) {
        Map<String, Object> result = pensionCalc.calcPension(input);
        return Map.of("success", true, "data", result);
    }

    @SuppressWarnings("unchecked")
    @PostMapping("/calc/pension/retirement-age")
    public Map<String, Object> calcRetirementAge(@RequestBody Map<String, Object> input) {
        // 前端发送 {"customer":{"age":35,"gender":"male",...}}
        Map<String, Object> customer = (Map<String, Object>) input.get("customer");
        if (customer == null) customer = input; // 兼容直接传参

        int age = ((Number) customer.get("age")).intValue();
        int birthYear = LocalDate.now().getYear() - age;
        String gender = (String) customer.get("gender");
        String femaleIdentityType = (String) customer.get("femaleIdentityType");
        double retAge = pensionPolicy.getLegalRetirementAge(birthYear, gender, femaleIdentityType);
        return Map.of("success", true, "data", Map.of("legalRetirementAge", retAge));
    }
}
