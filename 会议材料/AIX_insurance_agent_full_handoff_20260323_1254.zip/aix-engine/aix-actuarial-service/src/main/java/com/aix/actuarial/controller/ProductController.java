package com.aix.actuarial.controller;

import com.aix.actuarial.service.RuleEngineService;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/internal")
public class ProductController {

    private final RuleEngineService ruleEngine;

    public ProductController(RuleEngineService ruleEngine) {
        this.ruleEngine = ruleEngine;
    }

    @PostMapping("/report/products")
    public Map<String, Object> getProducts(@RequestBody Map<String, Object> input) {
        // 从前端报告请求体中提取规则引擎参数
        Map<String, Object> ruleInput = extractRuleInput(input);
        Map<String, Object> result = ruleEngine.runRuleEngine(ruleInput);
        return Map.of("success", true, "data", result);
    }

    @SuppressWarnings("unchecked")
    private Map<String, Object> extractRuleInput(Map<String, Object> body) {
        Map<String, Object> pension = body.containsKey("pensionResult") ? (Map<String, Object>) body.get("pensionResult") : Map.of();
        Map<String, Object> edu = body.containsKey("educationResult") ? (Map<String, Object>) body.get("educationResult") : Map.of();
        Map<String, Object> fs = body.containsKey("financialScore") ? (Map<String, Object>) body.get("financialScore") : Map.of();
        Map<String, Object> customer = body.containsKey("customer") ? (Map<String, Object>) body.get("customer") : Map.of();
        Map<String, Object> ins = body.containsKey("insuranceNeedsResult") ? (Map<String, Object>) body.get("insuranceNeedsResult") : Map.of();

        java.util.List<?> children = customer.containsKey("children") ? (java.util.List<?>) customer.get("children") : java.util.List.of();

        return Map.ofEntries(
                Map.entry("customerAge", toInt(customer.getOrDefault("age", 35))),
                Map.entry("pensionGap", toDouble(pension.getOrDefault("pensionGap", 0))),
                Map.entry("educationGap", toDouble(edu.getOrDefault("familyTotal", 0))),
                Map.entry("financialScore", toInt(fs.getOrDefault("total", 60))),
                Map.entry("tier3PV", toDouble(pension.getOrDefault("tier3PV", 0))),
                Map.entry("totalNeedPV", toDouble(pension.getOrDefault("totalNeedPV", 0))),
                Map.entry("hasChildren", !children.isEmpty()),
                Map.entry("hasSpouse", Boolean.TRUE.equals(customer.get("hasSpouse"))),
                Map.entry("lifeInsuranceGap", toDouble(ins.getOrDefault("lifeInsuranceGap", 0))),
                Map.entry("criticalIllnessGap", toDouble(ins.getOrDefault("criticalIllnessGap", 0))),
                Map.entry("medicalGap", toDouble(ins.getOrDefault("medicalGap", 0)))
        );
    }

    private int toInt(Object obj) {
        if (obj instanceof Number n) return n.intValue();
        return 0;
    }

    private double toDouble(Object obj) {
        if (obj instanceof Number n) return n.doubleValue();
        return 0;
    }
}
