# AIX 保险智能体 — 完整开发规范 v4.1

> 本文档面向开发组或开发 AI，包含所有必要信息可直接开发，无需查阅其他文档。
> 更新日期：2026-03-22
> 本次更新（v4.1）：品牌区改为蓝色文字 AIx、首页层级确立（AIx + 保险智能体 + 人人都是保险专家）、
> 旧 HomePage 降级为测算引擎内部入口、预算分配接口正式入 store、路由 target 全面收口、验收清单补全

---

## 第一章 项目背景与目标

### 1.1 公司定位

保险科技公司，愿景"让普通人成为保险专家"。
核心资产：1万+款结构化保险产品数据库（责任/费率/现金价值/病种/核保规则）。

> **本项目不是从零构建保险数据，而是基于公司既有产品主数据、责任标准库和精算能力，分阶段建设保险智能体系统。**

### 1.2 产品定位（v4.0 收口）

**产品名称**：保险智能体
**产品定位**：以 AI 对话为核心的保险规划和推荐系统，而非流程式测算后台工具

核心体验原则（参考 ChatGPT 首页交互哲学）：
- 首页唯一焦点是"开始对话"
- 欢迎态：居中欢迎语 + 居中大输入框 + 快捷建议（位于输入框下方）
- 对话态：消息流 + 底部固定输入栏
- 极简首页，不出现流程导航式结构
- 任何规划类需求先走"二选一路由"，不直接进入长问卷

### 1.3 用户类型

| 类型 | 典型场景 | 当前阶段优先级 |
|------|---------|-------------|
| **个人用户** | 咨询保险知识、分析保险需求、获取保险产品推荐 | P0，第一阶段主要对象 |
| **企业用户（B端）** | 产品研发人员、销售人员 | P2，第二阶段开发 |

### 1.4 开发目标与分阶段策略

**第一阶段（当前开发重点）：**
- 交互：文字 + 语音 + 图片识别三种输入
- 产品：重疾险（aix_category_id=6001）× 全量在售产品
- 端：桌面网页 + 手机网页（响应式）
- 具备完整的需求分析、预算测算、产品评分、精算报告能力

**第二阶段（后续扩展）：**
- 险种：寿险/身故险 → 增额终身寿/分红险 → 百万医疗险
- 用户：开放 B 端企业用户
- 性能：高并发支持、CDN、分库分表

---

## 第二章 系统架构

### 2.1 完整系统架构图

```
╔══════════════════════════════════════════════════════════════════════╗
║                        用户（浏览器）                                 ║
║  文字输入 / 语音输入（ASR）/ 图片上传                                  ║
╚════════════════════════╤═════════════════════════════════════════════╝
                         │ HTTP / SSE / WebSocket
╔════════════════════════▼═════════════════════════════════════════════╗
║                     Nginx 反向代理（:80）                             ║
║  /api/*  →  BFF     /health  →  BFF     其余  →  前端静态资源         ║
╚═══════╤════════════════════════════════════════════════╤═════════════╝
        │                                                │
╔═══════▼═══════════════════════╗       ╔═══════════════▼═════════════╗
║   前端 React SPA（Vite）       ║       ║  BFF  Node.js Express :3001  ║
║                               ║       ║                              ║
║  ┌──────────────────────────┐ ║       ║  路由：                       ║
║  │  保险智能体首页 ChatPage  │ ║       ║  POST /api/chat/stream       ║
║  │  ┌─────────┐             │ ║       ║    → SSE 代理 AI :8000       ║
║  │  │ 欢迎态  │ 居中输入框   │ ║       ║  GET  /api/asr/token         ║
║  │  │ 对话态  │ 底部输入栏   │ ║       ║    → 阿里云 NLS Token        ║
║  │  └─────────┘             │ ║       ║  /api/actuarial/*            ║
║  │  NeedsReportCard         │ ║       ║    → 精算服务 :8080           ║
║  │  ProductRecommendCard    │ ║       ║  /api/admin/*                ║
║  │  RouteCard               │ ║       ║    → 管理后台 API             ║
║  └──────────────────────────┘ ║       ║                              ║
║  ┌──────────────────────────┐ ║       ║  JWT 鉴权 / AES 加密          ║
║  │  AIX 测算引擎（Module1~7)│ ║       ║  会话管理 / 客户档案           ║
║  │  基本信息→财务→需求→结果  │ ║       ╚══════════╤═══════════════════╝
║  └──────────────────────────┘ ║                  │
║  Zustand store（持久化）        ║       ╔══════════▼═══════════════════╗
╚═══════════════════════════════╝       ║   AI 服务 FastAPI :8000       ║
                                        ║                               ║
                                        ║  chat.py（SSE 对话编排）       ║
                                        ║    ↓ Function Calling × 6     ║
                                        ║  chat_engine.py               ║
                                        ║    Kimi k2.5 系统提示词        ║
                                        ║    工具：show_options          ║
                                        ║         update_core_memory    ║
                                        ║         start_needs_analysis  ║
                                        ║         generate_needs_report ║
                                        ║         save_recall_summary   ║
                                        ║         report_issue          ║
                                        ║    ↓                          ║
                                        ║  needs_analysis.py            ║
                                        ║    需求报告 + 预算测算          ║
                                        ║    ↓                          ║
                                        ║  product_scorer.py            ║
                                        ║    7维度评分 + 精算性价比       ║
                                        ║    ↓ 调用精算服务              ║
                                        ║  memory_store.py              ║
                                        ║    对话记忆（MySQL）            ║
                                        ╚══════════╤════════════════════╝
                         ┌─────────────────────────┘
          ╔══════════════▼══════════════╗     ╔══════════════════════════╗
          ║  精算服务 Java Spring :8080  ║     ║  MySQL 8.0               ║
          ║                             ║     ║  aix_engine 库：          ║
          ║  PricingController          ║     ║  ├─ cmb_product（1万+款） ║
          ║  ActuarialPricingEngine     ║     ║  ├─ chat_sessions         ║
          ║  PVFB/GP 公式               ║     ║  ├─ core_memory           ║
          ║  → fairPremium（元/年）      ║     ║  ├─ actuarial_qx_table   ║
          ║                             ║     ║  ├─ actuarial_ci_table   ║
          ║  GET /actuarial/fair-price  ║     ║  └─ product_actuarial_   ║
          ║    ?productId&age&gender    ║     ║       config              ║
          ╚═════════════════════════════╝     ╚══════════════════════════╝
```

### 2.2 核心对话链路（SSE 全事件流）

```
用户消息
  │
  ▼
BFF POST /api/chat/stream
  │
  ▼
AI 服务 chat.py ──→ Kimi k2.5 API（Function Calling）
  │
  ├─ [chunk]              流式文字片段 → 前端逐字渲染
  ├─ [options]            多选项让用户选择
  ├─ [route_options]      规划路由卡（填写信息/对话规划）
  ├─ [needs_report]       需求报告摘要卡
  ├─ [product_recommendations]  推荐结果（Top3 + 预算分配）
  ├─ [done]               流结束
  └─ [error]              错误兜底

product_recommendations payload：
{
  top3: ProductRecommendation[]    // 3款产品 + 评分 + 性价比
  conclusion: string               // 选购建议
  risk_notes: string[]             // 风险说明
  budget_allocation: {             // 预算分配建议
    by_person: { self, spouse, children }
    by_coverage: { critical_illness, medical, life }
    rationale: string
  }
}
```

### 2.3 架构概览（文字版）

```
前端（React + Tailwind）
  ├── 保险智能体首页（ChatPage — 唯一入口，ChatGPT 风格）
  │     ├── 欢迎态：居中标题 + 居中输入框 + 快捷建议
  │     └── 对话态：消息流 + 底部输入栏
  └── AIX 保险智能测算引擎（结构化规划入口，由路由卡跳转）
        └── Module1~7（基本信息 → 推荐结果）

BFF（Node.js 3001）
  └── 会话管理、客户档案、ASR Token、精算代理

AI 服务（Python FastAPI 8000）
  ├── chat.py（SSE 对话编排）
  ├── chat_engine.py（Kimi 工具定义 + 系统提示词）
  ├── needs_analysis.py（需求报告 + 预算测算）
  ├── product_scorer.py（产品评分）
  └── memory_store.py（记忆系统）

精算服务（Java Spring Boot 8080）
  └── 费率计算、精算模型（PVFB/GP 公式）
```

### 2.2 两条规划路径

用户提出规划类需求时，AI 先弹出路由卡：

```
用户: "帮我规划家庭保险"
  ↓
路由卡（show_options route_options）
  ├── 填写信息规划 → navigate(aix-engine) → 跳转至 AIX 测算引擎 Module1
  └── 对话规划 → continue_chat → AI 继续对话收集信息
```

**关键约束（强制）：**
- `填写信息规划` = 复用现有 AIX 保险智能测算引擎，不是新建独立页面
- 路由 target key = `"aix-engine"`，前端 `TARGET_MODULE_MAP["aix-engine"] = 1`（Module1 基本信息）
- 两条路径共用同一套底层 schema（见第五章）
- 路由卡只做交互分流，不做业务逻辑分流

---

## 第三章 首页交互规范

### 3.1 品牌区设计规范

**左上角品牌标识：蓝色文字 AIx**
- 使用蓝色（`#2B7FE0`，蓝天感：清爽、可信、专业）
- "AI" 字重 bold，"x" 字重 light + italic
- 不使用公司 PNG 图片 Logo
- 不做厚重科技风、发光、描边、立体、复杂阴影
- 不偏紫，不荧光蓝

**视觉层级（从重到轻）：**
1. 页面中心主标题：**保险智能体**（h1，加粗，黑色，最大字号）
2. 主标题下方副标：**人人都是保险专家**（蓝色中等字重）
3. 引导文案：**有任何保险问题，尽管问我**（小字灰色）
4. 左上角品牌标识：**AIx**（蓝色，比页面主标题小，不抢焦点）
5. MainLayout header 中心：**chat 模式下隐藏**（由页面主体的 h1 承担）

**绝对禁止：**
- 把"人人都是保险专家"放进输入框 placeholder
- 把"人人都是保险专家"放成顶部导航主标题
- 把"人人都是保险专家"和"今天想了解什么？"并列成双主标题
- 口号堆叠（≤ 3 层文案，超出删减次要文案）

### 3.2 首页设计哲学

参考 ChatGPT 首页的核心原则：
- 首页是"开始对话"的起点，不是功能菜单
- 极简：顶部品牌区（仅 AIx 标识）+ 居中主区（标题 + 口号 + 输入框 + 快捷建议）+ 底部免责
- 快捷建议是"我可以这样问"的示范，不是模块菜单
- 顶部品牌区不抢占中心交互焦点

### 3.3 欢迎态布局

```
┌─────────────────────────────────────┐
│  AIx                       [⚙️]    │  ← MainLayout header：左 AIx，右操作
│  （蓝色文字，点击返回首页）          │    chat 模式不显示中心标题
├─────────────────────────────────────┤
│                                     │
│                                     │
│          保险智能体                  │  ← 页面主标题 h1（最重要）
│      人人都是保险专家                │  ← 品牌口号，蓝色，副标
│      有任何保险问题，尽管问我         │  ← 引导文案，灰色小字
│                                     │
│  ┌─────────────────────────────┐    │
│  │  有问题，尽管问…           🎤│    │  ← 核心焦点：居中大输入框
│  │  ─────────────────────────  │    │
│  │  🖼️  🎤                  ↑  │    │
│  └─────────────────────────────┘    │
│                                     │
│  [帮我规划家庭保障]                  │  ← 快捷建议（输入框下方）
│  [帮我推荐适合的重疾险]              │    自然问题式，非功能菜单
│  [帮我看看现有保单]                  │
│  [保险一般怎么配置更合理]            │
│                                     │
└─────────────────────────────────────┘
│  AI建议仅供参考，不构成投保依据      │  ← 底部免责
```

### 3.4 对话态布局

```
┌─────────────────────────────────────┐
│  🛡 保险智能体              [新对话]│  ← 紧凑顶栏
├─────────────────────────────────────┤
│  用户消息                           │
│              AI 回复 + 卡片         │
│  用户消息                           │
│              AI 回复                │
│                              [滚动] │
├─────────────────────────────────────┤
│  [🖼️][🎤] 输入框              [↑]  │  ← 底部固定输入栏
└─────────────────────────────────────┘
```

### 3.5 旧 HomePage 的处理方式

**`HomePage` 降级为 AIX 测算引擎内部入口，不再作为总站默认首页。**

- `App.tsx` 的 `default` case 返回 `<ChatPage />`（原为 `<HomePage />`）
- ErrorBoundary onReset 跳转 `'chat'`（原为 `'home'`）
- `activeModule === 'home'` 仍可从测算引擎内部访问
- 任何"返回首页"操作 → `setActiveModule('chat')`

### 3.6 快捷建议内容（自然问题式）

快捷建议必须像用户会主动说出口的问题，不是功能模块入口。

| 标签 | 触发文字 | 说明 |
|------|---------|------|
| 帮我规划家庭保障 | 帮我规划家庭保险方案 | 触发路由卡（填写信息/对话规划） |
| 帮我推荐适合的重疾险 | 帮我推荐一款适合我的重疾险 | 进入需求收集对话 |
| 帮我看看现有保单 | 帮我做一个保单体检分析 | 保单分析流程 |
| 保险一般怎么配置更合理 | 保险一般怎么配置更合理 | 知识问答 |

---

## 第四章 规划路由逻辑

### 4.1 触发条件

当用户表达以下任一意图时，AI **必须**先弹出路由卡，不得直接进入对话收集：
- 帮我规划家庭保险
- 帮我做保险方案
- 帮我配家庭保障
- 帮我设计保障方案
- 想做一个保险规划
- 家庭保障规划

### 4.2 路由卡 SSE 事件

```json
{
  "event": "route_options",
  "data": {
    "route_options": [
      {"label": "填写信息规划", "action": "navigate", "target": "aix-engine"},
      {"label": "对话规划", "action": "continue_chat"}
    ]
  }
}
```

### 4.3 前端路由映射（ChatPage.tsx）

```typescript
// 模块 key → activeModule 值映射
const TARGET_MODULE_MAP = {
  'aix-engine':   1,   // 填写信息规划 → AIX 测算引擎 Module1（基本信息）
  'policy-check': 3,   // 保单体检 → Module3（保障需求）
}
```

### 4.4 填写信息规划说明

**填写信息规划 = 跳转至现有 AIX 保险智能测算引擎的 Module1（基本信息）入口**

- 不是新建 `/family-plan` 独立页面
- 不是未来待开发的新表单系统
- 就是现有 AIX 引擎的结构化信息采集流程
- 后续如需替换问卷 schema，在 AIX 引擎内部替换即可

**禁止**在代码、注释、文档中把 `aix-engine` 描述为 `/family-plan` 路由路径。

---

## 第五章 统一规划 Schema

### 5.1 核心原则

两条路径（填写信息规划 / 对话规划）必须共用同一套底层 schema：

| 字段 | 对话规划 | 填写信息规划 |
|------|---------|------------|
| age | AI 对话收集 | Module1 表单填写 |
| gender | AI 对话收集 | Module1 表单填写 |
| budget_annual | AI 推算/收集 | Module2 财务状况填写 |
| family_structure | AI 对话收集 | Module1 家庭情况填写 |
| primary_concern | AI 对话收集 | Module3 保障需求填写 |

不允许出现：一条路径支持某字段，另一条路径不支持的情况。

### 5.2 信息采集三个核心目的

每个字段必须能解释其用途，字段存在必须至少服务一个目的：

1. **了解客户，生成建议** — 用于 AI 生成保险购买建议
2. **结构化检索** — 将客户信息转为条件，在产品库中搜索符合要求的产品
3. **预算测算/分配** — 当客户不给预算时，根据信息推算预算和分配建议

| 字段 | 生成建议 | 产品检索 | 预算测算 |
|------|---------|---------|---------|
| age | ✅ | ✅（费率随年龄变化） | ✅（年龄影响保费基准） |
| gender | ✅ | ✅（男女费率不同） | ✅ |
| annual_income | ✅ | — | ✅（收入×5%~10%推算预算） |
| budget_annual | ✅ | ✅（价格筛选） | — |
| family_structure | ✅ | ✅（被保人数量） | ✅（家庭成员数影响总预算） |
| health_status | ✅ | ✅（核保规则过滤） | — |
| primary_concern | ✅ | ✅（病种覆盖过滤） | — |
| preferred_company | — | ✅（公司过滤） | — |

---

## 第六章 预算能力规范

### 6.1 设计原则

用户不愿或无法给出预算时，系统必须主动推算，而不是把"先告诉我预算"作为前提。

### 6.2 数据结构

```typescript
interface NeedsReportSummary {
  age: number
  gender: string
  primary_concern: string
  family_structure: string
  health_status?: string
  // 预算字段
  budget_annual?: number              // 实际使用的年保费（元）
  budget_mode?: 'user_stated' | 'estimated'
  budget_annual_estimated_min?: number  // 测算下限（estimated 模式）
  budget_annual_estimated_max?: number  // 测算上限（estimated 模式）
  budget_annual_recommended?: number    // 推荐预算
}
```

### 6.3 预算测算规则

| 情景 | budget_mode | 处理逻辑 |
|------|------------|---------|
| 用户明确给出预算 | user_stated | 直接使用用户值 |
| 用户给收入未给预算 | estimated | min=年收入×5%，max=年收入×10%，recommended=年收入×7% |
| 收入也不知道 | estimated | 根据职业/城市估算中等收入，同上逻辑；AI 说明"根据您的情况估算" |

### 6.4 预算分配能力（已入接口，待 UI 实现）

系统不仅测算总预算，还要回答：**预算优先给谁、优先配置什么保障**。

当前状态：接口已定义入 `useStore.ts`，`ProductRecommendationsPayload` 已包含 `budget_allocation?` 字段。

```typescript
// useStore.ts — 已实现
interface BudgetAllocation {
  by_person?: {
    self?: number       // 本人（元/年）
    spouse?: number     // 配偶（元/年）
    children?: number   // 子女合计（元/年）
  }
  by_coverage?: {
    critical_illness?: number  // 重疾险（元/年）
    medical?: number           // 医疗险（元/年）
    life?: number              // 寿险（元/年）
    other?: number             // 其他（元/年）
  }
  rationale?: string   // 分配说明文字
}

interface ProductRecommendationsPayload {
  top3: ProductRecommendation[]
  conclusion?: string
  risk_notes?: string[]
  budget_allocation?: BudgetAllocation  // ← 已入接口
}
```

**后续 AI 侧实现要求：**
- `generate_needs_report` 工具增加 `budget_allocation` 输出字段
- Python `chat.py` 在 `product_recommendations` SSE payload 中填充分配建议
- 前端 `RecommendationConclusionCard` 展示分配逻辑

**分配逻辑参考：**
- 有孩家庭：本人重疾优先 → 配偶重疾 → 子女医疗
- 单身：本人重疾 + 医疗
- 预算 <5000/年：先保重疾，医疗次之
- 预算 >15000/年：重疾 + 医疗 + 寿险均可配置

---

## 第七章 推荐结果展示规范

### 7.1 卡片化结构（5张）

推荐结果必须使用结构化卡片，禁止退回 Markdown 表格：

| 卡片 | 组件 | 内容 |
|------|------|------|
| 1 | NeedsReportCard | 用户画像摘要（年龄/性别/预算/核心诉求/家庭） |
| 2×3 | RecommendationCard | 每产品：排名徽章 + 亮点标签 + 保费 + 性价比 + 评分条 |
| 4 | ProductCompareCard | 维度对比（横向可滑动，非表格墙） |
| 5 | RecommendationConclusionCard | 选购建议 + 预算逻辑 |
| 6 | RiskDisclosureCard | 风险说明（单次赔付/数据库边界/核保限制） |

### 7.2 NeedsReportCard 展示规则

- 默认折叠，显示摘要 chips（年龄/性别/诉求/家庭）
- 点击展开 2 列字段详情
- 预算显示规则：
  - `user_stated`：直接显示值，如 `8,000元/年`
  - `estimated`：显示区间，如 `4,000~8,000元/年（测算）`

### 7.3 ProductCompareCard 要求

- 不得产生"表格墙"视觉感
- 横向可滑动（overflow-x-auto）
- 每个字段用进度条+数字展示，而非纯文字对比

---

## 第八章 AI 工具规范

### 8.1 工具清单

| 工具 | 触发时机 |
|------|---------|
| show_options（普通） | 需要用户选择时（健康/家庭/收入/险种等） |
| show_options（route_options） | **仅在**用户提出规划类意图时 |
| update_core_memory | 用户透露重要个人信息时立即调用 |
| start_needs_analysis | 用户明确想要推荐产品时 |
| generate_needs_report | 收集足够信息后（至少：年龄+性别+家庭情况） |
| save_recall_summary | 对话将要结束时 |
| report_issue | 产品不在库中/超出能力范围时静默调用 |

### 8.2 generate_needs_report 必传字段

```python
# 必填
age: int
gender: "male" | "female"

# 预算字段（重要：必须填 budget_mode）
budget_mode: "user_stated" | "estimated"
budget_annual: int              # 实际使用的预算值
budget_annual_estimated_min: int  # estimated 模式填写
budget_annual_estimated_max: int  # estimated 模式填写
budget_annual_recommended: int    # estimated 模式填写

# 可选但建议填写
family_structure: str
health_status: str
primary_concern: str
preferred_company: str
```

### 8.3 route_options 标准格式

```json
[
  {"label": "填写信息规划", "action": "navigate", "target": "aix-engine"},
  {"label": "对话规划",     "action": "continue_chat"}
]
```

**target 说明：** `aix-engine` 是前端模块 key，映射到 AIX 测算引擎 Module1（基本信息），不是 URL 路径。

---

## 第九章 架构灵活性约束

### 9.1 问卷逻辑配置化

- 字段定义、显示顺序、必填规则尽量从配置读取
- AIX 测算引擎和对话规划共用同一份 schema 定义
- 后续替换问卷文件时，不需要同时修改 ChatPage 和 Module1~7

### 9.2 预算逻辑模块化

- 预算测算逻辑集中在 `needs_analysis.py` 的 `build_report_summary()` 中
- 不在 ChatPage、表单页、推荐页、Prompt 多处重复实现预算逻辑
- `budget_mode` / `budget_annual` / `budget_annual_recommended` 是唯一来源

### 9.3 推荐链路结构化

```
标准化 profile (NeedsReportSummary)
  → 检索条件 (fetch_products_for_scoring)
  → 评分 (score_products)
  → 丰富化 (enrich_recommendations)
  → 前端展示 (ProductRecommendCard)
```

- 每个环节输入输出明确，不靠大模型理解自然语言
- 评分参数来自 `score_breakdown`，不散落在 Prompt 中

### 9.4 前端展示与业务解耦

- UI 组件（ChatPage、卡片）可以独立更新样式
- `NeedsReportSummary`、`ProductRecommendationsPayload` 等接口尽量保持稳定
- UI 改版不应迫使后端接口重写

---

## 第十章 文件变更清单（v4.1 实施）

| 文件 | 改动 |
|------|------|
| `frontend/src/components/Logo.tsx` | 替换为蓝色文字 "AIx" 组件，移除 PNG Logo |
| `frontend/src/layouts/MainLayout.tsx` | chat 模式下隐藏 header 中心标题（由 ChatPage body h1 承担） |
| `frontend/src/modules/chat/ChatPage.tsx` | 欢迎态：移除内部顶栏、品牌层级（主标题+副标+引导语）、居中输入框 |
| `frontend/src/modules/chat/components/HomeQuickEntry.tsx` | 快捷建议改为自然问题式（帮我规划家庭保障等） |
| `frontend/src/App.tsx` | default case → `<ChatPage />`，ErrorBoundary onReset → `'chat'` |
| `frontend/src/store/useStore.ts` | 新增 `BudgetAllocation` 接口，`ProductRecommendationsPayload` 加 `budget_allocation?` |
| `frontend/src/modules/chat/components/ChatInputBar.tsx` | 新增 `variant='centered'` 模式 |
| `frontend/src/modules/chat/components/NeedsReportCard.tsx` | 支持 estimated 预算区间显示 |
| `aix-ai-service/app/services/chat_engine.py` | 路由 target=`aix-engine`，`generate_needs_report` 增预算字段，系统提示词增预算测算规则 |
| `aix-ai-service/app/services/needs_analysis.py` | `build_report_summary()` 传递预算字段到 SSE payload |

---

## 第十一章 验收清单（v4.1）

**品牌与视觉层级**
- [ ] 左上角品牌标识是蓝色文字 `AIx`（非 PNG Logo）
- [ ] 欢迎态页面主标题是**保险智能体**（居中，最大最重）
- [ ] 主标题下方是**人人都是保险专家**（蓝色，副标，不抢主标题）
- [ ] 引导语轻量，与口号不并列重复
- [ ] MainLayout header 在 chat 模式下不显示中心"保险智能体"文字（由 body h1 承担）

**首页布局**
- [ ] 欢迎态：居中主标题 + 副标 + **居中输入框**（不在底部） + 输入框下方快捷建议
- [ ] 对话态：消息流 + **底部固定输入栏**
- [ ] chat 模式下左侧边栏隐藏，全宽布局
- [ ] 首页不出现流程导航式结构
- [ ] 顶部品牌区克制，不抢中心焦点

**快捷建议**
- [ ] 快捷建议像自然问题（帮我规划家庭保障 / 帮我推荐适合的重疾险 / 帮我看看现有保单 / 保险一般怎么配置更合理）
- [ ] 不像功能模块菜单或业务入口

**路由逻辑**
- [ ] 规划类意图触发二选一路由卡（填写信息规划 / 对话规划）
- [ ] 路由卡 `target='aix-engine'`，点击跳转至 Module1 基本信息
- [ ] 代码/注释/文档/AI 示例中无 `/family-plan` 路由路径残留
- [ ] `TARGET_MODULE_MAP['aix-engine'] = 1` 且注释说明"复用 AIX 测算引擎"

**旧 HomePage**
- [ ] `App.tsx` default case 返回 `<ChatPage />`（不再是 `<HomePage />`）
- [ ] ErrorBoundary onReset 跳转 `'chat'`（不是 `'home'`）
- [ ] "返回首页"操作统一跳转 `'chat'`

**预算能力**
- [ ] `useStore.ts` 有 `BudgetAllocation` 接口定义
- [ ] `ProductRecommendationsPayload` 包含 `budget_allocation?` 字段
- [ ] `budget_mode=estimated` 时，NeedsReportCard 显示预算区间（如 `4,000~8,000元/年（测算）`）
- [ ] AI 系统提示词包含预算测算规则（年收入 5%~10%）

**推荐结果**
- [ ] 推荐结果使用结构化卡片（无 Markdown 表格）
- [ ] 5 张卡片：NeedsReportCard + RecommendationCard×3 + ProductCompareCard + ConclusionCard + RiskCard
- [ ] 代码/注释/文档无 `/family-plan` 作为路由路径的引用
- [ ] 推荐结果是结构化卡片（无 Markdown 表格）
- [ ] `budget_mode=estimated` 时，NeedsReportCard 显示预算区间
- [ ] 用户不给预算时，AI 自动推算并说明来源
- [ ] 架构支持后续替换问卷 schema

---

## 第十二章 技术栈

| 层 | 技术 |
|----|------|
| 前端 | React 18 + TypeScript + Vite + Tailwind CSS v3 + Zustand |
| BFF | Node.js + Express + MySQL2 |
| AI 服务 | Python 3.11 + FastAPI + Kimi API（Function Calling + Vision） |
| 精算服务 | Java 17 + Spring Boot |
| 数据库 | MySQL 8.0 |
| 消息队列 | RabbitMQ |
| 反向代理 | Nginx |
| 容器化 | Docker Compose |

---

## 第十三章 一期险种边界

| 类别 | 支持状态 |
|------|---------|
| 重疾险（aix_category_id=6001） | ✅ 当前版本支持 |
| 寿险/身故险 | 🔜 二期第一批 |
| 增额终身寿/分红险 | 🔜 二期第二批 |
| 百万医疗险 | 🔜 二期第三批（最难） |

**禁止对未收录险种估算保费或给出推荐，即使有通用知识也不能替代数据库数据。**

---

## 第十四章 数据库主数据

- 产品主数据库：`aix_engine.products`（1万+款）
- 当前使用：`product_status = 'RELEASED'`（在售产品）
- 精算模型：`product_actuarial_config` + 死亡率表 + 重疾发生率表
- 费率计算：通过精算服务（Java 8080）代理计算

---

*历史版本：v3.0~v3.6 → 见 docs/ 历史文档*
