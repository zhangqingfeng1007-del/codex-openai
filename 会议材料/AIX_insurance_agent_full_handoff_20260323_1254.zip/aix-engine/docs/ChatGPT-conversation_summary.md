# AIX Insurance Intelligent Agent Project Conversation Summary

Date: March 20, 2026 (New York timezone)

This file summarizes the key interactions between the user and assistant in this conversation. It does not include any internal reasoning or hidden messages; only the visible conversation content is summarized.

## Background and Goal

The user is a product manager at an insurance technology company whose vision is to enable every person to become an insurance expert. The company possesses a comprehensive Chinese insurance industry database including standardized insurance products, company data (solvency, service scores), actuarial models (earnings calculations, mortality/incidence rates), and plans to incorporate socioeconomic data. They aim to develop an insurance intelligent agent that combines large language models (LLMs) with accurate data and actuarial models. The project uses the existing AIX insurance intelligent measurement engine and two internal documents: “AIX Insurance Intelligent Measurement Engine IT Development Document V2.0” and “AIX Intelligent Agent Requirements and Development Document V3.3”.

## Main Discussion Points

- **Product Planning and Development Documents** – The assistant reviewed the two internal documents and produced two formal documents:
  1. **AIX保险智能体产品规划书_V1.0.md** – a product planning document that outlined the project background, goals, target users, scope of phase one, core product principles, module architecture (data layer, product retrieval, needs analysis, actuarial calculation, product scoring and sorting, dialogue orchestration, compliance auditing, operations and manual intervention), data governance strategies, scoring rules, risk list, milestone planning, and acceptance criteria.
  2. **AIX保险智能体开发文档_V1.0.md** – a development document describing the technical architecture (React + Node BFF + Python AI + Java actuarial services + MySQL + Nginx), the module breakdown with responsibilities, database design, API interfaces, tool calling guidelines, sprint planning, P0 bug fixes, downgrade strategies, security and compliance considerations, testing strategies, deployment, and acceptance standards.

- **Model Selection and Division of Labor** – The user asked which large models (LLMs) should be used. The assistant recommended a primary model and auxiliary models for different roles, suggesting that production should be controlled by a single high‑capability model with smaller models handling extraction and summarization tasks, and separate specialised models for speech recognition and moderation. This evolved into a detailed document describing:
  - Stage‑specific recommendations (planning, development, production).
  - Preferred models such as GPT‑5.4 (as the main agent model), gpt‑5.4‑mini (for extraction and low‑cost tasks), Kimi K2.5 or Qwen (for auxiliary review and Chinese language tasks), and Claude Opus 4.6 for planning and code review stages.
  - Emphasis on unified data and rules, auditability, and controlled model output.

- **Development Process and Governance** – The assistant provided guidelines to prevent uncontrolled code growth and maintainability issues:
  - Introduced a **task card template** requiring clear definition of module boundaries, inputs, outputs, acceptance criteria, and rollback plans before any model‑generated code changes.
  - Created a **model‑generated code review checklist** to ensure changes comply with design, avoid cross‑module contamination, remove obsolete logic, and include appropriate tests.
  - Drafted **complexity management and refactoring triggers** to monitor file and logic growth, prompt refactoring, and prevent layering of temporary patches.
  - Combined these guidelines into an **AIX intelligent agent R&D governance manual** for internal use.

- **File Packaging and Delivery** – Due to browser download restrictions, the assistant regenerated several files with English names and provided the user with direct download links.

## Memory Backup

This summary is stored in the `zqf-openclaw/codex-openai/memory_backup` directory as part of the conversation backup. It captures the visible conversation content to aid future reference and development continuity.
