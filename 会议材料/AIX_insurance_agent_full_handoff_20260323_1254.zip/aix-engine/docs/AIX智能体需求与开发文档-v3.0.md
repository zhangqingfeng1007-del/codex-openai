# AIX 保险智能体 — 需求与开发文档 v3.0

> 版本：v3.0　　更新日期：2026-03-20
> 范围：在 v2.0 基础上，围绕用户架构图进行正式智能体设计，补充引擎层、数据层规划和技术实现方案。

---

## 一、产品定位与目标

**公司愿景：** 让普通人成为保险专家
**核心资产：** 1万+款结构化保险产品数据库（责任/费率/现金价值/病种/核保规则）
**当前阶段：** 测试版（PoC），使用10款重疾险样本验证 AI 对话+产品库可行性

### 用户类型

| 类型 | 典型场景 |
|------|---------|
| **个人用户** | 咨询保险知识、了解自身需求、获取产品推荐和对比方案 |
| **企业用户（B端）** | 产品开发人员查市场行情、销售人员查产品责任和利益、公司查竞品 |

> 测试版优先完成**个人用户**完整链路，B端为 P2。

---

## 二、系统总体架构

### 2.1 架构分层（基于用户架构图，补充完善）

```
┌─────────────────────────────────────────────────────────────────┐
│                        智能交互层                                 │
│   Web / H5 对话界面（React）                                       │
│   • 流式文字输出   • 卡片快捷选项   • 会话持久化（本地+服务端）        │
└─────────────────────┬───────────────────────────────────────────┘
                      ↕ HTTP / SSE
┌─────────────────────┴───────────────────────────────────────────┐
│                    API 网关层（BFF）                               │
│   Node.js/Express                                                │
│   • 请求路由   • Session 管理   • 用户认证（JWT）                    │
│   • SSE 代理（前端↔Python）   • 限流 / Token 计费（预留）             │
└──────────────┬──────────────────────────┬───────────────────────┘
               ↓                          ↓
┌──────────────┴──────┐    ┌─────────────┴──────────────────────┐
│    精算引擎           │    │           AI 智能体引擎              │
│  Java Spring Boot   │    │         Python FastAPI             │
│                     │    │                                    │
│  • 养老规划精算       │    │  ┌─────────────────────────────┐  │
│  • 教育规划精算       │    │  │       大模型赋能模块           │  │
│  • 保障需求测算       │    │  │  ① 长期记忆（L1核心+L2摘要）   │  │
│  • 财务评分          │    │  │  ② RAG规则注入               │  │
│  • 产品评分计算       │    │  │  ③ 问题/缺陷收集              │  │
└─────────────────────┘    │  └─────────────────────────────┘  │
                           │                                    │
                           │  ┌─────────────────────────────┐  │
                           │  │     需求分析引擎               │  │
                           │  │  • 问卷对话驱动（Function Call）│  │
                           │  │  • 需求分析模块（年龄/预算/      │  │
                           │  │    健康/家庭结构/已有保障）      │  │
                           │  │  • 生成结构化保险需求报告        │  │
                           │  └─────────────────────────────┘  │
                           │                                    │
                           │  ┌─────────────────────────────┐  │
                           │  │   产品评分与推荐引擎            │  │
                           │  │  • 结合需求报告+客户偏好        │  │
                           │  │  • 从产品库检索候选产品         │  │
                           │  │  • 评分计算 → 输出 Top 3       │  │
                           │  └─────────────────────────────┘  │
                           │                                    │
                           │  ┌─────────────────────────────┐  │
                           │  │     Kimi 大模型 API           │  │
                           │  │  • 对话生成（SSE流）           │  │
                           │  │  • Function Calling          │  │
                           │  │  • temperature=1 (模型要求)   │  │
                           │  └─────────────────────────────┘  │
                           └────────────────────────────────────┘
                                           ↓
┌──────────────────────────────────────────────────────────────────┐
│                          数据层                                   │
│                                                                   │
│  ┌──────────────────────────┐   ┌──────────────────────────────┐ │
│  │      保险产品数据库        │   │         社会化数据库            │ │
│  │  (my_ensure)             │   │  (aix_social，预留)           │ │
│  │                          │   │                              │ │
│  │  • 产品基本信息            │   │  • 社保/公积金数据              │ │
│  │  • 产品责任（树形结构）      │   │  • 医疗成本数据                │ │
│  │  • 责任标准值              │   │  • 教育成本数据                │ │
│  │  • 费率数据               │   │  • 经济统计数据                │ │
│  │  • 现金价值               │   │                              │ │
│  │  • 病种定义               │   │  （现阶段数据存 aix_engine     │ │
│  │  • 万能险/分红险           │   │   city_config 等表中）         │ │
│  │  • 保险公司信息            │   └──────────────────────────────┘ │
│  └──────────────────────────┘                                    │
│                                                                   │
│  ┌──────────────────────────┐   ┌──────────────────────────────┐ │
│  │      业务数据库            │   │          向量数据库（预留）      │ │
│  │  (aix_engine)            │   │  （RAG 语义检索，测试版暂不用） │ │
│  │                          │   │                              │ │
│  │  • 客户档案 profiles       │   │  • 产品知识向量索引            │ │
│  │  • 对话记忆 chat_memories  │   │  • 条款语义搜索               │ │
│  │  • 对话摘要 chat_summaries │   └──────────────────────────────┘ │
│  │  • 问题记录 chat_issues    │                                    │
│  │  • 会话 sessions          │                                    │
│  └──────────────────────────┘                                    │
└──────────────────────────────────────────────────────────────────┘

                    ┌────────────────────────────┐
                    │         管理后台             │
                    │  引擎配置 / 数据库管理 /      │
                    │  对话质量监控 / 问题处理      │
                    └────────────────────────────┘
```

### 2.2 对原架构图的补充建议

| 原图设计 | 建议补充/修改 | 原因 |
|---------|-------------|------|
| 智能交互层（双向箭头） | 增加**会话持久化**：对话历史存库，离开再回来可续接 | 当前每次回来从头开始，体验差 |
| 引擎层两个子系统 | 两个子系统之间加**状态流转**：需求分析完成后再触发评分 | 避免没收集完需求就推荐产品 |
| 大模型赋能模块 | 增加 **Tool Calling 编排层**，明确哪些工具在什么时机调用 | 现已实现4个工具，需要统一管理 |
| 数据库层 | 增加**客户数据库**（已有 profiles/memories 表）和**业务数据库** | 图中缺少这一层 |
| 管理后台 | 增加**对话质量监控**功能（查看 issues 表、评分统计） | 测试阶段最核心的反馈渠道 |
| — | 增加**API网关层（BFF）**，图中未体现 | 安全、限流、SSE代理 |

---

## 三、核心模块设计

### 3.1 大模型赋能模块（已实现）

#### ① 长期记忆（MemGPT 分层架构）

```
L1 核心记忆（每次对话必注入）
  存储于：chat_memories 表（每客户一条记录）
  字段：age, gender, budget, health, family, existing_insurance,
        recommendation_summary, purchased
  更新时机：AI 调用 update_core_memory 工具

L2 召回摘要（按需加载，最近3条）
  存储于：chat_summaries 表
  内容：上次对话的需求分析摘要 + 推荐方案要点
  更新时机：AI 调用 save_recall_summary 工具（对话末尾）
```

#### ② RAG 规则注入（关键词意图匹配）

```
app/rules/
  ├── question_rules.md    → 提问规则（一次最多问2个，不重复）
  ├── product_rules.md     → 产品规则（只推荐库中产品，防幻觉）
  └── data_rules.md        → 数据规则（数据来源层级，不编造数字）

注入逻辑：
  用户消息 → 关键词意图识别 → 叠加相关规则块 → 注入 System Prompt
  product_rules 每次必注（防止AI推荐库外产品）
```

#### ③ Function Calling 工具集

| 工具名 | 触发时机 | 作用 |
|--------|---------|------|
| `update_core_memory` | AI 获知客户新信息时 | 更新 L1 核心记忆 |
| `save_recall_summary` | 对话阶段性总结时 | 写入 L2 摘要记忆 |
| `report_issue` | 遇到无法回答/产品不在库中 | 记录到 chat_issues 表 |
| `show_options` | 需要客户做选择时 | 前端渲染卡片快捷按钮 |

#### ④ 待解决：reasoning_content 问题

Kimi k2.5 开启思考模式后，assistant 工具调用消息必须包含 `reasoning_content`。
**修复方案：** kimi_client.py 在流式收集时记录 reasoning_content，回传工具结果时一并附带。

---

### 3.2 需求分析引擎（规划中）

**目标：** 通过对话系统性收集客户信息，生成结构化的"保险需求报告"。

#### 信息收集维度

```
基础信息（必收）
  • 被保险人年龄、性别
  • 年缴保费预算
  • 保障对象（本人/配偶/子女/父母）

健康与风险（次优先）
  • 当前健康状况（是否有慢性病、手术史）
  • 职业类型（影响核保和险种选择）

家庭保障现状（重要）
  • 是否有社保/商业保险
  • 家庭结构（已婚/子女数量）

保障偏好（辅助）
  • 倾向的保险公司
  • 终身 vs 定期
  • 返还型 vs 消费型
  • 保额优先 vs 保费优先
```

#### 对话状态机

```
IDLE → 欢迎寒暄
  ↓ 用户说明需求
NEED_ANALYSIS → 系统性收集上述信息（最多5-7轮）
  ↓ 信息收集完毕（AI判断）
REPORT_GENERATED → 生成结构化需求报告 + 触发产品评分
  ↓
PRODUCT_RECOMMENDATION → 展示 Top 3 产品对比
  ↓
DETAIL_QA → 用户追问产品细节、条款解读
  ↓ 用户满意 / 决策
FOLLOW_UP → 记录推荐方案到记忆，结束或继续
```

#### 输出格式（结构化需求报告）

```json
{
  "profile": {
    "age": 35, "gender": "male", "occupation": "office",
    "health": "good"
  },
  "budget": { "annual": 8000, "flexible": true },
  "coverage_target": ["本人"],
  "existing": { "social_insurance": true, "commercial": false },
  "preferences": {
    "type": "重疾险", "term": "终身",
    "priority": "保额", "company": null
  },
  "risk_factors": [],
  "generated_at": "2026-03-20T10:00:00"
}
```

---

### 3.3 产品评分与推荐引擎（规划中）

**目标：** 基于需求报告，从产品库检索并评分，输出 Top 3 产品。

#### 评分维度与权重

| 维度 | 权重 | 数据来源 |
|------|------|---------|
| 年龄适配度（是否在投保范围） | 25% | cmb_product_coverage（投保年龄责任项） |
| 预算匹配度（年缴保费 ≤ 预算） | 25% | cmb_product_rate |
| 保障全面性（重疾种数、轻症/中症） | 20% | cmb_product_coverage |
| 等待期短（越短越好） | 10% | cmb_product.waiting_period |
| 销售状态（在售优先） | 10% | cmb_product.sale_status |
| 客户偏好匹配（保险公司/长短险） | 10% | 需求报告偏好字段 |

#### 技术实现

```python
# 1. 从 my_ensure 检索满足基本条件的产品（按年龄过滤）
# 2. 对每款产品计算加权分
# 3. 排序取 Top 3
# 4. 将结果结构化注入 LLM prompt，由 AI 做自然语言解读和推荐

# 当前状态：步骤1已实现（product_search.py）
# 待实现：步骤2-3评分计算模块（对应架构图"产品评分计算模块"）
```

---

### 3.4 会话持久化（待实现）

**现状问题：** 用户离开聊天页面再回来，对话历史全部丢失。

**解决方案：**

```
客户端：
  • 每次对话完成，将 messages 数组存入 localStorage（按 profileId 区分）
  • 进入 ChatPage 时读取 localStorage，恢复历史消息展示

服务端（可选，更可靠）：
  • 新增 chat_sessions 表：session_id, profile_id, messages (JSON), updated_at
  • BFF 提供 GET /api/v1/chat/session 和 POST /api/v1/chat/session/save
  • 前端进入时拉取，离开时保存
```

**优先级：** P0 立即修复（用户体验关键路径）

---

## 四、数据库设计

### 4.1 已有表（aix_engine）

| 表名 | 状态 | 用途 |
|------|------|------|
| `profiles` | ✅ 已用 | 客户档案（AES-256 加密存储） |
| `chat_memories` | ✅ 已用 | L1 核心记忆（每客户唯一） |
| `chat_summaries` | ✅ 已用 | L2 历史对话摘要 |
| `chat_issues` | ✅ 已用 | AI 无法回答的问题/缺失产品记录 |
| `sessions` | ✅ 已用 | 精算业务会话 |

### 4.2 待新增表

```sql
-- 对话历史持久化
CREATE TABLE chat_history (
  id         VARCHAR(36)  NOT NULL DEFAULT (UUID()),
  profile_id VARCHAR(36)  NOT NULL,
  session_id VARCHAR(36)  NOT NULL,
  messages   JSON         NOT NULL,   -- [{role, content, options?}]
  created_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uk_session (session_id),
  KEY idx_profile (profile_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 结构化需求报告
CREATE TABLE insurance_need_reports (
  id          VARCHAR(36)  NOT NULL DEFAULT (UUID()),
  profile_id  VARCHAR(36)  NOT NULL,
  report_json JSON         NOT NULL,   -- 结构化需求报告
  top3_json   JSON,                    -- 推荐Top3产品
  created_at  DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_profile (profile_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
```

### 4.3 my_ensure 产品库 — 字段注意事项

基于 Excel 说明文档（20260105），以下关键字段说明：

| 字段 | 说明 | 注意 |
|------|------|------|
| `product_id` | 招行产品ID (varchar, utf8mb4_**general**_ci) | ⚠️ 与关联表 collation 不一致，JOIN 时需 `COLLATE` |
| `effective_date` | 产品生效日期（同产品可有多个版本） | 查询时取最新版本 |
| `product_id` vs `product_sub_id` | 有子计划时费率表用 sub_id，无子计划两者相同 | 费率查询注意区分 |
| `standard_content` | 责任项的实际值（如"终身"、"0-17周岁"） | 在 cmb_product_coverage 表 |
| `disease_category` | 重大疾病/轻症/中症分类 | 在 cmb_product_disease 表 |

**已知 Bug：collation 冲突**

```sql
-- cmb_product.product_id 是 utf8mb4_general_ci
-- cmb_product_coverage.product_id 是 utf8mb4_unicode_ci
-- JOIN 时报 Illegal mix of collations 错误

-- 修复方法：JOIN 条件加 COLLATE
ON p.product_id COLLATE utf8mb4_unicode_ci = pc.product_id
```

---

## 五、API 接口文档

### 5.1 AI 对话接口（已实现）

```
POST /api/v1/chat
Content-Type: application/json
Response: text/event-stream

Body:
{
  "messages": [{ "role": "user", "content": "..." }],
  "profile_id": "xxx"   // 可选，绑定客户档案
}

SSE 事件类型：
  chunk   → { "content": "文字片段" }
  options → { "options": ["选项1", "选项2"] }
  done    → {}
  error   → { "message": "错误信息" }
```

### 5.2 对话历史接口（待实现）

```
GET  /api/v1/chat/history?profile_id=xxx
     → 返回最近一次对话的 messages 数组

POST /api/v1/chat/history/save
     Body: { "profile_id": "xxx", "messages": [...] }
     → 保存当前对话到 chat_history 表
```

### 5.3 需求报告接口（规划中）

```
GET  /api/v1/chat/need-report?profile_id=xxx
     → 返回最新的结构化需求报告 + Top3推荐

POST /api/v1/chat/need-report
     Body: { "profile_id": "xxx", "report": {...} }
     → 保存需求报告
```

### 5.4 管理后台接口（已实现）

```
GET  /api/v1/admin/issues          → 查询问题记录列表
PATCH /api/v1/admin/issues/:id     → 标记已处理
GET  /api/v1/admin/config          → 配置管理
```

---

## 六、开发路线图

### Phase 1 — 稳定现有 PoC（当前阶段）

| 任务 | 优先级 | 状态 |
|------|--------|------|
| 修复 collation 冲突（产品查询正常） | P0 | ⚠️ 待修 |
| 修复 reasoning_content（多轮对话不卡死） | P0 | ⚠️ 待修 |
| 会话持久化（离开再回来可续接） | P0 | ⚠️ 待修 |
| 卡片快捷选项 | P1 | ✅ 已完成 |
| MemGPT 分层记忆 | P1 | ✅ 已完成 |
| RAG 规则注入 | P1 | ✅ 已完成 |
| 问题收集 Function Calling | P1 | ✅ 已完成 |
| 管理后台（issues查看） | P2 | ✅ 已完成 |

### Phase 2 — 需求分析引擎

| 任务 | 说明 |
|------|------|
| 对话状态机 | 实现 IDLE→NEED_ANALYSIS→REPORT→RECOMMENDATION 状态流转 |
| 结构化需求报告生成 | 基于对话信息生成 JSON 报告，存库 |
| 产品评分计算模块 | 基于需求报告 × 产品库，输出 Top 3 |
| 产品对比展示 | 前端展示产品对比卡片 |

### Phase 3 — 正式版功能

| 任务 | 说明 |
|------|------|
| 用户认证 + Token 计费 | 注册/登录，免费额度+付费扩充 |
| 语音输入 | 阿里云 ASR 接入 |
| 响应式优化 | 手机端完整适配 |
| B端企业模式 | 产品开发人员/销售人员场景 |
| 社会化数据库 | 社保/医疗/教育成本数据接入 |
| 向量检索（RAG升级） | 从关键词匹配升级为语义检索 |
| 防爬取机制 | 数据保护 |

---

## 七、部署说明

### 本地开发启动

```bash
cd ~/code/aix-engine

# 构建并启动所有服务
docker compose up -d

# 单独重建某个服务（修改代码后）
docker compose build ai && docker compose up -d ai
docker compose build nginx && docker compose up -d nginx

# 查看服务日志
docker logs aix-engine-ai-1 -f
docker logs aix-engine-bff-1 -f
```

### 访问地址

| 服务 | 地址 |
|------|------|
| 前端主界面 | http://localhost |
| AIX 保险顾问 | http://localhost/chat |
| 数据管理后台 | http://localhost/admin |
| Python AI 服务（内部） | http://localhost:8000 |
| BFF | http://localhost:3001 |

### 环境变量（.env）

```env
KIMI_API_KEY=sk-xxx
JWT_SECRET=xxx
MYSQL_ROOT_PASSWORD=root_secret
MYSQL_PASSWORD=aix_secret
```

---

## 八、已知问题与技术债

| 问题 | 影响 | 解决方案 |
|------|------|---------|
| collation 冲突 | 产品数据查不出来，AI 无法推荐 | JOIN 条件加 COLLATE utf8mb4_unicode_ci |
| reasoning_content 缺失 | 多轮对话遇到 Function Call 后卡死 | kimi_client.py 收集 reasoning_content 并回传 |
| 会话不持久 | 离开页面历史消息丢失 | localStorage 缓存 + DB 持久化 |
| 产品库数据少 | 只有10款样本，推荐范围窄 | 导入完整产品库 |
| 产品缓存 | 启动时查询失败会缓存空字符串，需重启才能恢复 | 改为失败时缓存 None，区分"无产品"和"查询失败" |
