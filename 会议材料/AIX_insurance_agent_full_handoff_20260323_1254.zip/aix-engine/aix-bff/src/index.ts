import express from 'express'
import cors from 'cors'
import helmet from 'helmet'
import morgan from 'morgan'
import rateLimit from 'express-rate-limit'
import dotenv from 'dotenv'
import router from './routes'
import { initMySQL } from './db/mysql'
import { jwtAuth } from './middleware/auth'
import { startCleanupScheduler } from './utils/cleanup'

dotenv.config()

const app = express()
const PORT = process.env.PORT || 3001

app.use(helmet())
app.use(cors({ origin: process.env.FRONTEND_URL || '*' }))
app.use(morgan('dev'))
app.use(express.json({ limit: '10mb' }))

// 全局限流：100 req/min
app.use('/api/v1', rateLimit({
  windowMs: 60_000,
  max: 100,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: '请求过于频繁，请稍后再试' },
}))

// 报告接口限流：5 req/min
app.use('/api/v1/report', rateLimit({
  windowMs: 60_000,
  max: 5,
  standardHeaders: true,
  legacyHeaders: false,
  message: { success: false, error: '报告生成请求过于频繁，请1分钟后再试' },
}))

// JWT认证（JWT_ENABLED=true 时生效，否则跳过）
app.use('/api/v1', jwtAuth)
app.use('/api/v1', router)

app.get('/health', async (_req, res) => {
  try {
    const pool = (await import('./db/mysql')).getPool()
    await pool.query('SELECT 1')
    res.json({ status: 'ok', version: '2.0.0', service: 'AIX-BFF', mysql: 'connected' })
  } catch (err) {
    res.status(503).json({ status: 'degraded', version: '2.0.0', service: 'AIX-BFF', mysql: 'disconnected' })
  }
})

async function bootstrap() {
  await initMySQL()
  startCleanupScheduler()
  app.listen(PORT, () => {
    console.log(`AIX BFF started on http://localhost:${PORT}`)
  })
}

bootstrap().catch(err => {
  console.error('BFF启动失败:', err)
  process.exit(1)
})

export default app
