/**
 * 审计日志工具 — §11 所有配置修改操作记录
 */
import { getPool } from '../db/mysql'
import { Request } from 'express'

export interface AuditEntry {
  action: string       // config_update, profile_delete, product_update, ...
  targetType: string   // admin_config, city_config, product, profile
  targetId?: string
  operator?: string
  beforeValue?: unknown
  afterValue?: unknown
  ipAddress?: string
}

export async function writeAuditLog(entry: AuditEntry): Promise<void> {
  try {
    const pool = getPool()
    await pool.query(
      `INSERT INTO audit_log (action, target_type, target_id, operator, before_value, after_value, ip_address)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [
        entry.action,
        entry.targetType,
        entry.targetId || null,
        entry.operator || 'system',
        entry.beforeValue ? JSON.stringify(entry.beforeValue) : null,
        entry.afterValue ? JSON.stringify(entry.afterValue) : null,
        entry.ipAddress || null,
      ]
    )
  } catch (err) {
    // Audit logging should never block the main operation
    console.error('[Audit] Failed to write audit log:', err)
  }
}

/**
 * Helper: extract client IP and operator from request
 */
export function auditFromReq(req: Request): { operator: string; ipAddress: string } {
  const authReq = req as Request & { user?: { sub?: string } }
  return {
    operator: authReq.user?.sub || 'anonymous',
    ipAddress: (req.headers['x-real-ip'] as string) || req.ip || 'unknown',
  }
}
