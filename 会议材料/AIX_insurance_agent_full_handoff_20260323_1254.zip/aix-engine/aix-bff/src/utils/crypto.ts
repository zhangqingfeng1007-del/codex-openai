/**
 * AES-256-GCM 加解密工具 — §11 敏感数据加密存储
 *
 * 配置: AES_SECRET_KEY 环境变量（32字节hex = 64字符）
 * 如不设置，使用明文存储（开发模式），并在控制台警告
 *
 * 加密输出格式: base64(iv + authTag + ciphertext)
 */
import crypto from 'crypto'

const IV_LEN = 12  // GCM recommended
const TAG_LEN = 16

function getKey(): Buffer | null {
  const hex = process.env.AES_SECRET_KEY
  if (!hex || hex.length !== 64) return null
  return Buffer.from(hex, 'hex')
}

let warned = false

export function encrypt(plaintext: string): string {
  const key = getKey()
  if (!key) {
    if (!warned) {
      console.warn('[Crypto] AES_SECRET_KEY not configured (64 hex chars). Storing data in plaintext.')
      warned = true
    }
    return plaintext
  }

  const iv = crypto.randomBytes(IV_LEN)
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv)
  const encrypted = Buffer.concat([cipher.update(plaintext, 'utf8'), cipher.final()])
  const tag = cipher.getAuthTag()

  // Pack: iv(12) + tag(16) + ciphertext(N)
  const packed = Buffer.concat([iv, tag, encrypted])
  return `enc:${packed.toString('base64')}`
}

export function decrypt(data: string): string {
  if (!data.startsWith('enc:')) {
    // Not encrypted (legacy or dev mode), return as-is
    return data
  }

  const key = getKey()
  if (!key) {
    throw new Error('AES_SECRET_KEY required to decrypt data')
  }

  const packed = Buffer.from(data.slice(4), 'base64')
  if (packed.length < IV_LEN + TAG_LEN + 1) {
    throw new Error('Invalid encrypted data')
  }

  const iv = packed.subarray(0, IV_LEN)
  const tag = packed.subarray(IV_LEN, IV_LEN + TAG_LEN)
  const ciphertext = packed.subarray(IV_LEN + TAG_LEN)

  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv)
  decipher.setAuthTag(tag)
  const decrypted = Buffer.concat([decipher.update(ciphertext), decipher.final()])

  return decrypted.toString('utf8')
}

/**
 * Generate a random AES-256 key (for initial setup)
 */
export function generateKey(): string {
  return crypto.randomBytes(32).toString('hex')
}
