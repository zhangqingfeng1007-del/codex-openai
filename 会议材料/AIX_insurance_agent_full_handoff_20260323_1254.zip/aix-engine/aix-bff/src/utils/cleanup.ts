/**
 * 数据自动清除定时任务 — §11 会话数据90天后清除
 * 每小时检查一次，删除过期数据
 */
import { getPool } from '../db/mysql'

const RETENTION_DAYS = 90
const CHECK_INTERVAL_MS = 60 * 60 * 1000 // 1 hour

async function cleanExpiredData(): Promise<void> {
  try {
    const pool = getPool()
    const cutoff = new Date(Date.now() - RETENTION_DAYS * 24 * 60 * 60 * 1000)
    const cutoffStr = cutoff.toISOString().slice(0, 19).replace('T', ' ')

    // Clean expired sessions
    const [sessResult] = await pool.query(
      'DELETE FROM sessions WHERE expires_at < NOW() OR created_at < ?',
      [cutoffStr]
    ) as unknown as [{ affectedRows: number }]

    // Clean old profiles (based on updated_at)
    const [profResult] = await pool.query(
      'DELETE FROM profiles WHERE updated_at < ?',
      [cutoffStr]
    ) as unknown as [{ affectedRows: number }]

    // Clean old report tasks
    const [reportResult] = await pool.query(
      'DELETE FROM report_tasks WHERE created_at < ?',
      [cutoffStr]
    ) as unknown as [{ affectedRows: number }]

    // Clean old audit logs (keep 180 days for audit trail)
    const auditCutoff = new Date(Date.now() - 180 * 24 * 60 * 60 * 1000)
    const auditCutoffStr = auditCutoff.toISOString().slice(0, 19).replace('T', ' ')
    const [auditResult] = await pool.query(
      'DELETE FROM audit_log WHERE created_at < ?',
      [auditCutoffStr]
    ) as unknown as [{ affectedRows: number }]

    const total = sessResult.affectedRows + profResult.affectedRows + reportResult.affectedRows + auditResult.affectedRows
    if (total > 0) {
      console.log(`[Cleanup] Removed ${sessResult.affectedRows} sessions, ${profResult.affectedRows} profiles, ${reportResult.affectedRows} reports, ${auditResult.affectedRows} audit logs`)
    }
  } catch (err) {
    console.error('[Cleanup] Error:', err)
  }
}

let intervalId: NodeJS.Timeout | null = null

export function startCleanupScheduler(): void {
  // Run immediately on startup
  cleanExpiredData()
  // Then every hour
  intervalId = setInterval(cleanExpiredData, CHECK_INTERVAL_MS)
  console.log(`[Cleanup] Scheduler started: ${RETENTION_DAYS}-day retention, checking every hour`)
}

export function stopCleanupScheduler(): void {
  if (intervalId) {
    clearInterval(intervalId)
    intervalId = null
  }
}
