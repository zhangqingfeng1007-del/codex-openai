import { Router, Request, Response } from 'express'
import { getPool } from '../db/mysql'
import { RowDataPacket } from 'mysql2'
import { ApiResponse } from '../types'
import { readFileSync } from 'fs'
import { resolve } from 'path'
import { writeAuditLog, auditFromReq } from '../utils/audit'

const router = Router()

// ── helpers ───────────────────────────────────────────────

/** snake_case → camelCase */
function toCamel(obj: Record<string, unknown>): Record<string, unknown> {
  const out: Record<string, unknown> = {}
  for (const [k, v] of Object.entries(obj)) {
    const ck = k.replace(/_([a-z])/g, (_, c) => c.toUpperCase())
    out[ck] = v
  }
  return out
}

/** camelCase → snake_case */
function toSnake(key: string): string {
  return key.replace(/[A-Z]/g, c => '_' + c.toLowerCase())
}

// ── 静态学校数据（从JSON文件加载，结构复杂不适合扁平MySQL表） ──
let domesticSchools: unknown = null
let overseasSchools: unknown = null
function loadSchoolData() {
  // 尝试多个可能路径：本地开发 / Docker容器
  const candidates = [
    resolve(__dirname, '../../data/schools'),         // Docker: /app/dist/routes -> /app/data/schools
    resolve(__dirname, '../../../data/schools'),       // 本地: src/routes -> data/schools
  ]
  for (const base of candidates) {
    try {
      domesticSchools = JSON.parse(readFileSync(resolve(base, 'domestic-schools.json'), 'utf8'))
      overseasSchools = JSON.parse(readFileSync(resolve(base, 'overseas-schools.json'), 'utf8'))
      return
    } catch { /* try next */ }
  }
  domesticSchools = { privateHighSchools: [], domesticUniversities: [], domesticGradSchools: [] }
  overseasSchools = { countries: {} }
}
loadSchoolData()

// ── Cities ────────────────────────────────────────────────

// GET /api/v1/admin/cities
router.get('/cities', async (_req: Request, res: Response) => {
  try {
    const pool = getPool()
    const [rows] = await pool.query<RowDataPacket[]>('SELECT * FROM city_config ORDER BY code')
    const cities = rows.map(r => toCamel(r as Record<string, unknown>))
    return res.json({ success: true, data: cities } as ApiResponse)
  } catch (err: unknown) {
    return res.status(500).json({ success: false, error: String(err) } as ApiResponse)
  }
})

// PUT /api/v1/admin/cities/:code
router.put('/cities/:code', async (req: Request, res: Response) => {
  try {
    const pool = getPool()
    const fields = req.body
    const keys = Object.keys(fields).filter(k => k !== 'code')
    if (keys.length === 0) return res.json({ success: true } as ApiResponse)
    const sets = keys.map(k => `${toSnake(k)} = ?`)
    const vals = keys.map(k => fields[k])
    // Audit: capture before value
    const [before] = await pool.query<RowDataPacket[]>('SELECT * FROM city_config WHERE code = ?', [req.params.code])
    await pool.query(`UPDATE city_config SET ${sets.join(', ')} WHERE code = ?`, [...vals, req.params.code])
    const [updated] = await pool.query<RowDataPacket[]>('SELECT * FROM city_config WHERE code = ?', [req.params.code])
    const data = updated.length > 0 ? toCamel(updated[0] as Record<string, unknown>) : fields
    const { operator, ipAddress } = auditFromReq(req)
    writeAuditLog({ action: 'config_update', targetType: 'city_config', targetId: req.params.code, operator, ipAddress, beforeValue: before[0], afterValue: updated[0] })
    return res.json({ success: true, data } as ApiResponse)
  } catch (err: unknown) {
    return res.status(500).json({ success: false, error: String(err) } as ApiResponse)
  }
})

// ── Config ────────────────────────────────────────────────

// GET /api/v1/admin/config
router.get('/config', async (_req: Request, res: Response) => {
  try {
    const pool = getPool()
    const [rows] = await pool.query<RowDataPacket[]>('SELECT section_key, config_data FROM admin_config')
    const config: Record<string, unknown> = {}
    for (const row of rows) {
      const data = typeof row.config_data === 'string' ? JSON.parse(row.config_data) : row.config_data
      config[row.section_key] = data
    }
    return res.json({ success: true, data: config } as ApiResponse)
  } catch (err: unknown) {
    return res.status(500).json({ success: false, error: String(err) } as ApiResponse)
  }
})

// PATCH /api/v1/admin/config/:section
router.patch('/config/:section', async (req: Request, res: Response) => {
  try {
    const pool = getPool()
    const section = req.params.section
    const [existing] = await pool.query<RowDataPacket[]>('SELECT config_data FROM admin_config WHERE section_key = ?', [section])
    if (existing.length === 0) return res.status(404).json({ success: false, error: '配置节不存在' } as ApiResponse)
    const current = typeof existing[0].config_data === 'string' ? JSON.parse(existing[0].config_data) : existing[0].config_data
    // 对于interestCategories等完整替换，不做merge
    const merged = typeof current === 'object' && !Array.isArray(current) && typeof req.body === 'object' && !Array.isArray(req.body) && !req.body.categories
      ? { ...current, ...req.body }
      : req.body
    await pool.query('UPDATE admin_config SET config_data = ? WHERE section_key = ?', [JSON.stringify(merged), section])
    const { operator, ipAddress } = auditFromReq(req)
    writeAuditLog({ action: 'config_update', targetType: 'admin_config', targetId: section, operator, ipAddress, beforeValue: current, afterValue: merged })
    return res.json({ success: true, data: merged } as ApiResponse)
  } catch (err: unknown) {
    return res.status(500).json({ success: false, error: String(err) } as ApiResponse)
  }
})

// ── Products ──────────────────────────────────────────────

// GET /api/v1/admin/products
router.get('/products', async (_req: Request, res: Response) => {
  try {
    const pool = getPool()
    const [rows] = await pool.query<RowDataPacket[]>('SELECT * FROM products ORDER BY id')
    const products = rows.map(r => ({
      id: r.id,
      name: r.name,
      productType: r.product_type,
      scenarioTags: typeof r.scenario_tags === 'string' ? JSON.parse(r.scenario_tags) : (r.scenario_tags || []),
      minAge: r.min_age,
      maxAge: r.max_age,
      paymentModes: typeof r.payment_modes === 'string' ? JSON.parse(r.payment_modes) : (r.payment_modes || []),
      highlights: r.highlights,
      isActive: r.status === 'active',
    }))
    return res.json({ success: true, data: products } as ApiResponse)
  } catch (err: unknown) {
    return res.status(500).json({ success: false, error: String(err) } as ApiResponse)
  }
})

// POST /api/v1/admin/products
router.post('/products', async (req: Request, res: Response) => {
  try {
    const pool = getPool()
    const p = req.body
    await pool.query(
      'INSERT INTO products (id, name, product_type, scenario_tags, min_age, max_age, payment_modes, highlights) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [p.id, p.name, p.productType, JSON.stringify(p.scenarioTags || []), p.minAge || 0, p.maxAge || 99, JSON.stringify(p.paymentModes || []), p.highlights || '']
    )
    const { operator, ipAddress } = auditFromReq(req)
    writeAuditLog({ action: 'product_create', targetType: 'product', targetId: p.id, operator, ipAddress, afterValue: p })
    return res.json({ success: true, data: p } as ApiResponse)
  } catch (err: unknown) {
    return res.status(500).json({ success: false, error: String(err) } as ApiResponse)
  }
})

// PATCH /api/v1/admin/products/:id/discontinue
router.patch('/products/:id/discontinue', async (req: Request, res: Response) => {
  try {
    const pool = getPool()
    await pool.query("UPDATE products SET status = 'discontinued', discontinued_at = NOW() WHERE id = ?", [req.params.id])
    const { operator, ipAddress } = auditFromReq(req)
    writeAuditLog({ action: 'product_discontinue', targetType: 'product', targetId: req.params.id, operator, ipAddress })
    return res.json({ success: true } as ApiResponse)
  } catch (err: unknown) {
    return res.status(500).json({ success: false, error: String(err) } as ApiResponse)
  }
})

// PUT /api/v1/admin/products/:id
router.put('/products/:id', async (req: Request, res: Response) => {
  try {
    const pool = getPool()
    const p = req.body
    const [before] = await pool.query<RowDataPacket[]>('SELECT * FROM products WHERE id = ?', [req.params.id])
    await pool.query(
      'UPDATE products SET name=?, product_type=?, scenario_tags=?, min_age=?, max_age=?, highlights=? WHERE id=?',
      [p.name, p.productType, JSON.stringify(p.scenarioTags || []), p.minAge, p.maxAge, p.highlights, req.params.id]
    )
    const { operator, ipAddress } = auditFromReq(req)
    writeAuditLog({ action: 'product_update', targetType: 'product', targetId: req.params.id, operator, ipAddress, beforeValue: before[0], afterValue: p })
    return res.json({ success: true } as ApiResponse)
  } catch (err: unknown) {
    return res.status(500).json({ success: false, error: String(err) } as ApiResponse)
  }
})

// ── Schools ───────────────────────────────────────────────

// GET /api/v1/admin/schools/domestic
router.get('/schools/domestic', async (_req: Request, res: Response) => {
  return res.json({ success: true, data: domesticSchools } as ApiResponse)
})

// GET /api/v1/admin/schools/overseas
router.get('/schools/overseas', async (_req: Request, res: Response) => {
  return res.json({ success: true, data: overseasSchools } as ApiResponse)
})

// ── Chat Issues（问题反馈）────────────────────────────────

// GET /api/v1/admin/issues — 查询 AI 发现的问题列表
router.get('/issues', async (req: Request, res: Response) => {
  try {
    const pool = getPool()
    const { type, resolved, limit = '50', offset = '0' } = req.query as Record<string, string>
    const conditions: string[] = []
    const params: unknown[] = []

    if (type) { conditions.push('issue_type = ?'); params.push(type) }
    if (resolved !== undefined) { conditions.push('is_resolved = ?'); params.push(resolved === 'true' ? 1 : 0) }

    const where = conditions.length ? `WHERE ${conditions.join(' AND ')}` : ''
    const [rows] = await pool.query<RowDataPacket[]>(
      `SELECT id, profile_id, issue_type, user_query, description, is_resolved, created_at
       FROM chat_issues ${where}
       ORDER BY created_at DESC
       LIMIT ? OFFSET ?`,
      [...params, parseInt(limit), parseInt(offset)]
    )
    const [countRows] = await pool.query<RowDataPacket[]>(
      `SELECT COUNT(*) as total FROM chat_issues ${where}`,
      params
    )
    return res.json({ success: true, data: { items: rows, total: countRows[0].total } } as ApiResponse)
  } catch (err) {
    return res.status(500).json({ success: false, error: String(err) } as ApiResponse)
  }
})

// PATCH /api/v1/admin/issues/:id — 标记为已处理
router.patch('/issues/:id', async (req: Request, res: Response) => {
  try {
    const pool = getPool()
    const { id } = req.params
    await pool.query('UPDATE chat_issues SET is_resolved = 1 WHERE id = ?', [id])
    return res.json({ success: true } as ApiResponse)
  } catch (err) {
    return res.status(500).json({ success: false, error: String(err) } as ApiResponse)
  }
})

export default router
