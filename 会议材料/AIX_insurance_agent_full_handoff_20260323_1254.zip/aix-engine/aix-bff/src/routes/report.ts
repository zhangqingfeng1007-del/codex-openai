import { Router, Request, Response } from 'express'
import { javaCalc } from '../proxy/java-client'
import { proxySSE } from '../proxy/python-client'
import { ApiResponse } from '../types'
import { errorResponse } from '../types/error-codes'

// Lazy-load puppeteer to avoid crash if not installed (dev mode)
let puppeteerModule: typeof import('puppeteer') | null = null
async function getPuppeteer() {
  if (!puppeteerModule) {
    try {
      puppeteerModule = await import('puppeteer')
    } catch {
      throw new Error('PDF导出服务未安装 puppeteer，请在 Docker 环境中运行')
    }
  }
  return puppeteerModule
}

const router = Router()

// POST /api/v1/report/generate — SSE流式报告
// 流程: 1. 调Java获取产品推荐 → 2. SSE发products事件 → 3. 代理Python SSE流
router.post('/generate', async (req: Request, res: Response) => {
  // SSE headers
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8')
  res.setHeader('Cache-Control', 'no-cache')
  res.setHeader('Connection', 'keep-alive')
  res.setHeader('X-Accel-Buffering', 'no')
  res.flushHeaders()

  const send = (event: string, data: string) => res.write(`event: ${event}\ndata: ${data}\n\n`)

  try {
    // 1. 调Java规则引擎获取产品推荐
    let ruleResult: { isEmpty: boolean; candidates: unknown[] } = { isEmpty: true, candidates: [] }
    try {
      const { data } = await javaCalc.products(req.body)
      ruleResult = data.data ?? data
    } catch {
      // Java不可用时，发送空产品列表
    }

    // 2. SSE发送产品筛选结果
    if (ruleResult.isEmpty) {
      send('products', JSON.stringify({ isEmpty: true, message: '无符合产品', candidates: [] }))
    } else {
      send('products', JSON.stringify({ isEmpty: false, candidates: ruleResult.candidates }))
    }

    // 3. 代理Python SSE流（AI报告生成）
    const pyBody = { ...req.body, candidates: ruleResult.candidates }
    await proxySSE('/internal/report/generate', pyBody, res)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    send('error', JSON.stringify({ message: msg }))
    res.end()
  }
})

// POST /api/v1/report/chat — SSE对话，直接代理Python
router.post('/chat', async (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8')
  res.setHeader('Cache-Control', 'no-cache')
  res.setHeader('Connection', 'keep-alive')
  res.setHeader('X-Accel-Buffering', 'no')
  res.flushHeaders()

  try {
    await proxySSE('/internal/report/chat', req.body, res)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    res.write(`event: error\ndata: ${JSON.stringify({ message: msg })}\n\n`)
    res.end()
  }
})

// POST /api/v1/report/products — 仅规则引擎，快速返回JSON
router.post('/products', async (req: Request, res: Response) => {
  try {
    const { data } = await javaCalc.products(req.body)
    return res.json(data)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(502).json(errorResponse('ACTUARIAL_ERROR', msg))
  }
})

// POST /api/v1/report/export-pdf — 服务端PDF导出
router.post('/export-pdf', async (req: Request, res: Response) => {
  const { reportContent, customerName, customerAge, customerGender, generatedAt } = req.body
  if (!reportContent) {
    return res.status(400).json(errorResponse('MISSING_REQUIRED_FIELD', '缺少报告内容'))
  }

  try {
    const puppeteer = await getPuppeteer()
    const browser = await puppeteer.default.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox', '--disable-dev-shm-usage'],
    })
    const page = await browser.newPage()

    const name = customerName || (customerAge ? `${customerAge}岁${customerGender === 'male' ? '男' : '女'}客户` : '客户')
    const date = generatedAt || new Date().toLocaleDateString('zh-CN')

    // Convert markdown-like content to HTML
    const htmlContent = reportContent
      .split('\n')
      .map((line: string) => {
        if (line.startsWith('## ')) return `<h2>${line.slice(3)}</h2>`
        if (line.startsWith('### ')) return `<h3>${line.slice(4)}</h3>`
        if (line.startsWith('# ')) return `<h1>${line.slice(2)}</h1>`
        if (line.startsWith('- ') || line.startsWith('* ')) return `<li>${line.slice(2)}</li>`
        if (/^\d+\. /.test(line)) return `<li>${line}</li>`
        if (line === '---') return '<hr/>'
        if (!line.trim()) return ''
        return `<p>${line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')}</p>`
      })
      .join('\n')

    const html = `<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="UTF-8">
<style>
  @page { size: A4; margin: 20mm 15mm; }
  body {
    font-family: "Source Han Sans CN", "Noto Sans SC", "PingFang SC", "Microsoft YaHei", sans-serif;
    color: #1D1D1F; font-size: 11pt; line-height: 1.8;
  }
  .cover { text-align: center; padding-top: 120px; page-break-after: always; }
  .cover h1 { font-size: 28pt; color: #0071E3; margin-bottom: 16px; }
  .cover .meta { color: #6E6E73; font-size: 12pt; }
  h1 { font-size: 18pt; color: #0071E3; margin-top: 24px; page-break-after: avoid; }
  h2 { font-size: 14pt; color: #1D1D1F; margin-top: 20px; border-bottom: 1px solid #E8E8ED; padding-bottom: 6px; page-break-after: avoid; }
  h3 { font-size: 12pt; color: #6E6E73; margin-top: 16px; page-break-after: avoid; }
  p { margin: 6px 0; }
  li { margin: 4px 0 4px 20px; }
  hr { border: none; border-top: 1px solid #E8E8ED; margin: 16px 0; }
  strong { color: #0071E3; }
  .footer { text-align: center; color: #AEAEB2; font-size: 8pt; margin-top: 40px; }
</style>
</head>
<body>
  <div class="cover">
    <h1>AIX 保险智能规划报告</h1>
    <p class="meta">${name} &middot; 生成日期：${date}</p>
  </div>
  <div class="content">
    ${htmlContent}
  </div>
  <div class="footer">
    本报告由AIX保险智能测算引擎自动生成，仅供参考，不构成投资建议。
  </div>
</body>
</html>`

    await page.setContent(html, { waitUntil: 'networkidle0' })
    const pdfBuffer = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: { top: '20mm', bottom: '20mm', left: '15mm', right: '15mm' },
    })
    await browser.close()

    res.setHeader('Content-Type', 'application/pdf')
    res.setHeader('Content-Disposition', `attachment; filename="AIX_Report_${Date.now()}.pdf"`)
    return res.send(pdfBuffer)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(500).json(errorResponse('PDF_GENERATION_FAILED', msg))
  }
})

export default router
