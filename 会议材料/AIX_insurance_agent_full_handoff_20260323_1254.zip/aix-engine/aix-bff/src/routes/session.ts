import { Router, Request, Response } from 'express'
import { v4 as uuidv4 } from 'uuid'
import { SessionStore } from '../db/session-store'
import { ApiResponse } from '../types'

const router = Router()

const SCENARIO_DEFAULTS = {
  optimistic:  { wageGrowthRate: 0.05, inflationRate: 0.015, returnRate: 0.08 },
  neutral:     { wageGrowthRate: 0.03, inflationRate: 0.03,  returnRate: 0.03 },
  pessimistic: { wageGrowthRate: 0.01, inflationRate: 0.04,  returnRate: 0.02 },
}

// POST /api/v1/session — 创建会话
router.post('/', async (_req: Request, res: Response) => {
  try {
    const id = uuidv4()
    const sessionData = {
      id,
      scenario: 'neutral',
      scenarioParams: SCENARIO_DEFAULTS['neutral'],
    }
    const row = await SessionStore.create(id, 'neutral', sessionData)
    return res.status(201).json({
      success: true,
      data: { ...sessionData, createdAt: row.created_at, updatedAt: row.updated_at },
    } as ApiResponse)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(500).json({ success: false, error: msg } as ApiResponse)
  }
})

// GET /api/v1/session/:id — 读取会话
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const row = await SessionStore.getById(req.params.id)
    if (!row) {
      return res.status(404).json({ success: false, error: '会话不存在或已过期', code: 4003 } as ApiResponse)
    }
    const parsed = typeof row.data === 'string' ? JSON.parse(row.data) : row.data
    return res.json({ success: true, data: parsed } as ApiResponse)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(500).json({ success: false, error: msg } as ApiResponse)
  }
})

// PUT /api/v1/session/:id — 保存会话数据
router.put('/:id', async (req: Request, res: Response) => {
  try {
    const existing = await SessionStore.getById(req.params.id)
    if (!existing) {
      return res.status(404).json({ success: false, error: '会话不存在', code: 4003 } as ApiResponse)
    }
    const existData = typeof existing.data === 'string' ? JSON.parse(existing.data) : existing.data
    const merged = { ...existData, ...req.body, id: req.params.id }
    const updated = await SessionStore.update(req.params.id, {
      scenario: req.body.scenario,
      data: merged,
    })
    return res.json({ success: true, data: merged } as ApiResponse)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(500).json({ success: false, error: msg } as ApiResponse)
  }
})

export default router
