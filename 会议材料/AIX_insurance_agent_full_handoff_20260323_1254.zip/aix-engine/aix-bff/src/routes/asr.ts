/**
 * Aliyun NLS 实时语音识别 Token 代理
 * GET /api/v1/asr/token  → 返回 10 分钟有效的 NLS Token
 *
 * 阿里云 NLS Token API：
 *   GET https://nls-meta.cn-shanghai.aliyuncs.com/
 *   参数使用 HMAC-SHA1 签名（与其他阿里云 OpenAPI 相同规范）
 */
import { Router, Request, Response } from 'express'
import crypto from 'crypto'
import axios from 'axios'

const router = Router()

// ── 内存缓存（生产环境建议换 Redis） ─────────────────────────────
let tokenCache: { token: string; appKey: string; expiresAt: number } | null = null

// ── Aliyun OpenAPI HMAC-SHA1 签名 ─────────────────────────────────
function buildAliyunQuery(
  accessKeyId: string,
  accessKeySecret: string,
): string {
  const params: Record<string, string> = {
    Action:           'CreateToken',
    Version:          '2019-02-28',
    AccessKeyId:      accessKeyId,
    SignatureMethod:  'HMAC-SHA1',
    SignatureNonce:   crypto.randomBytes(8).toString('hex'),
    SignatureVersion: '1.0',
    Timestamp:        new Date().toISOString().replace(/\.\d{3}Z$/, 'Z'),
    Format:           'JSON',
  }

  // 按键名字典序排列后 percent-encode
  const sortedKeys = Object.keys(params).sort()
  const canonicalQs = sortedKeys
    .map(k => `${percentEncode(k)}=${percentEncode(params[k])}`)
    .join('&')

  const stringToSign = `GET&${percentEncode('/')}&${percentEncode(canonicalQs)}`
  const signature = crypto
    .createHmac('sha1', `${accessKeySecret}&`)
    .update(stringToSign)
    .digest('base64')

  params.Signature = signature

  // 最终 query string（顺序不重要，签名已包含）
  return Object.entries(params)
    .map(([k, v]) => `${percentEncode(k)}=${percentEncode(v)}`)
    .join('&')
}

/** 阿里云规范的 percent-encode（不编码字母/数字/- _ . ~） */
function percentEncode(str: string): string {
  return encodeURIComponent(str)
    .replace(/\+/g, '%20')
    .replace(/\*/g, '%2A')
    .replace(/%7E/g, '~')
}

// ── Token 路由 ────────────────────────────────────────────────────
router.get('/token', async (_req: Request, res: Response) => {
  const accessKeyId     = process.env.ALIYUN_ACCESS_KEY_ID     || ''
  const accessKeySecret = process.env.ALIYUN_ACCESS_KEY_SECRET || ''
  const appKey          = process.env.ALIYUN_NLS_APP_KEY       || ''

  if (!accessKeyId || !accessKeySecret || !appKey) {
    return res.status(503).json({ error: '未配置 Aliyun NLS 密钥，请检查环境变量' })
  }

  const now = Date.now()

  // 缓存命中：还有 2 分钟以上有效期直接返回
  if (tokenCache && tokenCache.expiresAt > now + 120_000) {
    return res.json({
      token:      tokenCache.token,
      appKey:     tokenCache.appKey,
      expires_at: new Date(tokenCache.expiresAt).toISOString(),
    })
  }

  try {
    const qs  = buildAliyunQuery(accessKeyId, accessKeySecret)
    const url = `https://nls-meta.cn-shanghai.aliyuncs.com/?${qs}`
    const response = await axios.get(url, { timeout: 8000 })

    const tokenObj = response.data?.Token
    if (!tokenObj?.Id) {
      throw new Error(`Aliyun 响应异常: ${JSON.stringify(response.data)}`)
    }

    // ExpireTime 是 Unix 时间戳（秒）
    const expiresAt = tokenObj.ExpireTime * 1000

    tokenCache = { token: tokenObj.Id, appKey, expiresAt }

    return res.json({
      token:      tokenObj.Id,
      appKey,
      expires_at: new Date(expiresAt).toISOString(),
    })
  } catch (err: any) {
    console.error('[asr/token] 获取 Token 失败:', err.message)
    const status = err.response?.status ?? 500
    return res.status(status).json({
      error: `获取 Aliyun NLS Token 失败: ${err.message}`,
    })
  }
})

export default router
