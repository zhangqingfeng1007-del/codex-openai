import { Router, Request, Response } from 'express'
import { javaCalc } from '../proxy/java-client'
import { validateEducationCost } from '../middleware/validators'
import { ApiResponse } from '../types'

const router = Router()

// POST /api/v1/calc/education/cost → Java精算服务
router.post('/cost', validateEducationCost, async (req: Request, res: Response) => {
  try {
    const { data } = await javaCalc.educationCost(req.body)
    return res.json(data)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(502).json({ success: false, error: `精算服务错误: ${msg}` } as ApiResponse)
  }
})

export default router
