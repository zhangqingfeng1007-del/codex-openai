import { Router, Request, Response } from 'express'
import { javaConfig } from '../proxy/java-client'
import { ApiResponse } from '../types'

const router = Router()

// GET /api/v1/config/city-list → Java配置服务
router.get('/city-list', async (_req: Request, res: Response) => {
  try {
    const { data } = await javaConfig.cityList()
    return res.json(data)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(502).json({ success: false, error: `配置服务错误: ${msg}` } as ApiResponse)
  }
})

// GET /api/v1/config/city/:code → Java配置服务
router.get('/city/:code', async (req: Request, res: Response) => {
  try {
    const { data } = await javaConfig.cityByCode(req.params.code)
    return res.json(data)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(502).json({ success: false, error: `配置服务错误: ${msg}` } as ApiResponse)
  }
})

// GET /api/v1/config/scenario-params → Java配置服务
router.get('/scenario-params', async (_req: Request, res: Response) => {
  try {
    const { data } = await javaConfig.scenarioParams()
    return res.json(data)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(502).json({ success: false, error: `配置服务错误: ${msg}` } as ApiResponse)
  }
})

// GET /api/v1/config/expense-defaults → Java配置服务
router.get('/expense-defaults', async (_req: Request, res: Response) => {
  try {
    const { data } = await javaConfig.expenseDefaults()
    return res.json(data)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(502).json({ success: false, error: `配置服务错误: ${msg}` } as ApiResponse)
  }
})

// GET /api/v1/config/annuity-divisor/:age → Java配置服务
router.get('/annuity-divisor/:age', async (req: Request, res: Response) => {
  try {
    const { data } = await javaConfig.annuityDivisor(parseInt(req.params.age))
    return res.json(data)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(502).json({ success: false, error: `配置服务错误: ${msg}` } as ApiResponse)
  }
})

export default router
