/**
 * 精算配置管理代理路由
 * 转发至 Java 精算服务 /api/v1/admin/actuarial/* 和 /api/v1/actuarial/*
 */
import { Router, Request, Response } from 'express'
import javaClient from '../proxy/java-client'

const router = Router()

async function proxyJava(res: Response, fn: () => Promise<{ data: unknown }>) {
  try {
    const axiosRes = await fn()
    res.json(axiosRes.data)
  } catch (err: any) {
    const status = err.response?.status ?? 500
    res.status(status).json(err.response?.data ?? { error: String(err.message) })
  }
}

// 产品精算配置 CRUD
router.get('/configs', (_req, res) =>
  proxyJava(res, () => javaClient.get('/api/v1/admin/actuarial/configs')))

router.get('/configs/:id', (req, res) =>
  proxyJava(res, () => javaClient.get(`/api/v1/admin/actuarial/configs/${req.params.id}`)))

router.post('/configs', (req, res) =>
  proxyJava(res, () => javaClient.post('/api/v1/admin/actuarial/configs', req.body)))

router.put('/configs/:id', (req, res) =>
  proxyJava(res, () => javaClient.put(`/api/v1/admin/actuarial/configs/${req.params.id}`, req.body)))

router.delete('/configs/:id', (req, res) =>
  proxyJava(res, () => javaClient.delete(`/api/v1/admin/actuarial/configs/${req.params.id}`)))

// 可用精算表列表
router.get('/tables', (_req, res) =>
  proxyJava(res, () => javaClient.get('/api/v1/admin/actuarial/tables')))

// 公允定价测试（管理后台"测试定价"按钮，需要产品已在DB配置）
router.get('/fair-price', (req: Request, res: Response) => {
  const { productId, age, gender = 'male' } = req.query
  proxyJava(res, () =>
    javaClient.get('/api/v1/actuarial/fair-price', {
      params: { productId, age, gender },
    })
  )
})

// 精算计算器（手动输入所有参数，不需要产品DB配置，用于测试验证公式）
router.post('/calculate', (req: Request, res: Response) =>
  proxyJava(res, () => javaClient.post('/api/v1/actuarial/calculate', req.body))
)

export default router
