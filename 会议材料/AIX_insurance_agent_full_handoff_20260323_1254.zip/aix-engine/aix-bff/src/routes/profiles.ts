import { Router, Request, Response } from 'express'
import { ProfileStore } from '../db/profile-store'
import { ApiResponse } from '../types'
import { writeAuditLog, auditFromReq } from '../utils/audit'

const router = Router()

// GET /api/v1/profiles — 列出所有档案
router.get('/', async (_req: Request, res: Response) => {
  try {
    const profiles = await ProfileStore.list()
    return res.json({ success: true, data: profiles } as ApiResponse)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(500).json({ success: false, error: msg } as ApiResponse)
  }
})

// GET /api/v1/profiles/:id — 获取单个档案
router.get('/:id', async (req: Request, res: Response) => {
  try {
    const profile = await ProfileStore.getById(req.params.id)
    if (!profile) {
      return res.status(404).json({ success: false, error: '档案不存在' } as ApiResponse)
    }
    const parsed = typeof profile.data === 'string' ? JSON.parse(profile.data) : profile.data
    return res.json({ success: true, data: { ...profile, data: parsed } } as ApiResponse)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(500).json({ success: false, error: msg } as ApiResponse)
  }
})

// POST /api/v1/profiles — 保存/更新档案
router.post('/', async (req: Request, res: Response) => {
  try {
    const { id, name, data } = req.body
    if (!id || !name) {
      return res.status(400).json({ success: false, error: '缺少 id 或 name' } as ApiResponse)
    }
    await ProfileStore.save(id, name, data)
    return res.json({ success: true } as ApiResponse)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(500).json({ success: false, error: msg } as ApiResponse)
  }
})

// DELETE /api/v1/profiles/:id — 删除档案
router.delete('/:id', async (req: Request, res: Response) => {
  try {
    const deleted = await ProfileStore.delete(req.params.id)
    if (!deleted) {
      return res.status(404).json({ success: false, error: '档案不存在' } as ApiResponse)
    }
    const { operator, ipAddress } = auditFromReq(req)
    writeAuditLog({ action: 'profile_delete', targetType: 'profile', targetId: req.params.id, operator, ipAddress })
    return res.json({ success: true } as ApiResponse)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    return res.status(500).json({ success: false, error: msg } as ApiResponse)
  }
})

export default router
