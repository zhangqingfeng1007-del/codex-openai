import { Router, Request, Response } from 'express'
import { proxySSE } from '../proxy/python-client'

const router = Router()

// POST /api/v1/chat — SSE 流式个人用户对话，代理到 Python AI 服务
router.post('/', async (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'text/event-stream; charset=utf-8')
  res.setHeader('Cache-Control', 'no-cache')
  res.setHeader('Connection', 'keep-alive')
  res.setHeader('X-Accel-Buffering', 'no')
  res.flushHeaders()

  try {
    await proxySSE('/internal/chat', req.body, res)
  } catch (err: unknown) {
    const msg = err instanceof Error ? err.message : String(err)
    res.write(`event: error\ndata: ${JSON.stringify({ message: msg })}\n\n`)
    res.end()
  }
})

export default router
