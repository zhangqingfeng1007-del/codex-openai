import { Router } from 'express'
import pensionRouter from './pension'
import financialRouter from './financial'
import educationRouter from './education'
import insuranceRouter from './insurance'
import reportRouter from './report'
import configRouter from './config'
import sessionRouter from './session'
import profilesRouter from './profiles'
import adminRouter from './admin'
import chatRouter from './chat'
import actuarialAdminRouter from './actuarial-admin'
import asrRouter from './asr'

const router = Router()

router.use('/admin', adminRouter)
router.use('/admin/actuarial', actuarialAdminRouter)
router.use('/asr', asrRouter)
router.use('/profiles', profilesRouter)
router.use('/session', sessionRouter)
router.use('/calc/pension', pensionRouter)
router.use('/calc/financial', financialRouter)
router.use('/calc/education', educationRouter)
router.use('/calc/insurance', insuranceRouter)
router.use('/report', reportRouter)
router.use('/config', configRouter)
router.use('/chat', chatRouter)

export default router
