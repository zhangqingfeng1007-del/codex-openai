/**
 * 统一错误码体系 — §10
 *
 * 4xxx: 客户端错误
 * 5xxx: 服务端错误
 */
export const ErrorCodes = {
  // 参数校验 (4001-4099)
  VALIDATION_ERROR:        { code: 4001, message: '请求参数校验失败' },
  MISSING_REQUIRED_FIELD:  { code: 4002, message: '缺少必填字段' },
  INVALID_VALUE:           { code: 4003, message: '字段值不合法' },

  // 认证授权 (4010-4019)
  AUTH_TOKEN_MISSING:      { code: 4010, message: '未提供认证令牌' },
  AUTH_TOKEN_INVALID:      { code: 4011, message: '认证令牌无效或已过期' },
  AUTH_PERMISSION_DENIED:  { code: 4012, message: '权限不足' },

  // 资源 (4040-4049)
  RESOURCE_NOT_FOUND:      { code: 4040, message: '请求的资源不存在' },
  PROFILE_NOT_FOUND:       { code: 4041, message: '客户档案不存在' },
  SESSION_NOT_FOUND:       { code: 4042, message: '会话不存在或已过期' },
  CONFIG_NOT_FOUND:        { code: 4043, message: '配置节不存在' },

  // 限流 (4290)
  RATE_LIMITED:            { code: 4290, message: '请求过于频繁，请稍后再试' },

  // 精算服务 (5001-5009)
  ACTUARIAL_ERROR:         { code: 5001, message: '精算服务计算错误' },
  ACTUARIAL_UNAVAILABLE:   { code: 5002, message: '精算服务不可用' },
  ACTUARIAL_TIMEOUT:       { code: 5003, message: '精算服务响应超时' },

  // AI服务 (5010-5019)
  AI_SERVICE_ERROR:        { code: 5010, message: 'AI报告服务错误' },
  AI_SERVICE_UNAVAILABLE:  { code: 5011, message: 'AI报告服务不可用' },
  AI_API_KEY_INVALID:      { code: 5012, message: 'AI服务API密钥无效' },

  // 数据库 (5020-5029)
  DB_ERROR:                { code: 5020, message: '数据库操作失败' },
  DB_CONNECTION_FAILED:    { code: 5021, message: '数据库连接失败' },

  // PDF (5030-5039)
  PDF_GENERATION_FAILED:   { code: 5030, message: 'PDF生成失败' },
  PDF_SERVICE_UNAVAILABLE: { code: 5031, message: 'PDF服务未安装' },

  // 通用 (5000)
  INTERNAL_ERROR:          { code: 5000, message: '服务器内部错误' },
} as const

export type ErrorCode = keyof typeof ErrorCodes

/**
 * Create a standardized error response
 */
export function errorResponse(errorKey: ErrorCode, detail?: string) {
  const { code, message } = ErrorCodes[errorKey]
  return {
    success: false,
    error: detail || message,
    code,
  }
}
