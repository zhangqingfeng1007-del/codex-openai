import { getPool } from './mysql'
import { RowDataPacket, ResultSetHeader } from 'mysql2'
import { encrypt, decrypt } from '../utils/crypto'

export interface ProfileRow {
  id: string
  name: string
  created_at: string
  updated_at: string
  data?: string
}

export const ProfileStore = {
  async list(): Promise<Omit<ProfileRow, 'data'>[]> {
    const pool = getPool()
    const [rows] = await pool.query<RowDataPacket[]>(
      'SELECT id, name, created_at, updated_at FROM profiles ORDER BY updated_at DESC'
    )
    return rows as Omit<ProfileRow, 'data'>[]
  },

  async getById(id: string): Promise<ProfileRow | undefined> {
    const pool = getPool()
    const [rows] = await pool.query<RowDataPacket[]>(
      'SELECT * FROM profiles WHERE id = ?', [id]
    )
    const row = rows[0] as ProfileRow | undefined
    if (row?.data) {
      // Decrypt data field if encrypted
      try {
        row.data = decrypt(row.data)
      } catch {
        // If decryption fails, data might be plain JSON (legacy)
      }
    }
    return row
  },

  async save(id: string, name: string, data: unknown): Promise<void> {
    const pool = getPool()
    const jsonStr = JSON.stringify(data)
    const encryptedData = encrypt(jsonStr)
    await pool.query(
      `INSERT INTO profiles (id, name, data) VALUES (?, ?, ?)
       ON DUPLICATE KEY UPDATE name = VALUES(name), data = VALUES(data)`,
      [id, name, encryptedData]
    )
  },

  async delete(id: string): Promise<boolean> {
    const pool = getPool()
    const [result] = await pool.query<ResultSetHeader>(
      'DELETE FROM profiles WHERE id = ?', [id]
    )
    return result.affectedRows > 0
  },
}
