import mysql from 'mysql2/promise'

let pool: mysql.Pool

export function getPool(): mysql.Pool {
  if (!pool) {
    pool = mysql.createPool({
      host: process.env.MYSQL_HOST || 'localhost',
      port: parseInt(process.env.MYSQL_PORT || '3306'),
      user: process.env.MYSQL_USER || 'aix',
      password: process.env.MYSQL_PASSWORD || 'aix_secret',
      database: process.env.MYSQL_DATABASE || 'aix_engine',
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      timezone: '+08:00',
    })
  }
  return pool
}

export async function initMySQL(): Promise<void> {
  const p = getPool()
  const [rows] = await p.query('SELECT 1')
  console.log('MySQL connected, pool ready')
}
