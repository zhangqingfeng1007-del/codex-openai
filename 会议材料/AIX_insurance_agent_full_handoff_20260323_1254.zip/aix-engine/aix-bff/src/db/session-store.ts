import { getPool } from './mysql'
import { RowDataPacket, ResultSetHeader } from 'mysql2'

export interface SessionRow {
  id: string
  created_at: string
  updated_at: string
  scenario: string
  data: string
  expires_at: string
}

const SESSION_TTL_HOURS = 24

export const SessionStore = {
  async create(id: string, scenario: string, data: unknown): Promise<SessionRow> {
    const pool = getPool()
    const expiresAt = new Date(Date.now() + SESSION_TTL_HOURS * 3600_000)
      .toISOString().slice(0, 19).replace('T', ' ')
    await pool.query(
      `INSERT INTO sessions (id, scenario, data, expires_at) VALUES (?, ?, ?, ?)`,
      [id, scenario, JSON.stringify(data), expiresAt]
    )
    const [rows] = await pool.query<RowDataPacket[]>(
      'SELECT * FROM sessions WHERE id = ?', [id]
    )
    return rows[0] as SessionRow
  },

  async getById(id: string): Promise<SessionRow | undefined> {
    const pool = getPool()
    const [rows] = await pool.query<RowDataPacket[]>(
      'SELECT * FROM sessions WHERE id = ? AND expires_at > NOW()', [id]
    )
    return rows[0] as SessionRow | undefined
  },

  async update(id: string, data: Partial<{ scenario: string; data: unknown }>): Promise<SessionRow | undefined> {
    const pool = getPool()
    const sets: string[] = []
    const params: unknown[] = []
    if (data.scenario) { sets.push('scenario = ?'); params.push(data.scenario) }
    if (data.data !== undefined) { sets.push('data = ?'); params.push(JSON.stringify(data.data)) }
    if (sets.length === 0) return this.getById(id)
    params.push(id)
    await pool.query(`UPDATE sessions SET ${sets.join(', ')} WHERE id = ?`, params)
    return this.getById(id)
  },

  async cleanup(): Promise<number> {
    const pool = getPool()
    const [result] = await pool.query<ResultSetHeader>(
      'DELETE FROM sessions WHERE expires_at < NOW()'
    )
    return result.affectedRows
  },
}
