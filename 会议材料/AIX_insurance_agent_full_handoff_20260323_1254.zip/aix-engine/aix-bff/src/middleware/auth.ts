/**
 * JWT 认证中间件 — §11 数据安全
 * 支持从父系统传入的 JWT Token 验证
 *
 * 配置方式:
 *   JWT_SECRET  — 对称密钥（HS256）
 *   JWT_ENABLED — "true" 启用，其他值或不设则跳过（开发模式）
 *
 * Token 传递:
 *   Authorization: Bearer <token>
 */
import { Request, Response, NextFunction } from 'express'
import crypto from 'crypto'

// ---- 轻量 JWT 验证（避免额外依赖 jsonwebtoken） ----

function base64UrlDecode(str: string): Buffer {
  str = str.replace(/-/g, '+').replace(/_/g, '/')
  while (str.length % 4) str += '='
  return Buffer.from(str, 'base64')
}

interface JwtPayload {
  sub?: string
  exp?: number
  iat?: number
  role?: string
  [key: string]: unknown
}

function verifyHS256(token: string, secret: string): JwtPayload | null {
  const parts = token.split('.')
  if (parts.length !== 3) return null

  const [headerB64, payloadB64, sigB64] = parts

  // Verify signature
  const data = `${headerB64}.${payloadB64}`
  const expectedSig = crypto
    .createHmac('sha256', secret)
    .update(data)
    .digest('base64url')

  if (sigB64 !== expectedSig) return null

  // Parse header & verify alg
  try {
    const header = JSON.parse(base64UrlDecode(headerB64).toString('utf8'))
    if (header.alg !== 'HS256') return null
  } catch {
    return null
  }

  // Parse payload
  try {
    const payload: JwtPayload = JSON.parse(base64UrlDecode(payloadB64).toString('utf8'))

    // Check expiration
    if (payload.exp && Date.now() / 1000 > payload.exp) return null

    return payload
  } catch {
    return null
  }
}

// ---- Express Middleware ----

export interface AuthenticatedRequest extends Request {
  user?: JwtPayload
}

export function jwtAuth(req: AuthenticatedRequest, res: Response, next: NextFunction) {
  const enabled = process.env.JWT_ENABLED === 'true'
  if (!enabled) {
    // 开发模式：跳过认证
    return next()
  }

  const secret = process.env.JWT_SECRET
  if (!secret) {
    console.error('[Auth] JWT_ENABLED=true but JWT_SECRET not configured')
    return res.status(500).json({ success: false, error: '服务端认证配置错误', code: 5001 })
  }

  const authHeader = req.headers.authorization
  if (!authHeader?.startsWith('Bearer ')) {
    return res.status(401).json({ success: false, error: '未提供认证令牌', code: 4010 })
  }

  const token = authHeader.slice(7)
  const payload = verifyHS256(token, secret)
  if (!payload) {
    return res.status(401).json({ success: false, error: '认证令牌无效或已过期', code: 4011 })
  }

  req.user = payload
  next()
}

// ---- Token 生成工具（用于测试/开发） ----

export function generateToken(payload: JwtPayload, secret: string, expiresInSeconds = 86400): string {
  const header = { alg: 'HS256', typ: 'JWT' }
  const now = Math.floor(Date.now() / 1000)
  const fullPayload = { ...payload, iat: now, exp: now + expiresInSeconds }

  const headerB64 = Buffer.from(JSON.stringify(header)).toString('base64url')
  const payloadB64 = Buffer.from(JSON.stringify(fullPayload)).toString('base64url')
  const data = `${headerB64}.${payloadB64}`
  const sig = crypto.createHmac('sha256', secret).update(data).digest('base64url')

  return `${data}.${sig}`
}
