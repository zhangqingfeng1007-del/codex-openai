import { body, validationResult } from 'express-validator'
import { Request, Response, NextFunction } from 'express'

function handleValidation(req: Request, res: Response, next: NextFunction) {
  const errors = validationResult(req)
  if (!errors.isEmpty()) {
    return res.status(400).json({ success: false, error: errors.array()[0].msg, code: 4001 })
  }
  next()
}

export const validatePensionGap = [
  body('customer').isObject().withMessage('缺少客户信息 customer'),
  body('customer.age').isInt({ min: 1, max: 100 }).withMessage('年龄须为 1-100 整数'),
  body('customer.gender').isIn(['male', 'female']).withMessage('性别须为 male/female'),
  body('expense').isObject().withMessage('缺少支出信息 expense'),
  handleValidation,
]

export const validateFinancialScore = [
  body('financial').isObject().withMessage('缺少财务信息 financial'),
  body('socialSecurityType').isIn(['employee', 'civil_servant', 'resident', 'none']).withMessage('社保类型无效'),
  handleValidation,
]

export const validateEducationCost = [
  body('children').isArray({ min: 1 }).withMessage('至少需要一个子女信息'),
  body('cityCode').isString().notEmpty().withMessage('缺少城市编码'),
  handleValidation,
]

export const validateInsuranceNeeds = [
  body('customerAge').isInt({ min: 1, max: 100 }).withMessage('年龄须为 1-100 整数'),
  body('gender').isIn(['male', 'female']).withMessage('性别须为 male/female'),
  handleValidation,
]
