import axios, { AxiosInstance } from 'axios'

const JAVA_URL = process.env.JAVA_SERVICE_URL || 'http://localhost:8080'

const client: AxiosInstance = axios.create({
  baseURL: JAVA_URL,
  timeout: 10_000,
  headers: { 'Content-Type': 'application/json' },
})

// 计算接口
export const javaCalc = {
  pensionGap: (body: unknown) => client.post('/internal/calc/pension/gap', body),
  retirementAge: (body: unknown) => client.post('/internal/calc/pension/retirement-age', body),
  financialScore: (body: unknown) => client.post('/internal/calc/financial/score', body),
  educationCost: (body: unknown) => client.post('/internal/calc/education/cost', body),
  insuranceNeeds: (body: unknown) => client.post('/internal/calc/insurance/needs', body),
  products: (body: unknown) => client.post('/internal/report/products', body),
}

// 配置接口
export const javaConfig = {
  cityList: () => client.get('/internal/config/cities'),
  cityByCode: (code: string) => client.get(`/internal/config/city/${code}`),
  scenarioParams: () => client.get('/internal/config/scenario-params'),
  expenseDefaults: () => client.get('/internal/config/expense-defaults'),
  annuityDivisor: (age: number) => client.get(`/internal/config/annuity-divisor/${age}`),
}

// 精算公允定价接口
export const javaActuarial = {
  fairPrice: (productId: string, age: number, gender: string) =>
    client.get('/api/v1/actuarial/fair-price', { params: { productId, age, gender } }),
  fairPriceBatch: (body: unknown) =>
    client.post('/api/v1/actuarial/fair-price/batch', body),
  adminListConfigs: () =>
    client.get('/api/v1/admin/actuarial/configs'),
  adminGetConfig: (productId: string) =>
    client.get(`/api/v1/admin/actuarial/configs/${productId}`),
  adminSaveConfig: (body: unknown) =>
    client.post('/api/v1/admin/actuarial/configs', body),
  adminUpdateConfig: (productId: string, body: unknown) =>
    client.put(`/api/v1/admin/actuarial/configs/${productId}`, body),
  adminDeleteConfig: (productId: string) =>
    client.delete(`/api/v1/admin/actuarial/configs/${productId}`),
  adminListTables: () =>
    client.get('/api/v1/admin/actuarial/tables'),
}

export default client
