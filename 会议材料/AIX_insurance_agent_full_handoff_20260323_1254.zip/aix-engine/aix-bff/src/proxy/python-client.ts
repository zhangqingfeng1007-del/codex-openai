import { Request, Response } from 'express'

const PYTHON_URL = process.env.PYTHON_SERVICE_URL || 'http://localhost:8000'

/**
 * SSE 流式代理：BFF → Python FastAPI → 前端
 * 保持 SSE 连接不断，逐 chunk 转发
 */
export async function proxySSE(
  endpoint: string,
  reqBody: unknown,
  res: Response
): Promise<void> {
  const url = `${PYTHON_URL}${endpoint}`

  const response = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(reqBody),
  })

  if (!response.ok || !response.body) {
    const text = await response.text().catch(() => 'Unknown error')
    res.write(`event: error\ndata: ${JSON.stringify({ message: `Python service error: ${response.status} ${text}` })}\n\n`)
    res.end()
    return
  }

  const reader = response.body.getReader()
  const decoder = new TextDecoder()

  try {
    while (true) {
      const { done, value } = await reader.read()
      if (done) break
      const chunk = decoder.decode(value, { stream: true })
      res.write(chunk)
    }
  } catch (err) {
    res.write(`event: error\ndata: ${JSON.stringify({ message: 'SSE proxy interrupted' })}\n\n`)
  } finally {
    res.end()
  }
}
