import amqplib from 'amqplib'

let channel: amqplib.Channel | null = null

const RABBITMQ_URL = process.env.RABBITMQ_URL || 'amqp://localhost:5672'
const EXCHANGE = 'aix.report'

export async function initMQ(): Promise<void> {
  try {
    const conn = await amqplib.connect(RABBITMQ_URL)
    const ch = await conn.createChannel()
    await ch.assertExchange(EXCHANGE, 'direct', { durable: true })
    await ch.assertQueue('aix.report.generate', { durable: true })
    await ch.assertQueue('aix.report.result', { durable: true })
    await ch.assertQueue('aix.report.dlq', { durable: true })
    await ch.bindQueue('aix.report.generate', EXCHANGE, 'report.generate')
    await ch.bindQueue('aix.report.result', EXCHANGE, 'report.result')
    await ch.bindQueue('aix.report.dlq', EXCHANGE, 'report.dlq')
    channel = ch
    console.log('RabbitMQ connected, exchange/queues ready')
  } catch (err) {
    console.warn('RabbitMQ not available, SSE will use HTTP direct mode:', (err as Error).message)
  }
}

export function publishReportTask(taskId: string, payload: unknown): boolean {
  if (!channel) return false
  return channel.publish(EXCHANGE, 'report.generate', Buffer.from(JSON.stringify({ taskId, ...payload as object })))
}

export function getChannel(): amqplib.Channel | null {
  return channel
}
