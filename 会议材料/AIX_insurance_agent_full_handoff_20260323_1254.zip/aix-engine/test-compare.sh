#!/bin/bash
# ============================================================
# AIX 精算服务 Java vs TypeScript 对比测试
# 旧后端(TS): http://localhost:3099
# 新后端(Java via BFF): http://localhost:3001
# ============================================================

OLD="http://localhost:3099/api/v1"
NEW="http://localhost:3001/api/v1"

PASS=0
FAIL=0
WARN=0

compare_json() {
  local name="$1" old_resp="$2" new_resp="$3" tolerance="$4"

  # 检查是否有错误
  old_success=$(echo "$old_resp" | python3 -c "import sys,json; print(json.load(sys.stdin).get('success',''))" 2>/dev/null)
  new_success=$(echo "$new_resp" | python3 -c "import sys,json; print(json.load(sys.stdin).get('success',''))" 2>/dev/null)

  if [ "$old_success" != "True" ]; then
    echo "  ⚠️  旧后端返回失败: $(echo "$old_resp" | head -c 200)"
    WARN=$((WARN+1))
    return
  fi
  if [ "$new_success" != "True" ]; then
    echo "  ❌ 新后端返回失败: $(echo "$new_resp" | head -c 200)"
    FAIL=$((FAIL+1))
    return
  fi

  # 用 Python 比较数值
  result=$(python3 << 'PYEOF'
import sys, json

old = json.loads(sys.argv[1])["data"]
new = json.loads(sys.argv[2])["data"]
tol = float(sys.argv[3])

def flatten(obj, prefix=""):
    items = {}
    if isinstance(obj, dict):
        for k, v in obj.items():
            items.update(flatten(v, f"{prefix}{k}."))
    elif isinstance(obj, list):
        items[prefix.rstrip(".")] = f"[list:{len(obj)}]"
    elif isinstance(obj, (int, float)):
        items[prefix.rstrip(".")] = obj
    elif isinstance(obj, str):
        items[prefix.rstrip(".")] = obj
    else:
        items[prefix.rstrip(".")] = str(obj)
    return items

old_flat = flatten(old)
new_flat = flatten(new)

diffs = []
for k in sorted(set(list(old_flat.keys()) + list(new_flat.keys()))):
    ov = old_flat.get(k, "MISSING")
    nv = new_flat.get(k, "MISSING")
    if isinstance(ov, (int, float)) and isinstance(nv, (int, float)):
        if abs(ov - nv) > tol:
            diffs.append(f"    {k}: old={ov:.4f} new={nv:.4f} diff={abs(ov-nv):.4f}")
    elif isinstance(ov, str) and isinstance(nv, str):
        if ov.startswith("[list:") and nv.startswith("[list:"):
            if ov != nv:
                diffs.append(f"    {k}: old={ov} new={nv}")
        elif ov != nv:
            diffs.append(f"    {k}: old={ov} new={nv}")
    elif ov == "MISSING":
        pass  # 新后端多返回字段不算错
    elif nv == "MISSING":
        diffs.append(f"    {k}: 新后端缺少此字段 (old={ov})")

if diffs:
    print("DIFF")
    for d in diffs[:15]:
        print(d)
else:
    print("MATCH")
PYEOF
  "$old_resp" "$new_resp" "$tolerance")

  if echo "$result" | grep -q "^MATCH"; then
    echo "  ✅ PASS"
    PASS=$((PASS+1))
  else
    echo "  ❌ DIFF:"
    echo "$result" | tail -n +2
    FAIL=$((FAIL+1))
  fi
}

# ============================================================
echo "═══════════════════════════════════════════════════"
echo "     AIX 精算对比测试：Java vs TypeScript"
echo "═══════════════════════════════════════════════════"
echo ""

# ── TEST 1: 退休年龄（35岁男性职工）──
echo "▶ TEST 1: 退休年龄 — 35岁男性职工"
PAYLOAD='{"customer":{"age":35,"gender":"male","socialSecurityType":"employee"}}'
OLD_R=$(curl -s -X POST "$OLD/calc/pension/retirement-age" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/pension/retirement-age" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "retirement-age-male-35" "$OLD_R" "$NEW_R" "0.5"

# ── TEST 2: 退休年龄（40岁女性干部）──
echo "▶ TEST 2: 退休年龄 — 40岁女性干部"
PAYLOAD='{"customer":{"age":40,"gender":"female","femaleIdentityType":"cadre","socialSecurityType":"employee"}}'
OLD_R=$(curl -s -X POST "$OLD/calc/pension/retirement-age" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/pension/retirement-age" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "retirement-age-female-40-cadre" "$OLD_R" "$NEW_R" "0.5"

# ── TEST 3: 退休年龄（50岁女性工人）──
echo "▶ TEST 3: 退休年龄 — 50岁女性工人"
PAYLOAD='{"customer":{"age":50,"gender":"female","femaleIdentityType":"worker","socialSecurityType":"employee"}}'
OLD_R=$(curl -s -X POST "$OLD/calc/pension/retirement-age" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/pension/retirement-age" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "retirement-age-female-50-worker" "$OLD_R" "$NEW_R" "0.5"

# ── TEST 4: 财务评分（标准案例）──
echo "▶ TEST 4: 财务评分 — 标准双薪家庭"
PAYLOAD='{"financial":{"personalMonthlyIncome":15000,"spouseMonthlyIncome":10000,"totalFamilyMonthlyIncome":25000,"fixedMonthlyExpense":8000,"mortgageMonthly":5000,"otherLoanMonthly":1000,"availableAssets":800000},"socialSecurityType":"employee","spouseSocialSecurityType":"employee"}'
OLD_R=$(curl -s -X POST "$OLD/calc/financial/score" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/financial/score" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "financial-score-standard" "$OLD_R" "$NEW_R" "0.01"

# ── TEST 5: 财务评分（高负债）──
echo "▶ TEST 5: 财务评分 — 高负债低资产"
PAYLOAD='{"financial":{"personalMonthlyIncome":8000,"totalFamilyMonthlyIncome":8000,"fixedMonthlyExpense":6000,"mortgageMonthly":4000,"otherLoanMonthly":2000,"availableAssets":50000},"socialSecurityType":"resident"}'
OLD_R=$(curl -s -X POST "$OLD/calc/financial/score" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/financial/score" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "financial-score-high-debt" "$OLD_R" "$NEW_R" "0.01"

# ── TEST 6: 保障需求（有子女家庭）──
echo "▶ TEST 6: 保障需求 — 35岁有1子女"
PAYLOAD='{"customerAge":35,"gender":"male","monthlyIncome":15000,"totalFamilyMonthlyIncome":25000,"retirementAge":63,"totalDebt":2000000,"liquidAssets":800000,"existingLifeCoverage":500000,"existingCriticalIllnessCoverage":200000,"existingMedicalCoverage":500000,"annualExpense":96000,"socialSecurityType":"employee","cityTier":1,"hasChildren":true,"childrenCount":1,"remainingEducationCost":600000,"hospitalPreference":"public"}'
OLD_R=$(curl -s -X POST "$OLD/calc/insurance/needs" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/insurance/needs" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "insurance-needs-family" "$OLD_R" "$NEW_R" "0.01"

# ── TEST 7: 保障需求（单身无子女）──
echo "▶ TEST 7: 保障需求 — 28岁单身无子女"
PAYLOAD='{"customerAge":28,"gender":"female","monthlyIncome":8000,"totalFamilyMonthlyIncome":8000,"retirementAge":58,"totalDebt":0,"liquidAssets":100000,"existingLifeCoverage":0,"existingCriticalIllnessCoverage":0,"existingMedicalCoverage":0,"annualExpense":60000,"socialSecurityType":"employee","cityTier":2,"hasChildren":false,"childrenCount":0,"remainingEducationCost":0,"hospitalPreference":"vip"}'
OLD_R=$(curl -s -X POST "$OLD/calc/insurance/needs" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/insurance/needs" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "insurance-needs-single" "$OLD_R" "$NEW_R" "0.01"

# ── TEST 8: 养老缺口（北京男性标准案例）──
echo "▶ TEST 8: 养老缺口 — 北京35岁男性"
PAYLOAD='{"customer":{"age":35,"gender":"male","cityWork":"beijing","monthlyIncome":15000,"yearsPaid":10,"socialSecurityType":"employee","hasSpouse":false,"retirementAge":63,"children":[]},"cityRetire":"beijing","health":"average","expense":{"activeLivingType":"own_home","activeMonthlyResidence":0,"monthlyLiving":6000,"otherAnnual":30000,"medicalTier":"mid","leisureTier":"mid","semiCareMonthlyNursing":10000,"fullCareMonthlyNursing":18000},"reserve":{"enterpriseAnnuityBalance":0,"enterpriseAnnuityMonthly":0,"personalPensionBalance":50000,"personalPensionAnnual":12000,"otherSavings":200000,"otherMonthlySaving":3000},"scenario":"neutral","scenarioParams":{"wageGrowthRate":0.03,"inflationRate":0.03,"returnRate":0.03}}'
OLD_R=$(curl -s -X POST "$OLD/calc/pension/gap" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/pension/gap" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "pension-gap-beijing-male" "$OLD_R" "$NEW_R" "1.0"

# ── TEST 9: 养老缺口（上海女性悲观情景）──
echo "▶ TEST 9: 养老缺口 — 上海40岁女性悲观"
PAYLOAD='{"customer":{"age":40,"gender":"female","femaleIdentityType":"cadre","cityWork":"shanghai","monthlyIncome":20000,"yearsPaid":15,"socialSecurityType":"employee","hasSpouse":true,"retirementAge":58,"spouse":{"age":42,"gender":"male","monthlyIncome":25000,"yearsPaid":18,"socialSecurityType":"employee"},"children":[]},"cityRetire":"shanghai","health":"good","spouseHealth":"average","expense":{"activeLivingType":"own_home","activeMonthlyResidence":0,"monthlyLiving":8000,"otherAnnual":50000,"medicalTier":"high","leisureTier":"high","semiCareMonthlyNursing":15000,"fullCareMonthlyNursing":25000},"reserve":{"enterpriseAnnuityBalance":100000,"enterpriseAnnuityMonthly":1500,"personalPensionBalance":80000,"personalPensionAnnual":12000,"otherSavings":500000,"otherMonthlySaving":5000},"scenario":"pessimistic","scenarioParams":{"wageGrowthRate":0.01,"inflationRate":0.04,"returnRate":0.02}}'
OLD_R=$(curl -s -X POST "$OLD/calc/pension/gap" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/pension/gap" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "pension-gap-shanghai-female-pessimistic" "$OLD_R" "$NEW_R" "1.0"

# ── TEST 10: 产品推荐 ──
echo "▶ TEST 10: 产品推荐 — 35岁有养老+教育需求"
PAYLOAD='{"customer":{"age":35,"gender":"male","cityWork":"beijing","monthlyIncome":15000,"hasSpouse":true,"children":[{"age":5}]},"pensionResult":{"pensionGap":500000},"educationResult":{"familyTotal":400000},"insuranceResult":{"lifeInsuranceGap":1000000,"criticalIllnessGap":300000,"medicalGap":500000},"financialResult":{"total":75}}'
OLD_R=$(curl -s -X POST "$OLD/report/products" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/report/products" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "product-recommendation" "$OLD_R" "$NEW_R" "0.01"

# ── 边界测试 ──
echo ""
echo "── 边界用例 ──"

# ── TEST 11: 极端年龄（22岁刚工作）──
echo "▶ TEST 11: 边界 — 22岁0年缴费"
PAYLOAD='{"customer":{"age":22,"gender":"male","socialSecurityType":"employee"}}'
OLD_R=$(curl -s -X POST "$OLD/calc/pension/retirement-age" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/pension/retirement-age" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "retirement-age-22" "$OLD_R" "$NEW_R" "0.5"

# ── TEST 12: 无社保 ──
echo "▶ TEST 12: 边界 — 无社保用户"
PAYLOAD='{"customerAge":45,"gender":"male","monthlyIncome":5000,"totalFamilyMonthlyIncome":5000,"retirementAge":60,"totalDebt":0,"liquidAssets":30000,"existingLifeCoverage":0,"existingCriticalIllnessCoverage":0,"existingMedicalCoverage":0,"annualExpense":48000,"socialSecurityType":"none","cityTier":3,"hasChildren":false,"childrenCount":0,"remainingEducationCost":0,"hospitalPreference":"public"}'
OLD_R=$(curl -s -X POST "$OLD/calc/insurance/needs" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/insurance/needs" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "insurance-needs-no-ss" "$OLD_R" "$NEW_R" "0.01"

# ── TEST 13: 居民医保 ──
echo "▶ TEST 13: 边界 — 居民医保养老缺口"
PAYLOAD='{"customer":{"age":50,"gender":"female","cityWork":"chengdu","monthlyIncome":4000,"yearsPaid":20,"socialSecurityType":"resident","hasSpouse":false,"retirementAge":55,"children":[]},"cityRetire":"chengdu","health":"poor","expense":{"activeLivingType":"rent","activeMonthlyResidence":1500,"monthlyLiving":3000,"otherAnnual":10000,"medicalTier":"low","leisureTier":"low","semiCareMonthlyNursing":5000,"fullCareMonthlyNursing":10000},"reserve":{"enterpriseAnnuityBalance":0,"enterpriseAnnuityMonthly":0,"personalPensionBalance":0,"personalPensionAnnual":0,"otherSavings":80000,"otherMonthlySaving":500},"scenario":"neutral","scenarioParams":{"wageGrowthRate":0.03,"inflationRate":0.03,"returnRate":0.03}}'
OLD_R=$(curl -s -X POST "$OLD/calc/pension/gap" -H "Content-Type: application/json" -d "$PAYLOAD")
NEW_R=$(curl -s -X POST "$NEW/calc/pension/gap" -H "Content-Type: application/json" -d "$PAYLOAD")
compare_json "pension-gap-resident-chengdu" "$OLD_R" "$NEW_R" "1.0"

# ── 汇总 ──
echo ""
echo "═══════════════════════════════════════════════════"
echo "  测试结果汇总: ✅ PASS=$PASS  ❌ FAIL=$FAIL  ⚠️ WARN=$WARN"
echo "═══════════════════════════════════════════════════"
