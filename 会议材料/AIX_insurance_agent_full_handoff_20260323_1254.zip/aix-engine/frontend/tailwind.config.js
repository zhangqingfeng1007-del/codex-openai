/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        // AIX 设计系统 — Apple 风格亮色主题
        bg: {
          base:    '#FFFFFF',  // 纯白页面底色
          card:    '#FFFFFF',  // 卡片白色，靠阴影分层
          float:   '#F5F5F7',  // Apple 标志性浅灰
          border:  '#D2D2D7',  // 淡灰边线
        },
        text: {
          primary:     '#1D1D1F',  // Apple 近黑色
          secondary:   '#6E6E73',  // Apple 灰色
          muted:       '#86868B',  // 更轻的灰色
          placeholder: '#AEAEB2',  // 浅灰占位
        },
        accent: {
          DEFAULT:  '#0071E3',  // Apple Blue
          light:    '#2997FF',  // 浅蓝 hover
          success:  '#34C759',  // Apple Green
          warning:  '#FF9500',  // Apple Orange
          danger:   '#FF3B30',  // Apple Red
          purple:   '#AF52DE',  // Apple Purple
        },
        chart: {
          1: '#0071E3',
          2: '#34C759',
          3: '#FF9500',
          4: '#FF3B30',
        },
      },
      fontFamily: {
        sans: ['-apple-system', 'BlinkMacSystemFont', 'SF Pro Text', 'Inter', 'PingFang SC', 'Source Han Sans CN', 'sans-serif'],
        display: ['SF Pro Display', 'Inter Display', 'Inter', 'sans-serif'],
      },
      borderRadius: {
        card:  '16px',
        input: '10px',
        btn:   '980px',  // Apple 胶囊形按钮
      },
      boxShadow: {
        'card':       '0 1px 3px rgba(0,0,0,0.04), 0 4px 12px rgba(0,0,0,0.06)',
        'card-hover': '0 2px 8px rgba(0,0,0,0.06), 0 8px 24px rgba(0,0,0,0.10)',
        'float':      '0 4px 24px rgba(0,0,0,0.12), 0 0 0 1px rgba(0,0,0,0.04)',
        'nav':        '0 1px 0 rgba(0,0,0,0.08)',
      },
      animation: {
        'fade-in': 'fadeIn 0.3s ease-in-out',
        'slide-in-right': 'slideInRight 0.3s ease-in-out',
        'number-count': 'numberCount 0.6s ease-out',
      },
      keyframes: {
        fadeIn: {
          '0%':   { opacity: '0' },
          '100%': { opacity: '1' },
        },
        slideInRight: {
          '0%':   { transform: 'translateX(60px)', opacity: '0' },
          '100%': { transform: 'translateX(0)',    opacity: '1' },
        },
      },
    },
  },
  plugins: [],
}
