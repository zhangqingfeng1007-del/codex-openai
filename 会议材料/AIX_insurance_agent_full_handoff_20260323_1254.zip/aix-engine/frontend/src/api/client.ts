import axios from 'axios'

export const api = axios.create({
  baseURL: '/api/v1',
  timeout: 30000,
  headers: { 'Content-Type': 'application/json' },
})

api.interceptors.response.use(
  res => res,
  err => { console.error('[API Error]', err.response?.data || err.message); return Promise.reject(err) }
)

export const fetchCities = () => api.get('/config/city-list').then(r => r.data.data)
export const fetchScenarioParams = () => api.get('/config/scenario-params').then(r => r.data.data)
export const fetchExpenseDefaults = () => api.get('/config/expense-defaults').then(r => r.data.data)
export const calcRetirementAge = (customer: object) => api.post('/calc/pension/retirement-age', { customer }).then(r => r.data.data)
export const calcPensionGap = (payload: object) => api.post('/calc/pension/gap', payload).then(r => r.data.data)
export const calcEducationCost = (payload: object) => api.post('/calc/education/cost', payload).then(r => r.data.data)
export const calcFinancialScore = (payload: object) => api.post('/calc/financial/score', payload).then(r => r.data.data)
export const createSession = () => api.post('/session').then(r => r.data.data)
export const calcInsuranceNeeds = (payload: object) => api.post('/calc/insurance/needs', payload).then(r => r.data.data)
export const fetchProductRecommendations = (payload: object) =>
  api.post('/report/products', payload).then(r => r.data.data as {
    candidates: import('../types').ProductRecord[]
    matchedTags: string[]
    tagReasons: Record<string, string>
    isEmpty: boolean
  })

export const generateReport = (payload: object, onProducts: (d: { isEmpty: boolean; candidates: unknown[]; message?: string }) => void, onChunk: (t: string) => void): Promise<void> => {
  return new Promise((resolve, reject) => {
    fetch('/api/v1/report/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    }).then(res => {
      const reader = res.body!.getReader()
      const decoder = new TextDecoder()
      let buf = '', lastEvent = ''
      function pump(): Promise<void> {
        return reader.read().then(({ done, value }) => {
          if (done) { resolve(); return }
          buf += decoder.decode(value, { stream: true })
          const lines = buf.split('\n')
          buf = lines.pop() ?? ''
          for (const line of lines) {
            const t = line.trim()
            if (t.startsWith('event:')) { lastEvent = t.slice(6).trim(); continue }
            if (t.startsWith('data:')) {
              const raw = t.slice(5).trim()
              try {
                const d = JSON.parse(raw)
                if (lastEvent === 'products') onProducts(d)
                else if (lastEvent === 'chunk' && d.content) onChunk(d.content)
                else if (lastEvent === 'done') { resolve(); return }
              } catch { /* ignore */ }
            }
          }
          return pump()
        })
      }
      return pump()
    }).catch(reject)
  })
}

// ── 服务端 PDF 导出 ──
export const exportPdf = async (payload: {
  reportContent: string
  customerName?: string
  customerAge?: number
  customerGender?: string
  generatedAt?: string
}): Promise<Blob> => {
  const res = await api.post('/report/export-pdf', payload, {
    responseType: 'blob',
    timeout: 60000,
  })
  return res.data
}

// ── 档案 API ──
export const listProfiles = () => api.get('/profiles').then(r => r.data.data)
export const getProfile = (id: string) => api.get(`/profiles/${id}`).then(r => r.data.data)
export const saveProfileToServer = (id: string, name: string, data: unknown) =>
  api.post('/profiles', { id, name, data }).then(r => r.data)
export const deleteProfileFromServer = (id: string) =>
  api.delete(`/profiles/${id}`).then(r => r.data)

export const chatWithAI = (messages: Array<{ role: string; content: string }>, onChunk: (t: string) => void): Promise<void> => {
  return new Promise((resolve, reject) => {
    fetch('/api/v1/report/chat', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ messages }),
    }).then(res => {
      const reader = res.body!.getReader()
      const decoder = new TextDecoder()
      let buf = '', lastEvent = ''
      function pump(): Promise<void> {
        return reader.read().then(({ done, value }) => {
          if (done) { resolve(); return }
          buf += decoder.decode(value, { stream: true })
          const lines = buf.split('\n')
          buf = lines.pop() ?? ''
          for (const line of lines) {
            const t = line.trim()
            if (t.startsWith('event:')) { lastEvent = t.slice(6).trim(); continue }
            if (t.startsWith('data:')) {
              try {
                const d = JSON.parse(t.slice(5).trim())
                if (lastEvent === 'chunk' && d.content) onChunk(d.content)
                else if (lastEvent === 'done') { resolve(); return }
              } catch { /* ignore */ }
            }
          }
          return pump()
        })
      }
      return pump()
    }).catch(reject)
  })
}
