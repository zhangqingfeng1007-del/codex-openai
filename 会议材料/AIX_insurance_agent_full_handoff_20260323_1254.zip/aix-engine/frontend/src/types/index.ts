// AIX 前端类型定义 V1.0
export type Gender = 'male' | 'female'
export type FemaleIdentityType = 'cadre' | 'worker'
export type SocialSecurityType = 'employee' | 'civil_servant' | 'resident' | 'none'
export type CityTier = 1 | 2 | 3
export type Scenario = 'optimistic' | 'neutral' | 'pessimistic'
export type HealthStatus = 'good' | 'average' | 'poor'
export type RetirementLivingType = 'own_home' | 'rent' | 'senior_community'
export type EducationPath = 'A' | 'B' | 'C' | 'D'
export type InterestCategory = 'sports' | 'arts' | 'academic' | 'language' | 'travel' | 'tech' | 'tutoring'
export type HospitalPreference = 'public' | 'vip' | 'private' | 'international'

export interface ChildInfo {
  id: string
  birthYear?: number
  age: number
  gender: Gender
  educationPath?: EducationPath
}

export interface SpouseInfo {
  birthYear?: number
  age: number
  gender: Gender
  femaleIdentityType?: FemaleIdentityType
  cityWork: string
  cityRetire?: string
  socialSecurityType: SocialSecurityType
  yearsPaid: number
  monthlyIncome: number
  ssContributionBase?: number
  retirementAge?: number
  workStartYear?: number
}

export interface CustomerBasicInfo {
  name?: string
  birthYear?: number
  age: number
  gender: Gender
  femaleIdentityType?: FemaleIdentityType
  cityWork: string
  cityRetire?: string
  socialSecurityType: SocialSecurityType
  yearsPaid: number
  monthlyIncome: number
  ssContributionBase?: number
  retirementAge?: number
  workStartYear?: number
  hasSpouse: boolean
  spouse?: SpouseInfo
  children: ChildInfo[]
}

export interface FinancialInfo {
  // 派生汇总字段（供评分使用）
  personalMonthlyIncome: number
  spouseMonthlyIncome?: number
  totalFamilyMonthlyIncome: number
  fixedMonthlyExpense: number     // 月总支出（不含贷款还款）
  mortgageMonthly: number
  otherLoanMonthly: number
  availableAssets: number

  // 本人附加月收入
  personalRentalIncome?: number
  personalInvestmentIncome?: number
  personalOtherIncome?: number

  // 配偶附加月收入
  spouseRentalIncome?: number
  spouseInvestmentIncome?: number
  spouseOtherIncome?: number

  // 月度支出明细
  rentMonthly?: number
  dailyLivingMonthly?: number
  insurancePremiumMonthly?: number
  educationCurrentMonthly?: number
  otherFixedMonthly?: number

  // 资产明细
  cashAndDeposits?: number
  investmentAssets?: number
  insuranceCashValue?: number
  otherFinancialAssets?: number
  propertyValue?: number
}

export interface FinancialScore {
  total: number
  surplusRatio: number
  debtRatio: number
  assetAdequacy: number
  ssLevel: 'high' | 'medium' | 'low'
  detail: string
  grade: string
}

export interface EducationStageDetail {
  stage: string
  schoolType: string
  remainingYears: number
  annualCost: number
  totalCost: number
  startYear: number
}

export interface InterestPlan {
  category: InterestCategory
  annualCost: number
  untilStage: string
  totalCost: number
}

export interface ChildEducationPlan {
  childId: string
  educationPath: EducationPath
  stages: EducationStageDetail[]
  interests: InterestPlan[]
  academicTotal: number
  interestTotal: number
  totalCost: number
  monthlyTargetConservative: number
  monthlyTargetAggressive: number
}

export interface EducationPlanResult {
  children: ChildEducationPlan[]
  familyAcademicTotal: number
  familyInterestTotal: number
  familyTotal: number
  monthlyTargetConservative: number
  monthlyTargetAggressive: number
}

export interface RetirementExpense {
  activeLivingType: RetirementLivingType
  activeMonthlyResidence: number
  semiCareMonthlyNursing: number
  fullCareMonthlyNursing: number
  medicalTier: 'low' | 'mid' | 'high'
  leisureTier: 'low' | 'mid' | 'high'
  monthlyLiving: number
  otherAnnual: number
}

export interface PensionReserve {
  enterpriseAnnuityBalance: number
  personalPensionBalance: number
  otherSavings: number
  enterpriseAnnuityMonthly: number
  personalPensionAnnual: number
  otherMonthlySaving: number
}

export interface AnnualCashFlowRow {
  year: number
  age: number
  spouseAge?: number
  phase: string
  salaryIncome: number
  pensionIncome: number
  tier2Income: number
  tier3Income: number
  totalIncome: number
  retirementExpense: number
  netCashFlow: number
  cumulativeBalance: number
}

export interface PensionCalculationResult {
  retirementAge: number
  expectedLifespan: number
  totalNeedPV: number
  tier1PV: number
  tier2PV: number
  tier3PV: number
  totalReservePV: number
  pensionGap: number
  monthlyPMT: number
  monthlyPension: number
  annualCashFlow: AnnualCashFlowRow[]
}

export interface ProductRecord {
  id: string
  name: string
  productType: string
  scenarioTags: string[]
  minAge: number
  maxAge: number
  highlights: string
}

// ---- 保障需求分析 ----
export interface InsuranceNeedsResult {
  lifeInsuranceNeed: number
  lifeInsuranceGap: number
  criticalIllnessNeed: number
  criticalIllnessGap: number
  medicalNeed: number
  medicalGap: number
  educationProtectionNeed: number
  totalProtectionGap: number
  priorityOrder: string[]
  details: Record<string, string>
}

export interface ScenarioParams {
  wageGrowthRate: number
  inflationRate: number
  returnRate: number
}

export const SCENARIO_DEFAULTS: Record<Scenario, ScenarioParams> = {
  optimistic:  { wageGrowthRate: 0.05, inflationRate: 0.015, returnRate: 0.08 },
  neutral:     { wageGrowthRate: 0.03, inflationRate: 0.03,  returnRate: 0.03 },
  pessimistic: { wageGrowthRate: 0.01, inflationRate: 0.04,  returnRate: 0.02 },
}

export interface CityOption {
  code: string
  name: string
  tier: CityTier
  isEstimated?: boolean
  isOverseas?: boolean
}

export interface ApiResponse<T = unknown> {
  success: boolean
  data?: T
  error?: string
  code?: number
}
