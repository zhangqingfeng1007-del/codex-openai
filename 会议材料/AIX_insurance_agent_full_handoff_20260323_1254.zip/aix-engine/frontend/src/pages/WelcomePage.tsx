/**
 * 欢迎主页 — §9.0.4②
 * 品牌展示 + 流程说明 + 核心主张
 */
import { motion } from 'framer-motion'
import { ArrowRight, ShieldCheck, GraduationCap, PiggyBank, BarChart3, FileText } from 'lucide-react'
import Logo from '../components/Logo'

interface Props {
  onStart: () => void
}

const STEPS = [
  {
    num: '01',
    icon: <ShieldCheck size={20} />,
    title: '基本信息',
    desc: '家庭结构、社保状况、子女情况',
    color: '#0071E3',
  },
  {
    num: '02',
    icon: <BarChart3 size={20} />,
    title: '家庭财务',
    desc: '收支结构、资产负债健康评分',
    color: '#34C759',
  },
  {
    num: '03',
    icon: <GraduationCap size={20} />,
    title: '教育规划',
    desc: '四条路径、含通胀全周期费用',
    color: '#FF9500',
  },
  {
    num: '04',
    icon: <PiggyBank size={20} />,
    title: '养老测算',
    desc: '三支柱精算、缺口与月储蓄目标',
    color: '#AF52DE',
  },
  {
    num: '05',
    icon: <FileText size={20} />,
    title: '综合报告',
    desc: 'AI生成专属规划报告与产品建议',
    color: '#FF3B30',
  },
]

const FEATURES = [
  { label: '精算级公式', desc: '国家标准延迟退休+个人账户利率' },
  { label: '全情景测算', desc: '悲观 / 中性 / 乐观三情景覆盖' },
  { label: 'AI顾问报告', desc: '一键生成专属家庭保障规划书' },
]

export default function WelcomePage({ onStart }: Props) {
  return (
    <div className="min-h-screen bg-bg-base flex flex-col">

      {/* 顶部导航条 */}
      <header className="h-14 border-b border-bg-border flex items-center px-6">
        <Logo height={32} />
      </header>

      {/* Hero 区域 */}
      <section className="flex-1 flex flex-col items-center justify-center px-6 py-16 text-center">
        <motion.div
          className="max-w-2xl w-full space-y-10"
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55, ease: 'easeOut' }}
        >
          {/* Logo 大号展示 §9.0.4② height=56px */}
          <div className="flex justify-center">
            <Logo height={56} withSlogan />
          </div>

          {/* 核心主张 */}
          <div className="space-y-3">
            <h1 className="text-4xl font-bold text-text-primary leading-tight tracking-tight">
              每个人都是<span className="text-accent">保险专家</span>
            </h1>
            <p className="text-text-secondary text-lg leading-relaxed">
              填写一份家庭信息，获得精算级养老缺口、教育规划与保障方案
            </p>
          </div>

          {/* CTA 按钮 */}
          <motion.button
            onClick={onStart}
            className="btn-primary inline-flex items-center gap-2.5 px-10 py-3.5 text-base font-medium"
            whileHover={{ scale: 1.03 }}
            whileTap={{ scale: 0.97 }}
            transition={{ duration: 0.1 }}
          >
            开始免费测算
            <ArrowRight size={18} />
          </motion.button>

          {/* 三点特性 */}
          <div className="grid grid-cols-3 gap-4">
            {FEATURES.map((f, i) => (
              <motion.div
                key={f.label}
                className="bg-bg-card border border-bg-border rounded-xl p-4 text-left"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.15 + i * 0.08, duration: 0.4, ease: 'easeOut' }}
              >
                <div className="text-text-primary font-semibold text-sm mb-1">{f.label}</div>
                <div className="text-text-muted text-xs leading-relaxed">{f.desc}</div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </section>

      {/* 流程展示区 */}
      <section className="border-t border-bg-border bg-bg-card py-12 px-6">
        <div className="max-w-4xl mx-auto">
          <p className="text-center text-text-muted text-xs mb-8 tracking-widest uppercase">
            五步完成家庭保障规划
          </p>

          {/* 横向流程卡片 */}
          <div className="flex items-start gap-0">
            {STEPS.map((step, idx) => (
              <div key={step.num} className="flex items-start flex-1">
                <motion.div
                  className="flex-1 flex flex-col items-center text-center gap-3"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: 0.1 + idx * 0.1, duration: 0.4, ease: 'easeOut' }}
                >
                  {/* 图标圆 */}
                  <div
                    className="w-12 h-12 rounded-full flex items-center justify-center"
                    style={{ background: `${step.color}18`, border: `1.5px solid ${step.color}40`, color: step.color }}
                  >
                    {step.icon}
                  </div>

                  {/* 步骤号 */}
                  <span className="text-xs font-mono" style={{ color: step.color }}>
                    {step.num}
                  </span>

                  {/* 标题 + 描述 */}
                  <div>
                    <div className="text-text-primary font-semibold text-sm">{step.title}</div>
                    <div className="text-text-muted text-xs mt-1 leading-relaxed px-1">{step.desc}</div>
                  </div>
                </motion.div>

                {/* 连接箭头（最后一个不显示） */}
                {idx < STEPS.length - 1 && (
                  <div className="flex items-center pt-5 px-1 text-bg-border shrink-0">
                    <ArrowRight size={14} />
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 底部 */}
      <footer className="h-12 border-t border-bg-border flex items-center justify-center">
        <span className="text-text-muted text-xs">
          © 2025 AIX爱选科技 · 仅供专业顾问内部使用 · 数据本地存储，不上传个人隐私
        </span>
      </footer>
    </div>
  )
}
