/**
 * AIX 保险智能测算引擎 — 模块仪表盘
 *
 * ⚠️ 定位：这是 AIX 测算引擎的内部入口面板，不是产品总站首页。
 *   - 总站首页入口：ChatPage（保险智能体，activeModule='chat'）
 *   - 本页面由路由卡"填写信息规划"跳转至 Module1 后可从侧边栏访问
 *   - App.tsx default case → ChatPage（不再是本页面）
 *   - 如后续测算引擎独立部署，本页面可作为其内部导航首页
 *
 * 模块顺序：基本信息→财务状况→保障需求→教育规划→养老测算→综合分析→产品推荐
 */
import { motion } from 'framer-motion'
import Logo from '../components/Logo'
import { useStore, ModuleStatus } from '../store/useStore'

interface CardDef {
  emoji: string
  title: string
  desc: string
  module: 1 | 2 | 3 | 4 | 5 | 6 | 7
  statusKey: 'module1Status' | 'module2Status' | 'module3Status' | 'module4Status' | 'module5Status' | 'module67Status'
}

const CARDS: CardDef[] = [
  { emoji: '👨‍👩‍👧', title: '家庭信息',  desc: '录入基本信息',   module: 1, statusKey: 'module1Status' },
  { emoji: '📊',    title: '财务分析',  desc: '评估收支状况',   module: 2, statusKey: 'module2Status' },
  { emoji: '🛡️',    title: '保障需求',  desc: '量化保障缺口',   module: 3, statusKey: 'module3Status' },
  { emoji: '🎓',    title: '教育规划',  desc: '测算教育成本',   module: 4, statusKey: 'module4Status' },
  { emoji: '🏦',    title: '养老测算',  desc: '分析养老缺口',   module: 5, statusKey: 'module5Status' },
  { emoji: '🤖',    title: '综合分析',  desc: '智能规划建议',   module: 6, statusKey: 'module67Status' },
  { emoji: '🎯',    title: '产品推荐',  desc: '精准匹配方案',   module: 7, statusKey: 'module67Status' },
]

const STATUS_BADGE: Record<ModuleStatus, { dot: string; label: string }> = {
  empty:    { dot: 'bg-text-muted/40',  label: '未开始' },
  partial:  { dot: 'bg-yellow-400',     label: '进行中' },
  complete: { dot: 'bg-green-400',      label: '已完成' },
}

export default function HomePage() {
  const { setActiveModule, module1Status, module2Status, module3Status, module4Status, module5Status, pensionResult, financialScore } = useStore()

  // Module 6/7 可访问性 = 至少完成了养老或财务
  const module67Status: ModuleStatus = (pensionResult || financialScore) ? 'complete' : 'empty'

  const statusMap: Record<CardDef['statusKey'], ModuleStatus> = {
    module1Status,
    module2Status,
    module3Status,
    module4Status,
    module5Status,
    module67Status,
  }

  // 核心步骤：基本信息 → 财务 → 保障 → 教育 → 养老
  const completedCount = [module1Status, module2Status, module3Status, module4Status, module5Status].filter(s => s === 'complete').length
  const totalSteps = 5

  // 找到第一个未完成的模块
  const nextModule = (
    module1Status !== 'complete' ? 1 :
    module2Status !== 'complete' ? 2 :
    module3Status !== 'complete' ? 3 :
    module4Status !== 'complete' ? 4 :
    module5Status !== 'complete' ? 5 : 6
  ) as 1 | 2 | 3 | 4 | 5 | 6

  const hasStarted = module1Status !== 'empty'

  const MODULE_NAMES = ['基本信息', '财务分析', '保障需求', '教育规划', '养老测算', '综合分析']

  return (
    <div className="min-h-full flex items-center justify-center py-10 px-8">
      <motion.div
        className="w-full max-w-2xl flex flex-col items-center gap-8"
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.45, ease: 'easeOut' }}
      >
        {/* Logo */}
        <Logo height={64} />

        {/* 标题 */}
        <div className="text-center space-y-2">
          <h1 className="text-3xl font-bold text-text-primary tracking-tight">
            AIX保险智能测算引擎
          </h1>
          <p className="text-text-secondary text-base">专业家庭财务保障规划平台</p>
        </div>

        {/* 进度总览 */}
        {hasStarted && (
          <motion.div
            className="w-full bg-bg-card border border-bg-border rounded-xl px-6 py-4 flex items-center gap-4"
            initial={{ opacity: 0, scale: 0.97 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.15 }}
          >
            <div className="flex-1">
              <div className="flex justify-between text-xs text-text-muted mb-2">
                <span>测算进度</span>
                <span className="text-accent font-medium">{completedCount} / {totalSteps} 完成</span>
              </div>
              <div className="h-1.5 bg-bg-float rounded-full overflow-hidden">
                <motion.div
                  className="h-full bg-accent rounded-full"
                  initial={{ width: 0 }}
                  animate={{ width: `${(completedCount / totalSteps) * 100}%` }}
                  transition={{ delay: 0.3, duration: 0.6, ease: 'easeOut' }}
                />
              </div>
            </div>
            <button
              onClick={() => setActiveModule(nextModule)}
              className="btn-primary text-sm px-4 py-2 shrink-0"
            >
              继续测算 →
            </button>
          </motion.div>
        )}

        {/* 功能卡片 */}
        <div className="grid grid-cols-3 gap-4 w-full">
          {CARDS.map((card, i) => {
            const st = statusMap[card.statusKey]
            const badge = STATUS_BADGE[st]
            return (
              <motion.button
                key={card.title}
                onClick={() => setActiveModule(card.module)}
                className="bg-bg-card border border-bg-border rounded-xl p-5 flex flex-col items-center gap-2 text-center hover:bg-bg-float hover:border-accent/30 transition-all relative overflow-hidden"
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.1 + i * 0.06, duration: 0.35, ease: 'easeOut' }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <span className={`absolute top-2.5 right-2.5 w-2 h-2 rounded-full ${badge.dot}`} title={badge.label} />
                <span className="text-3xl leading-none">{card.emoji}</span>
                <div className="text-text-primary font-semibold text-sm">{card.title}</div>
                <div className="text-text-muted text-xs">{card.desc}</div>
                {st === 'complete' && (
                  <div className="text-green-400 text-[10px] font-medium">✓ 已完成</div>
                )}
                {st === 'partial' && (
                  <div className="text-yellow-400 text-[10px] font-medium">进行中</div>
                )}
              </motion.button>
            )
          })}
        </div>

        {/* CTA 按钮 */}
        <motion.button
          onClick={() => setActiveModule(hasStarted ? nextModule : 1)}
          className="btn-primary w-full py-4 text-base font-semibold tracking-wide"
          whileHover={{ scale: 1.01 }}
          whileTap={{ scale: 0.99 }}
          transition={{ duration: 0.1 }}
        >
          {hasStarted ? `继续测算（${MODULE_NAMES[nextModule - 1]}）→` : '开始测算 →'}
        </motion.button>

        <p className="text-text-muted text-xs">
          测算结果仅供参考，不构成专业投资建议
        </p>
      </motion.div>
    </div>
  )
}
