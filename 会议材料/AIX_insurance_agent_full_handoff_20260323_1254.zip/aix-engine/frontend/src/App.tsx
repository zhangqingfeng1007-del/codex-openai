import { useEffect, useState } from 'react'
import { AnimatePresence, motion } from 'framer-motion'
import MainLayout from './layouts/MainLayout'
import PrivacyConsent, { hasConsented } from './components/PrivacyConsent'
import HomePage from './pages/HomePage'
import Module1 from './modules/module1/Module1'
import Module2 from './modules/module2/Module2'
import Module3 from './modules/module3/Module3'
import Module4 from './modules/module4/Module4'
import Module5 from './modules/module5/Module5'
import Module6 from './modules/module6/Module6'
import Module7 from './modules/module7/Module7'
import AdminPanel from './admin/AdminPanel'
import ChatPage from './modules/chat/ChatPage'
import ErrorBoundary from './components/ErrorBoundary'
import { useStore } from './store/useStore'
import { createSession } from './api/client'

export default function App() {
  const { activeModule, sessionId, setSessionId, setActiveModule } = useStore()
  const [consented, setConsented] = useState(hasConsented)

  useEffect(() => {
    if (!sessionId) {
      createSession()
        .then(data => setSessionId(data.id))
        .catch(console.error)
    }
  }, [sessionId, setSessionId])

  const renderContent = () => {
    switch (activeModule) {
      case 'home':  return <HomePage />   // AIX 测算引擎内部入口（不作为总站默认首页）
      case 1:       return <Module1 />
      case 2:       return <Module2 />
      case 3:       return <Module3 />
      case 4:       return <Module7 />
      case 5:       return <Module4 />
      case 6:       return <Module5 />
      case 7:       return <Module6 />
      case 'admin': return <AdminPanel />
      case 'chat':  return <ChatPage />
      default:      return <ChatPage />  // 未知模块 → 保险智能体首页
    }
  }

  const isFullHeight = activeModule === 'home' || activeModule === 'chat'

  if (!consented) {
    return <PrivacyConsent onAccept={() => setConsented(true)} />
  }

  return (
    <ErrorBoundary>
      <MainLayout>
        <AnimatePresence mode="wait">
          <motion.div
            key={String(activeModule)}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            transition={{ duration: 0.2, ease: 'easeInOut' }}
            className={isFullHeight ? 'h-full' : 'max-w-4xl mx-auto px-8 py-8'}
          >
            {/* 每个模块独立 ErrorBoundary，崩溃时可返回首页 */}
            <ErrorBoundary
              onReset={() => setActiveModule('chat')}
              fallback={
                <div className="flex flex-col items-center justify-center min-h-[50vh] gap-4 text-center">
                  <span className="text-5xl">⚠️</span>
                  <h2 className="text-lg font-semibold text-text-primary">该模块出现异常</h2>
                  <p className="text-text-secondary text-sm">您的数据已自动保存，可切换到其他模块继续操作。</p>
                  <button onClick={() => setActiveModule('chat')} className="btn-primary px-6 py-2.5">
                    返回首页
                  </button>
                </div>
              }
            >
              {renderContent()}
            </ErrorBoundary>
          </motion.div>
        </AnimatePresence>
      </MainLayout>
    </ErrorBoundary>
  )
}
