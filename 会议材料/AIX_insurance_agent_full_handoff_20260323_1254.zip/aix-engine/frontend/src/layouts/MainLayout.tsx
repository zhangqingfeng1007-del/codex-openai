import { ReactNode, useState } from 'react'
import { useStore, ModuleStatus } from '../store/useStore'
import Logo from '../components/Logo'
import { Settings, Smartphone, Monitor, FolderOpen, Save, Trash2, Check, MessageSquare } from 'lucide-react'

const NAV_ITEMS = [
  { id: 1 as const, label: '基本信息', emoji: '👤' },
  { id: 2 as const, label: '财务状况', emoji: '💰' },
  { id: 3 as const, label: '教育规划', emoji: '📚' },
  { id: 4 as const, label: '保障需求', emoji: '🛡️' },
  { id: 5 as const, label: '养老测算', emoji: '🏦' },
  { id: 6 as const, label: '综合分析', emoji: '📊' },
  { id: 7 as const, label: '产品推荐', emoji: '🎯' },
]

function StatusDot({ status }: { status: ModuleStatus }) {
  if (status === 'complete') return <span className="flex items-center justify-center w-4 h-4 rounded-full bg-accent-success/15 text-accent-success"><Check size={10} strokeWidth={3} /></span>
  if (status === 'partial') return <span className="w-2 h-2 rounded-full bg-accent-warning" />
  return null
}

const BOTTOM_NAV = [
  { id: 'home' as const, label: '首页',  emoji: '🏠' },
  { id: 1     as const, label: '基本',  emoji: '👤' },
  { id: 2     as const, label: '财务',  emoji: '💰' },
  { id: 3     as const, label: '教育',  emoji: '📚' },
  { id: 4     as const, label: '保障',  emoji: '🛡️' },
  { id: 5     as const, label: '养老',  emoji: '🏦' },
  { id: 6     as const, label: '分析',  emoji: '📊' },
  { id: 7     as const, label: '产品',  emoji: '🎯' },
  { id: 'chat' as const, label: 'AI',   emoji: '💬' },
]

const RIGHT_PANEL_HINTS: Record<string, { icon: string; text: string }> = {
  home:  { icon: '📋', text: '填写基本信息后，后续模块将自动带入城市、社保等数据' },
  '1':   { icon: '👤', text: '填写本人及配偶的基本信息，是后续精算的基础数据' },
  '2':   { icon: '💰', text: '收支结构与资产状况将影响财务健康评分与储蓄目标' },
  '3':   { icon: '🎓', text: '选择教育路径后，系统将按通胀率测算全周期费用' },
  '4':   { icon: '🛡️', text: '量化寿险、重疾、医疗保障缺口，教育费用将纳入寿险保额计算' },
  '5':   { icon: '🏦', text: '三支柱精算：社保养老金 + 企业年金 + 个人储蓄' },
  '6':   { icon: '📝', text: 'AI将根据您填写的数据生成专属保障规划报告' },
  '7':   { icon: '🎯', text: '基于保障缺口、养老缺口、教育费用和财务评分，自动匹配保险产品' },
  admin: { icon: '⚙️', text: '调整精算参数和情景假设后，重新计算即可生效' },
}

function RightPanel() {
  const { activeModule, customer, profiles, saveProfile, loadProfile, deleteProfile, reset, setActiveModule } = useStore()
  const key = String(activeModule)
  const hint = RIGHT_PANEL_HINTS[key] ?? RIGHT_PANEL_HINTS['home']
  const [showProfiles, setShowProfiles] = useState(false)

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* 提示区 */}
      <div className="p-5 flex flex-col items-center text-center gap-3">
        <span className="text-4xl">{hint.icon}</span>
        <p className="text-text-muted text-xs leading-relaxed max-w-[170px]">{hint.text}</p>
        {customer?.age && (
          <div className="w-full text-left bg-bg-float rounded-xl p-3">
            <div className="text-text-muted text-xs mb-1">当前客户</div>
            <div className="text-text-primary text-sm font-medium">
              {customer.age} 岁 · {customer.gender === 'male' ? '男' : '女'}
            </div>
            {customer.cityWork && (
              <div className="text-text-secondary text-xs mt-0.5">{customer.cityWork}</div>
            )}
          </div>
        )}
      </div>

      {/* 客户档案区 */}
      <div className="border-t border-black/[0.06] flex flex-col flex-1 overflow-hidden">
        <div className="flex items-center justify-between px-4 py-2.5">
          <button
            onClick={() => setShowProfiles(v => !v)}
            className="flex items-center gap-1.5 text-xs text-text-secondary hover:text-text-primary transition-colors"
          >
            <FolderOpen size={13} />
            <span>客户档案 ({profiles.length})</span>
          </button>
          {customer?.age && (
            <button
              onClick={() => { saveProfile(); setShowProfiles(true) }}
              className="flex items-center gap-1 text-xs text-accent hover:text-accent-light transition-colors px-1.5 py-0.5 rounded-lg hover:bg-accent/5"
              title="保存当前客户档案"
            >
              <Save size={12} /> 保存
            </button>
          )}
        </div>

        {showProfiles && (
          <div className="flex-1 overflow-y-auto px-3 pb-3 space-y-2">
            {profiles.length === 0 && (
              <p className="text-text-muted text-xs text-center py-4">暂无保存的档案</p>
            )}
            {profiles.map(p => (
              <div key={p.id} className="bg-bg-float rounded-xl p-2.5 text-xs group">
                <div className="flex items-center justify-between gap-1">
                  <button
                    onClick={() => { loadProfile(p.id); setShowProfiles(false) }}
                    className="text-left flex-1 hover:text-accent transition-colors"
                  >
                    <div className="font-medium text-text-primary truncate">{p.name}</div>
                    <div className="text-text-muted mt-0.5">{p.savedAt}</div>
                  </button>
                  <button onClick={() => deleteProfile(p.id)} className="text-text-muted hover:text-accent-danger opacity-0 group-hover:opacity-100 transition-all p-0.5 shrink-0">
                    <Trash2 size={12} />
                  </button>
                </div>
              </div>
            ))}

            {customer?.age && (
              <button
                onClick={() => { reset(); setActiveModule('home') }}
                className="w-full text-xs text-text-muted hover:text-accent-danger py-2 border border-dashed border-bg-border rounded-xl hover:border-accent-danger/50 transition-colors mt-2"
              >
                + 新建客户
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  )
}

interface Props {
  children: ReactNode
}

export default function MainLayout({ children }: Props) {
  const { activeModule, setActiveModule, module1Status, module2Status, module3Status, module4Status, module5Status, pensionResult } = useStore()
  const [mobileView, setMobileView] = useState(false)

  // step→status 映射（步骤重排后：3=教育, 4=保障, 5=养老, 6=综合分析, 7=产品推荐）
  const stepStatus: Record<number, ModuleStatus> = {
    1: module1Status,
    2: module2Status,
    3: module4Status,   // 教育规划
    4: module3Status,   // 保障需求
    5: module5Status,   // 养老测算
    6: pensionResult ? 'complete' : 'empty',  // 综合分析依赖养老结果
    7: 'empty',         // 产品推荐无独立状态
  }

  return (
    <div className="flex flex-col h-screen bg-bg-base overflow-hidden">

      {/* ── 顶部导航栏 — 毛玻璃效果 ── */}
      <header className="h-12 bg-white/80 backdrop-blur-xl border-b border-black/[0.08] flex items-center shrink-0 z-30 sticky top-0">

        {/* Logo — 点击回 chat 首页 */}
        <div className={`shrink-0 flex items-center px-5 ${mobileView ? 'w-auto' : activeModule === 'chat' ? 'w-auto' : 'w-[220px]'}`}>
          <button
            onClick={() => setActiveModule('chat')}
            className="opacity-90 hover:opacity-100 transition-opacity"
            title="保险智能体首页"
          >
            <Logo height={mobileView ? 28 : 32} />
          </button>
        </div>

        {/* 中心标题 — 网页版显示（chat 模式下隐藏，由页面主体大标题承担） */}
        {!mobileView && activeModule !== 'chat' && (
          <div className="flex-1 text-center">
            <span className="text-text-primary font-semibold text-base tracking-tight">
              保险智能体 · 测算引擎
            </span>
          </div>
        )}
        {!mobileView && activeModule === 'chat' && <div className="flex-1" />}

        {/* 手机版标题 */}
        {mobileView && (
          <div className="flex-1 text-center">
            <span className="text-text-secondary text-sm">
              {activeModule === 'chat' ? '保险智能体' :
               activeModule === 'home' ? '测算引擎' :
               NAV_ITEMS.find(n => n.id === activeModule)?.label ?? '管理后台'}
            </span>
          </div>
        )}

        {/* 右侧操作 */}
        <div className={`shrink-0 flex items-center justify-end px-5 gap-2 ${mobileView ? 'w-auto' : 'w-64'}`}>
          {/* 视图切换 */}
          <button
            onClick={() => setMobileView(v => !v)}
            className={`flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg text-xs transition-all ${
              mobileView
                ? 'bg-accent/10 text-accent'
                : 'text-text-muted hover:text-text-secondary hover:bg-black/[0.04]'
            }`}
            title={mobileView ? '切换到网页版' : '切换到手机版'}
          >
            {mobileView ? <Monitor size={14} /> : <Smartphone size={14} />}
            {mobileView ? '网页版' : '手机版'}
          </button>

          {/* 后台管理 — 网页版显示 */}
          {!mobileView && (
            <button
              onClick={() => setActiveModule('admin')}
              className={`p-1.5 rounded-lg transition-all ${
                activeModule === 'admin'
                  ? 'text-accent bg-accent/10'
                  : 'text-text-muted hover:text-text-secondary hover:bg-black/[0.04]'
              }`}
              title="后台管理"
            >
              <Settings size={16} />
            </button>
          )}
        </div>
      </header>

      {/* ── 手机版布局 ── */}
      {mobileView && (
        <div className="flex flex-col flex-1 overflow-hidden">
          {/* 内容区（居中模拟手机宽度） */}
          <main className="flex-1 overflow-y-auto">
            <div className="max-w-sm mx-auto">
              {children}
            </div>
          </main>

          {/* 底部导航栏 — 毛玻璃 */}
          <nav className="border-t border-black/[0.08] bg-white/80 backdrop-blur-xl flex shrink-0 safe-area-bottom">
            {BOTTOM_NAV.map(item => {
              const isActive = activeModule === item.id
              const status = typeof item.id === 'number' ? (stepStatus[item.id] ?? 'empty') : 'empty'
              return (
                <button
                  key={String(item.id)}
                  onClick={() => setActiveModule(item.id)}
                  className={`flex-1 flex flex-col items-center justify-center py-2 gap-0.5 text-xs transition-colors relative ${
                    isActive ? 'text-accent' : 'text-text-muted hover:text-text-secondary'
                  }`}
                >
                  <span className="text-lg leading-none">{item.emoji}</span>
                  <span className="text-[10px]">{item.label}</span>
                  {status === 'complete' && <span className="absolute top-1.5 right-1/4 w-1.5 h-1.5 rounded-full bg-accent-success" />}
                  {status === 'partial' && <span className="absolute top-1.5 right-1/4 w-1.5 h-1.5 rounded-full bg-accent-warning" />}
                </button>
              )
            })}
          </nav>
        </div>
      )}

      {/* ── 网页版布局（三栏 / chat 全宽） ── */}
      {!mobileView && (
        <div className="flex flex-1 overflow-hidden">

          {/* 左侧边栏 — chat 模式隐藏 */}
          <aside className={`w-[220px] bg-bg-float/50 flex flex-col shrink-0 overflow-y-auto transition-all ${activeModule === 'chat' ? 'hidden' : ''}`}>
            <div className="px-5 pt-4 pb-2 text-text-muted text-xs tracking-widest uppercase">
              测算流程
            </div>
            <nav className="flex-1 py-1 px-2">
              {NAV_ITEMS.map(item => {
                const isActive = activeModule === item.id
                const status = stepStatus[item.id] ?? 'empty'
                return (
                  <button
                    key={item.id}
                    onClick={() => setActiveModule(item.id)}
                    className={`
                      w-full flex items-center gap-3 px-3 py-2.5 text-sm transition-all rounded-lg mb-0.5
                      ${isActive
                        ? 'text-accent bg-accent/10 font-medium'
                        : 'text-text-secondary hover:text-text-primary hover:bg-black/[0.04]'}
                    `}
                  >
                    <span className="text-base leading-none">{item.emoji}</span>
                    <span className="flex-1 text-left">{item.label}</span>
                    <StatusDot status={status} />
                  </button>
                )
              })}
              {/* AI顾问入口 */}
              <div className="mt-2 mb-1 border-t border-black/[0.06]" />
              <button
                onClick={() => setActiveModule('chat')}
                className={`
                  w-full flex items-center gap-3 px-3 py-2.5 text-sm transition-all rounded-lg mb-0.5
                  ${activeModule === 'chat'
                    ? 'text-accent bg-accent/10 font-medium'
                    : 'text-text-secondary hover:text-text-primary hover:bg-black/[0.04]'}
                `}
              >
                <MessageSquare size={16} className="shrink-0" />
                <span className="flex-1 text-left">AI顾问</span>
              </button>
            </nav>
          </aside>

          {/* 内容区 */}
          <main className="flex-1 overflow-y-auto">
            {children}
          </main>

          {/* 右面板 — chat 模式隐藏 */}
          <aside className={`w-64 border-l border-black/[0.06] flex flex-col shrink-0 overflow-y-auto ${activeModule === 'chat' ? 'hidden' : ''}`}>
            <div className="h-12 border-b border-black/[0.06] flex items-center px-5">
              <span className="text-text-primary font-semibold text-sm">📈 实时测算</span>
            </div>
            <RightPanel />
          </aside>
        </div>
      )}
    </div>
  )
}
