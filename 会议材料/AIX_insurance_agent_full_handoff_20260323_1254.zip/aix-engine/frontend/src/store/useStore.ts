import { create } from 'zustand'
import { devtools, persist } from 'zustand/middleware'
import { v4 as uuidv4 } from 'uuid'
import type {
  CustomerBasicInfo, FinancialInfo, FinancialScore,
  EducationPlanResult, PensionCalculationResult,
  InsuranceNeedsResult,
  Scenario, ScenarioParams, ChildInfo,
} from '../types'
import { SCENARIO_DEFAULTS } from '../types'
import { saveProfileToServer, deleteProfileFromServer, listProfiles as fetchProfiles, getProfile as fetchProfile } from '../api/client'

export type ModuleStatus = 'empty' | 'partial' | 'complete'

export interface CustomerProfile {
  id: string
  name: string
  savedAt: string
  customer: Partial<CustomerBasicInfo> | null
  financial: Partial<FinancialInfo> | null
  financialScore: FinancialScore | null
  educationResult: EducationPlanResult | null
  pensionResult: PensionCalculationResult | null
  insuranceNeedsResult: InsuranceNeedsResult | null
  scenario: Scenario
  module1Status: ModuleStatus
  module2Status: ModuleStatus
  module3Status: ModuleStatus  // 保障需求
  module4Status: ModuleStatus  // 教育规划
  module5Status: ModuleStatus  // 养老测算
}

export interface NeedsReportSummary {
  age: number
  gender: string
  primary_concern: string
  family_structure: string
  health_status?: string
  // 预算字段
  budget_annual?: number                         // 实际使用的年保费（元）
  budget_mode?: 'user_stated' | 'estimated'      // 预算来源
  budget_annual_estimated_min?: number           // 测算下限（元，estimated模式）
  budget_annual_estimated_max?: number           // 测算上限（元，estimated模式）
  budget_annual_recommended?: number             // 推荐预算（元）
}

export interface ProductRecommendation {
  product_id: string
  product_name: string
  company_name: string
  total_score: number
  annual_premium: number
  fair_premium?: number
  score_breakdown: Record<string, number>
  highlights?: string[]          // 2-4 核心亮点标签（后端生成）
  recommendation_reason?: string // 推荐理由（后端生成）
}

/**
 * 预算分配建议（后续实现，当前预留接口）
 *
 * 系统不仅测算总预算，还要回答：
 *   - 预算优先给谁（by_person）
 *   - 优先配置什么保障（by_coverage）
 */
export interface BudgetAllocation {
  by_person?: {
    self?: number       // 本人（元/年）
    spouse?: number     // 配偶（元/年）
    children?: number   // 子女合计（元/年）
  }
  by_coverage?: {
    critical_illness?: number  // 重疾险（元/年）
    medical?: number           // 医疗险（元/年）
    life?: number              // 寿险（元/年）
    other?: number             // 其他（元/年）
  }
  rationale?: string   // 分配说明文字
}

export interface ProductRecommendationsPayload {
  top3: ProductRecommendation[]
  conclusion?: string              // 推荐总结文字
  risk_notes?: string[]            // 风险提示列表
  budget_allocation?: BudgetAllocation  // 预算分配建议（后续实现）
}

export interface RouteOption {
  label: string
  action: 'navigate' | 'continue_chat'
  target?: string   // action=navigate 时为前端模块 key，如 'aix-engine'（填写信息规划=复用AIX测算引擎）
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant'
  content: string
  options?: string[]
  routeOptions?: RouteOption[]             // 意图路由卡片（show_options.route_options）
  imageUrl?: string                        // blob: URL，仅展示用，不持久化
  needsReport?: {
    report_id: string
    summary: NeedsReportSummary
  }
  productRecommendations?: ProductRecommendation[]
  recommendationsPayload?: ProductRecommendationsPayload  // 完整 payload（含 conclusion/risk_notes）
}

interface AIXStore {
  sessionId: string | null
  setSessionId: (id: string) => void
  chatMessages: ChatMessage[]
  setChatMessages: (msgs: ChatMessage[] | ((prev: ChatMessage[]) => ChatMessage[])) => void
  clearChatMessages: () => void
  profiles: CustomerProfile[]
  saveProfile: (name?: string) => void
  loadProfile: (id: string) => void
  deleteProfile: (id: string) => void
  syncProfilesFromServer: () => void
  scenario: Scenario
  scenarioParams: ScenarioParams
  scenariosConfig: Record<Scenario, ScenarioParams>
  setScenariosConfig: (config: Record<Scenario, ScenarioParams>) => void
  setScenario: (s: Scenario) => void
  customer: Partial<CustomerBasicInfo> | null
  updateCustomer: (patch: Partial<CustomerBasicInfo>) => void
  addChild: (child: ChildInfo) => void
  removeChild: (id: string) => void
  module1Status: ModuleStatus
  financial: Partial<FinancialInfo> | null
  updateFinancial: (patch: Partial<FinancialInfo>) => void
  financialScore: FinancialScore | null
  setFinancialScore: (s: FinancialScore) => void
  module2Status: ModuleStatus
  insuranceNeedsResult: InsuranceNeedsResult | null
  setInsuranceNeedsResult: (r: InsuranceNeedsResult) => void
  module3Status: ModuleStatus  // 保障需求
  educationResult: EducationPlanResult | null
  setEducationResult: (r: EducationPlanResult) => void
  module4Status: ModuleStatus  // 教育规划
  pensionResult: PensionCalculationResult | null
  setPensionResult: (r: PensionCalculationResult) => void
  module5Status: ModuleStatus  // 养老测算
  activeModule: 'home' | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 'admin' | 'chat'
  setActiveModule: (m: 'home' | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 'admin' | 'chat') => void
  activeProfileId: string | null
  reset: () => void
}

const m1Complete = (c: Partial<CustomerBasicInfo> | null): ModuleStatus => {
  if (!c) return 'empty'
  if (c.age && c.gender && c.cityWork && c.monthlyIncome) return 'complete'
  return 'partial'
}
const m2Complete = (f: Partial<FinancialInfo> | null): ModuleStatus => {
  if (!f) return 'empty'
  if (f.fixedMonthlyExpense !== undefined) return 'complete'
  return 'partial'
}

export const useStore = create<AIXStore>()(
  devtools(
    persist(
      (set, get) => ({
        sessionId: null,
        setSessionId: id => set({ sessionId: id }),

        chatMessages: [],
        setChatMessages: msgs => {
          if (typeof msgs === 'function') {
            set(state => ({ chatMessages: msgs(state.chatMessages) }))
          } else {
            set({ chatMessages: msgs })
          }
        },
        clearChatMessages: () => set({ chatMessages: [] }),

        profiles: [],
        saveProfile: (name?: string) => {
          const s = get()
          const label = name
            || s.customer?.name
            || (s.customer?.age ? `${s.customer.age}岁${s.customer.gender === 'male' ? '男' : '女'}客户` : '新客户')
          const profile: CustomerProfile = {
            id: uuidv4(),
            name: label,
            savedAt: new Date().toLocaleString('zh-CN'),
            customer: s.customer,
            financial: s.financial,
            financialScore: s.financialScore,
            educationResult: s.educationResult,
            pensionResult: s.pensionResult,
            insuranceNeedsResult: s.insuranceNeedsResult,
            scenario: s.scenario,
            module1Status: s.module1Status,
            module2Status: s.module2Status,
            module3Status: s.module3Status,
            module4Status: s.module4Status,
            module5Status: s.module5Status,
          }
          set(prev => ({ profiles: [profile, ...prev.profiles].slice(0, 20) }))
          saveProfileToServer(profile.id, profile.name, profile).catch(() => {})
        },
        loadProfile: (id: string) => {
          const p = get().profiles.find(pr => pr.id === id)
          if (!p) return
          set({
            customer: p.customer,
            financial: p.financial,
            financialScore: p.financialScore,
            educationResult: p.educationResult,
            pensionResult: p.pensionResult,
            insuranceNeedsResult: p.insuranceNeedsResult,
            scenario: p.scenario,
            scenarioParams: SCENARIO_DEFAULTS[p.scenario],
            module1Status: p.module1Status,
            module2Status: p.module2Status,
            module3Status: p.module3Status,
            module4Status: p.module4Status,
            module5Status: p.module5Status,
            activeModule: 'home',
            activeProfileId: id,
          })
        },
        deleteProfile: (id: string) => {
          set(prev => ({ profiles: prev.profiles.filter(p => p.id !== id) }))
          deleteProfileFromServer(id).catch(() => {})
        },
        syncProfilesFromServer: async () => {
          try {
            const serverList = await fetchProfiles()
            if (!Array.isArray(serverList) || serverList.length === 0) return
            const localIds = new Set(get().profiles.map(p => p.id))
            const newProfiles: CustomerProfile[] = []
            for (const item of serverList) {
              if (!localIds.has(item.id)) {
                try {
                  const full = await fetchProfile(item.id)
                  if (full?.data) newProfiles.push(full.data as CustomerProfile)
                } catch { /* skip */ }
              }
            }
            if (newProfiles.length > 0) {
              set(prev => ({
                profiles: [...prev.profiles, ...newProfiles].slice(0, 20),
              }))
            }
          } catch { /* server unavailable, use localStorage */ }
        },
        scenario: 'neutral',
        scenarioParams: SCENARIO_DEFAULTS['neutral'],
        scenariosConfig: SCENARIO_DEFAULTS,
        setScenariosConfig: config => set(state => ({
          scenariosConfig: config,
          scenarioParams: config[state.scenario] ?? state.scenarioParams,
        })),
        setScenario: s => set(state => ({ scenario: s, scenarioParams: state.scenariosConfig[s] ?? SCENARIO_DEFAULTS[s] })),

        customer: null,
        module1Status: 'empty',
        updateCustomer: patch => {
          const prev = get().customer || {}
          const customer = { ...prev, ...patch } as Partial<CustomerBasicInfo>
          set({ customer, module1Status: m1Complete(customer) })
        },
        addChild: child => {
          const prev = get().customer
          if (!prev) return
          const children = [...(prev.children || []), child]
          const c = { ...prev, children }
          set({ customer: c, module1Status: m1Complete(c) })
        },
        removeChild: id => {
          const prev = get().customer
          if (!prev) return
          const children = (prev.children || []).filter(c => c.id !== id)
          const c = { ...prev, children }
          set({ customer: c, module1Status: m1Complete(c) })
        },

        financial: null,
        module2Status: 'empty',
        financialScore: null,
        updateFinancial: patch => {
          const prev = get().financial || {}
          const customer = get().customer
          const personalSalary = customer?.monthlyIncome || 0
          const spouseSalary = customer?.spouse?.monthlyIncome || 0
          const merged = { ...prev, ...patch } as Partial<FinancialInfo>

          const personalTotal = personalSalary
            + (merged.personalRentalIncome || 0)
            + (merged.personalInvestmentIncome || 0)
            + (merged.personalOtherIncome || 0)
          const spouseTotal = spouseSalary
            + (merged.spouseRentalIncome || 0)
            + (merged.spouseInvestmentIncome || 0)
            + (merged.spouseOtherIncome || 0)

          const fixedExp = (merged.rentMonthly || 0)
            + (merged.dailyLivingMonthly || 0)
            + (merged.insurancePremiumMonthly || 0)
            + (merged.educationCurrentMonthly || 0)
            + (merged.otherFixedMonthly || 0)

          const assets = (merged.cashAndDeposits || 0)
            + (merged.investmentAssets || 0)
            + (merged.insuranceCashValue || 0)
            + (merged.otherFinancialAssets || 0)

          const f: Partial<FinancialInfo> = {
            ...merged,
            personalMonthlyIncome: personalTotal,
            spouseMonthlyIncome: customer?.hasSpouse ? spouseTotal : undefined,
            totalFamilyMonthlyIncome: personalTotal + (customer?.hasSpouse ? spouseTotal : 0),
            fixedMonthlyExpense: fixedExp,
            availableAssets: assets,
          }
          set({ financial: f, module2Status: m2Complete(f) })
        },
        setFinancialScore: s => set({ financialScore: s }),

        // 保障需求（新位置3）
        insuranceNeedsResult: null,
        module3Status: 'empty',
        setInsuranceNeedsResult: r => set({ insuranceNeedsResult: r, module3Status: 'complete' }),

        // 教育规划（新位置4）
        educationResult: null,
        module4Status: 'empty',
        setEducationResult: r => set({ educationResult: r, module4Status: 'complete' }),

        // 养老测算（新位置5）
        pensionResult: null,
        module5Status: 'empty',
        setPensionResult: r => set({ pensionResult: r, module5Status: 'complete' }),

        activeModule: 'chat' as const,
        setActiveModule: m => set({ activeModule: m }),
        activeProfileId: null,

        reset: () => set({
          customer: null, financial: null, financialScore: null,
          educationResult: null, pensionResult: null, insuranceNeedsResult: null,
          module1Status: 'empty', module2Status: 'empty',
          module3Status: 'empty', module4Status: 'empty', module5Status: 'empty',
          scenario: 'neutral', scenarioParams: SCENARIO_DEFAULTS['neutral'],
        }),
      }),
      {
        name: 'aix-session-v4',
        partialize: s => ({
          sessionId: s.sessionId,
          // imageUrl 是 blob: URL，页面关闭后失效，不持久化
          chatMessages: s.chatMessages.map(m => ({ ...m, imageUrl: undefined })),
          customer: s.customer,
          financial: s.financial,
          financialScore: s.financialScore,
          educationResult: s.educationResult,
          pensionResult: s.pensionResult,
          insuranceNeedsResult: s.insuranceNeedsResult,
          scenario: s.scenario,
          module1Status: s.module1Status,
          module2Status: s.module2Status,
          module3Status: s.module3Status,
          module4Status: s.module4Status,
          module5Status: s.module5Status,
          profiles: s.profiles,
        }),
      }
    )
  )
)
