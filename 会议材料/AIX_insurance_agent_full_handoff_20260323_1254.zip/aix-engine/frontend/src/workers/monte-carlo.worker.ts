/**
 * Monte Carlo simulation Web Worker for pension gap analysis
 * Runs N simulations with random walks for wage growth, inflation, and investment returns
 * Reports progress and returns percentile distributions (P10, P50, P90)
 */

interface SimulationParams {
  currentAge: number
  retirementAge: number
  expectedLifespan: number
  monthlyIncome: number           // current monthly salary
  monthlyExpenseAtRetirement: number // estimated monthly expense at retirement
  totalReservePV: number          // total pension reserves (3 pillars combined)
  monthlyPension: number          // estimated monthly pension income at retirement
  // Scenario base rates
  wageGrowthRate: number
  inflationRate: number
  returnRate: number
  // Volatility (standard deviation)
  wageVolatility?: number
  inflationVolatility?: number
  returnVolatility?: number
  numSimulations?: number
}

interface SimulationResult {
  type: 'progress' | 'result'
  progress?: number
  data?: {
    years: number[]
    p10: number[]
    p50: number[]
    p90: number[]
    mean: number[]
    successRate: number  // % of simulations where balance > 0 at lifespan end
  }
}

// Box-Muller transform for normal random numbers
function randn(): number {
  let u = 0, v = 0
  while (u === 0) u = Math.random()
  while (v === 0) v = Math.random()
  return Math.sqrt(-2.0 * Math.log(u)) * Math.cos(2.0 * Math.PI * v)
}

function runSimulation(params: SimulationParams): number[] {
  const {
    currentAge, retirementAge, expectedLifespan,
    monthlyIncome, monthlyExpenseAtRetirement,
    totalReservePV, monthlyPension,
    wageGrowthRate, inflationRate, returnRate,
    wageVolatility = 0.02, inflationVolatility = 0.01, returnVolatility = 0.04,
  } = params

  const totalYears = expectedLifespan - currentAge
  const yearsTilRetire = retirementAge - currentAge
  const balances: number[] = new Array(totalYears)

  let balance = totalReservePV
  let salary = monthlyIncome * 12
  let expense = monthlyExpenseAtRetirement * 12
  let pensionAnnual = monthlyPension * 12

  for (let y = 0; y < totalYears; y++) {
    // Random shocks for this year
    const wageShock = wageGrowthRate + wageVolatility * randn()
    const inflShock = inflationRate + inflationVolatility * randn()
    const retShock = returnRate + returnVolatility * randn()

    if (y < yearsTilRetire) {
      // Working phase: earn salary, save a portion, invest balance
      const annualSaving = salary * 0.3 // assume 30% savings rate
      balance = balance * (1 + retShock) + annualSaving
      salary *= (1 + wageShock)
    } else {
      // Retirement phase: draw pension, pay expenses, invest remainder
      const netInflow = pensionAnnual - expense
      balance = balance * (1 + retShock) + netInflow
      // Inflate expenses and pension
      expense *= (1 + inflShock)
      pensionAnnual *= (1 + Math.max(0, inflShock * 0.6)) // pension adjusts ~60% of inflation
    }

    balances[y] = balance
  }

  return balances
}

function percentile(arr: number[], p: number): number {
  const sorted = [...arr].sort((a, b) => a - b)
  const idx = (p / 100) * (sorted.length - 1)
  const lower = Math.floor(idx)
  const frac = idx - lower
  if (lower + 1 >= sorted.length) return sorted[lower]
  return sorted[lower] * (1 - frac) + sorted[lower + 1] * frac
}

self.onmessage = (e: MessageEvent<SimulationParams>) => {
  const params = e.data
  const N = params.numSimulations || 10000
  const totalYears = params.expectedLifespan - params.currentAge
  const allBalances: number[][] = [] // [simulation][year]

  const BATCH = 500
  for (let i = 0; i < N; i++) {
    allBalances.push(runSimulation(params))
    if ((i + 1) % BATCH === 0 || i === N - 1) {
      const msg: SimulationResult = { type: 'progress', progress: Math.round(((i + 1) / N) * 100) }
      self.postMessage(msg)
    }
  }

  // Compute percentiles per year
  const years: number[] = []
  const p10: number[] = []
  const p50: number[] = []
  const p90: number[] = []
  const mean: number[] = []

  for (let y = 0; y < totalYears; y++) {
    years.push(params.currentAge + y + 1)
    const col = allBalances.map(sim => sim[y])
    p10.push(percentile(col, 10))
    p50.push(percentile(col, 50))
    p90.push(percentile(col, 90))
    mean.push(col.reduce((s, v) => s + v, 0) / col.length)
  }

  // Success rate: balance > 0 at end of life
  const endBalances = allBalances.map(sim => sim[totalYears - 1])
  const successRate = endBalances.filter(b => b > 0).length / N * 100

  const result: SimulationResult = {
    type: 'result',
    data: { years, p10, p50, p90, mean, successRate },
  }
  self.postMessage(result)
}
