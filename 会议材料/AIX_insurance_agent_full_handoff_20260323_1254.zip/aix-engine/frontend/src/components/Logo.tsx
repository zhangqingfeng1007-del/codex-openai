/**
 * AIx 品牌标识组件
 *
 * 左上角轻量品牌标识，蓝色文字 "AIx"。
 * 颜色气质：蓝天感，清爽、可信、专业。
 * 视觉定位：不抢占页面中心「保险智能体」主标题的视觉重心。
 *
 * 当获取到品牌方正式 Logo 文件后，可在此处替换。
 */

interface LogoProps {
  /** 像素高度（字号自适应），导航栏默认 32px */
  height?: number
  withSlogan?: boolean  // 保留以兼容调用方，当前不使用
}

export default function Logo({ height = 32 }: LogoProps) {
  // 根据 height 推算合适字号
  const fontSize = Math.round(height * 0.65)
  const letterSpacing = '-0.02em'

  return (
    <span
      className="select-none font-bold tracking-tight"
      style={{
        fontSize,
        letterSpacing,
        color: '#2B7FE0',         // 蓝天蓝，清爽可信
        lineHeight: 1,
        fontFamily: 'Inter, system-ui, sans-serif',
      }}
      aria-label="AIx 保险智能体"
    >
      AI<span style={{ fontWeight: 300, fontStyle: 'italic' }}>x</span>
    </span>
  )
}
