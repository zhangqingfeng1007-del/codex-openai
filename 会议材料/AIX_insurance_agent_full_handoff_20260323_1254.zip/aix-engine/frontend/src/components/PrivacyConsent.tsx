/**
 * 隐私声明与用户同意弹窗 — 个人信息保护法合规（§11）
 * 首次访问时展示，用户同意后存入 localStorage
 */
import { useState } from 'react'
import { Shield, ChevronDown, ChevronUp } from 'lucide-react'

const CONSENT_KEY = 'aix-privacy-consent'

export function hasConsented(): boolean {
  return localStorage.getItem(CONSENT_KEY) === 'true'
}

export default function PrivacyConsent({ onAccept }: { onAccept: () => void }) {
  const [expanded, setExpanded] = useState(false)

  const handleAccept = () => {
    localStorage.setItem(CONSENT_KEY, 'true')
    onAccept()
  }

  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/40 backdrop-blur-sm p-4">
      <div className="bg-white rounded-2xl shadow-float max-w-lg w-full max-h-[85vh] flex flex-col overflow-hidden">
        {/* Header */}
        <div className="px-6 pt-6 pb-4 text-center">
          <div className="w-12 h-12 mx-auto mb-3 rounded-full bg-accent/10 flex items-center justify-center">
            <Shield size={24} className="text-accent" />
          </div>
          <h2 className="text-lg font-semibold text-text-primary">个人信息保护声明</h2>
          <p className="text-sm text-text-secondary mt-1">使用本系统前，请阅读并同意以下条款</p>
        </div>

        {/* Content */}
        <div className="px-6 flex-1 overflow-y-auto text-sm text-text-secondary leading-relaxed space-y-3">
          <p>
            AIX保险智能测算引擎（以下简称"本系统"）重视您的个人信息保护。根据《中华人民共和国个人信息保护法》等相关法律法规，
            我们在此向您说明个人信息的收集和使用规则：
          </p>

          <div className="bg-bg-float rounded-lg p-4 space-y-2">
            <h3 className="font-semibold text-text-primary">一、信息收集范围</h3>
            <ul className="list-disc pl-5 space-y-1">
              <li>基本信息：年龄、性别、工作城市、家庭成员概况</li>
              <li>财务信息：收入、支出、资产、负债概况</li>
              <li>社保信息：社保类型、缴费年限、缴费基数</li>
              <li>健康信息：健康状况自评（仅用于预期寿命估算）</li>
            </ul>
          </div>

          <div className="bg-bg-float rounded-lg p-4 space-y-2">
            <h3 className="font-semibold text-text-primary">二、信息使用目的</h3>
            <p>上述信息仅用于：</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>养老缺口测算、教育成本规划、保障需求分析</li>
              <li>生成个性化保险规划报告及产品推荐</li>
              <li>本地会话保存，便于您下次继续操作</li>
            </ul>
          </div>

          <button
            onClick={() => setExpanded(v => !v)}
            className="flex items-center gap-1 text-accent text-xs font-medium hover:underline"
          >
            {expanded ? '收起详细条款' : '展开详细条款'}
            {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
          </button>

          {expanded && (
            <div className="space-y-3 text-xs border-t border-bg-border pt-3">
              <div>
                <h3 className="font-semibold text-text-primary">三、信息存储与安全</h3>
                <ul className="list-disc pl-5 space-y-1 mt-1">
                  <li>会话数据存储于浏览器本地（localStorage）及服务端加密数据库</li>
                  <li>服务端敏感数据采用 AES-256 加密存储</li>
                  <li>会话数据自创建起保留90天，届时自动清除</li>
                  <li>数据传输全程使用 HTTPS 加密</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-text-primary">四、信息共享</h3>
                <p className="mt-1">我们不会将您的个人信息出售、交换或出租给任何第三方。AI报告生成过程中，
                仅将脱敏后的测算结果（非原始个人信息）传输至AI服务接口。</p>
              </div>
              <div>
                <h3 className="font-semibold text-text-primary">五、您的权利</h3>
                <ul className="list-disc pl-5 space-y-1 mt-1">
                  <li>您可随时通过"重置会话"功能清除所有本地及服务端数据</li>
                  <li>您可拒绝提供任何可选信息（仅影响对应模块的测算精度）</li>
                  <li>您有权要求删除已保存的客户档案</li>
                </ul>
              </div>
              <div>
                <h3 className="font-semibold text-text-primary">六、免责声明</h3>
                <p className="mt-1">本系统提供的测算结果和规划建议仅供参考，不构成任何形式的投资建议或保险产品购买建议。
                实际保险方案请以保险公司正式合同为准。</p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-5 border-t border-bg-border space-y-3">
          <button
            onClick={handleAccept}
            className="btn-primary w-full py-3 text-sm font-semibold"
          >
            我已阅读并同意
          </button>
          <p className="text-xs text-text-muted text-center">
            点击"我已阅读并同意"即表示您同意本隐私声明的全部内容
          </p>
        </div>
      </div>
    </div>
  )
}
