import { Component, ReactNode } from 'react'

interface Props {
  children: ReactNode
  /** 提供自定义 fallback UI；默认显示通用错误页 */
  fallback?: ReactNode
  /** 错误恢复按钮的回调（默认 reload 页面） */
  onReset?: () => void
}

interface State {
  hasError: boolean
  error: Error | null
}

export default class ErrorBoundary extends Component<Props, State> {
  state: State = { hasError: false, error: null }

  static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error }
  }

  componentDidCatch(error: Error, info: React.ErrorInfo) {
    console.error('[ErrorBoundary]', error, info.componentStack)
  }

  handleReset = () => {
    if (this.props.onReset) {
      this.props.onReset()
      this.setState({ hasError: false, error: null })
    } else {
      window.location.reload()
    }
  }

  render() {
    if (!this.state.hasError) return this.props.children

    if (this.props.fallback) return this.props.fallback

    return (
      <div className="flex flex-col items-center justify-center min-h-[50vh] gap-4 px-8 text-center">
        <span className="text-5xl">⚠️</span>
        <h2 className="text-lg font-semibold text-text-primary">页面出现异常</h2>
        <p className="text-text-secondary text-sm max-w-md">
          当前模块遇到了意外错误，您的数据已自动保存。
          请点击下方按钮恢复。
        </p>
        {this.state.error && (
          <pre className="text-xs text-text-muted bg-bg-float rounded-lg p-3 max-w-lg overflow-x-auto">
            {this.state.error.message}
          </pre>
        )}
        <div className="flex gap-3 mt-2">
          <button onClick={this.handleReset} className="btn-primary px-6 py-2.5">
            刷新页面
          </button>
        </div>
      </div>
    )
  }
}
