/** 统一骨架屏组件 */

export function SkeletonLine({ width = '100%' }: { width?: string }) {
  return <div className="h-3 bg-bg-float rounded animate-pulse" style={{ width }} />
}

export function SkeletonText({ lines = 4 }: { lines?: number }) {
  const widths = ['90%', '75%', '85%', '60%', '70%', '95%', '50%', '80%']
  return (
    <div className="space-y-2.5">
      {Array.from({ length: lines }, (_, i) => (
        <SkeletonLine key={i} width={widths[i % widths.length]} />
      ))}
    </div>
  )
}

export function SkeletonCard() {
  return (
    <div className="card p-5 space-y-4 animate-pulse">
      <div className="flex items-center gap-3">
        <div className="w-8 h-8 rounded-lg bg-bg-float" />
        <div className="h-4 bg-bg-float rounded w-32" />
      </div>
      <SkeletonText lines={3} />
    </div>
  )
}

export function SkeletonChart({ height = 200 }: { height?: number }) {
  return (
    <div className="card p-5 animate-pulse">
      <div className="h-4 bg-bg-float rounded w-24 mb-4" />
      <div className="bg-bg-float rounded-lg" style={{ height }} />
    </div>
  )
}

/** 表单字段骨架 §9.8 */
export function SkeletonField() {
  return (
    <div className="space-y-1.5">
      <div className="h-3 w-20 bg-bg-float rounded animate-pulse" />
      <div className="h-10 w-full bg-bg-float rounded-lg animate-pulse" />
    </div>
  )
}

/** 模块页面骨架 §9.8 */
export function PageSkeleton() {
  return (
    <div className="space-y-6">
      <div className="space-y-2">
        <div className="h-7 w-48 bg-bg-float rounded animate-pulse" />
        <div className="h-4 w-72 bg-bg-float rounded animate-pulse" />
      </div>
      <div className="card p-6 space-y-4 animate-pulse">
        <div className="h-5 w-28 bg-bg-float rounded" />
        <div className="grid grid-cols-2 gap-4">
          <SkeletonField />
          <SkeletonField />
          <SkeletonField />
          <SkeletonField />
        </div>
      </div>
      <div className="card p-6 space-y-4 animate-pulse">
        <div className="h-5 w-36 bg-bg-float rounded" />
        <div className="grid grid-cols-3 gap-4">
          <SkeletonField />
          <SkeletonField />
          <SkeletonField />
        </div>
      </div>
      <div className="flex justify-end">
        <div className="h-10 w-40 bg-bg-float rounded-full animate-pulse" />
      </div>
    </div>
  )
}
