import { ReactNode, InputHTMLAttributes, useState, useRef } from 'react'

/** §9.2 Tooltip info icon */
function InfoTooltip({ text }: { text: string }) {
  const [show, setShow] = useState(false)
  return (
    <span className="relative inline-flex ml-1 align-middle">
      <button
        type="button"
        className="w-3.5 h-3.5 rounded-full bg-bg-float text-text-muted text-[10px] font-bold leading-none flex items-center justify-center hover:bg-accent/20 hover:text-accent transition-colors"
        onMouseEnter={() => setShow(true)}
        onMouseLeave={() => setShow(false)}
        onFocus={() => setShow(true)}
        onBlur={() => setShow(false)}
        tabIndex={-1}
      >
        ?
      </button>
      {show && (
        <span className="absolute z-50 bottom-full left-1/2 -translate-x-1/2 mb-1.5 px-2.5 py-1.5 bg-text-primary text-white text-xs rounded-lg shadow-lg whitespace-nowrap max-w-[240px] text-wrap leading-relaxed pointer-events-none">
          {text}
          <span className="absolute top-full left-1/2 -translate-x-1/2 w-0 h-0 border-l-4 border-r-4 border-t-4 border-transparent border-t-text-primary" />
        </span>
      )}
    </span>
  )
}

interface Props extends InputHTMLAttributes<HTMLInputElement> {
  label: string
  hint?: string
  tooltip?: string
  error?: string
  isDirty?: boolean
  unit?: string
  required?: boolean
  children?: ReactNode
}

export function FormField({ label, hint, tooltip, error, isDirty, unit, required, children, ...inputProps }: Props) {
  return (
    <div className="flex flex-col gap-1">
      <label className="field-label">
        {label}
        {required && <span className="text-accent-danger ml-0.5">*</span>}
        {tooltip && <InfoTooltip text={tooltip} />}
        {isDirty && (
          <span className="ml-2 inline-block w-1.5 h-1.5 rounded-full bg-accent-warning align-middle" title="已手动修改" />
        )}
      </label>
      <div className="relative">
        {children ? (
          children
        ) : (
          <div className="flex items-center">
            <input
              className={`input flex-1 ${error ? 'input-error' : ''} ${unit ? 'pr-10' : ''}`}
              {...inputProps}
            />
            {unit && (
              <span className="absolute right-3 text-text-secondary text-sm pointer-events-none">
                {unit}
              </span>
            )}
          </div>
        )}
      </div>
      {hint && !error && <p className="text-text-placeholder text-xs">{hint}</p>}
      {error && <p className="text-accent-danger text-xs">{error}</p>}
    </div>
  )
}

// 单选按钮组（≤4个选项用按钮组）
interface RadioGroupProps<T extends string> {
  label: string
  value: T
  options: Array<{ value: T; label: string }>
  onChange: (v: T) => void
  required?: boolean
  hint?: string
}

export function RadioGroup<T extends string>({ label, value, options, onChange, required, hint }: RadioGroupProps<T>) {
  return (
    <div className="flex flex-col gap-1">
      <label className="field-label">
        {label}
        {required && <span className="text-accent-danger ml-0.5">*</span>}
      </label>
      <div className="flex gap-2 flex-wrap">
        {options.map(opt => (
          <button
            key={opt.value}
            type="button"
            onClick={() => onChange(opt.value)}
            className={`
              px-4 py-2 rounded-input text-sm border transition-all duration-150
              ${value === opt.value
                ? 'border-accent bg-accent/10 text-accent font-medium'
                : 'border-bg-border text-text-secondary hover:border-accent/50 hover:text-text-primary'}
            `}
          >
            {opt.label}
          </button>
        ))}
      </div>
      {hint && <p className="text-text-placeholder text-xs">{hint}</p>}
    </div>
  )
}

// 城市选择下拉
interface CitySelectProps {
  label: string
  value: string
  onChange: (code: string) => void
  cities: Array<{ code: string; name: string; tier: number; isOverseas?: boolean; isEstimated?: boolean }>
  required?: boolean
  hint?: string
  error?: string
}

export function CitySelect({ label, value, onChange, cities, required, hint, error }: CitySelectProps) {
  const tierLabel: Record<number, string> = { 1: '一线', 2: '新一线/二线', 3: '三线' }
  const domestic = cities.filter(c => !c.isOverseas)
  const overseas = cities.filter(c => c.isOverseas)
  const groups: Array<{ label: string; items: typeof cities }> = [
    { label: '一线城市', items: domestic.filter(c => c.tier === 1) },
    { label: '新一线/二线城市', items: domestic.filter(c => c.tier === 2) },
    { label: '三线及其他', items: domestic.filter(c => c.tier === 3) },
  ]
  if (overseas.length > 0) groups.push({ label: '境外目的地', items: overseas })

  return (
    <div className="flex flex-col gap-1">
      <label className="field-label">
        {label}
        {required && <span className="text-accent-danger ml-0.5">*</span>}
      </label>
      <select value={value} onChange={e => onChange(e.target.value)} className={`input ${error ? 'input-error' : ''}`}>
        <option value="">请选择城市</option>
        {groups.map(g => g.items.length > 0 && (
          <optgroup key={g.label} label={g.label}>
            {g.items.map(c => (
              <option key={c.code} value={c.code}>
                {c.name}{c.isOverseas ? '' : `（${tierLabel[c.tier] ?? ''}）`}
              </option>
            ))}
          </optgroup>
        ))}
      </select>
      {hint && !error && <p className="text-text-placeholder text-xs">{hint}</p>}
      {error && <p className="text-accent-danger text-xs">{error}</p>}
    </div>
  )
}

// 数值输入（自动千分位格式化）
interface NumberInputProps {
  label: string
  value: number | undefined
  onChange: (v: number) => void
  unit?: string
  min?: number
  max?: number
  step?: number
  placeholder?: string
  required?: boolean
  isDirty?: boolean
  hint?: string
  tooltip?: string
  error?: string
  /** 实时校验：失焦时触发，返回错误信息或 undefined */
  validate?: (v: number | undefined) => string | undefined
}

/** 千分位格式化 §9.2 */
function formatThousands(v: number | undefined): string {
  if (v === undefined || v === null || isNaN(v)) return ''
  return v.toLocaleString('zh-CN')
}

export function NumberInput({ label, value, onChange, unit, min, max, step: _step = 1, placeholder, required, isDirty, hint, tooltip, error, validate }: NumberInputProps) {
  const [localError, setLocalError] = useState<string | undefined>()
  const [focused, setFocused] = useState(false)
  const [localText, setLocalText] = useState('')
  const inputRef = useRef<HTMLInputElement>(null)
  const displayError = error || localError

  function handleBlur() {
    setFocused(false)
    // Parse final value from local text
    const raw = localText.replace(/,/g, '').trim()
    if (raw === '') {
      onChange(undefined as unknown as number)
    } else {
      const v = Number(raw)
      if (!isNaN(v)) onChange(v)
    }
    if (validate) {
      setLocalError(validate(value))
    } else if (required && (value === undefined || value === null || isNaN(value as number))) {
      setLocalError(`请输入${label}`)
    } else if (min !== undefined && value !== undefined && value < min) {
      setLocalError(`${label}不能小于${min}`)
    } else if (max !== undefined && value !== undefined && value > max) {
      setLocalError(`${label}不能大于${max}`)
    } else {
      setLocalError(undefined)
    }
  }

  function handleFocus() {
    setFocused(true)
    // 聚焦时：0 显示为空（方便直接输入），其他数字显示原始值
    setLocalText(value === 0 || value === undefined || value === null ? '' : String(value))
  }

  function handleChange(e: React.ChangeEvent<HTMLInputElement>) {
    const raw = e.target.value
    setLocalText(raw)
    // 实时同步到 store
    const cleaned = raw.replace(/,/g, '').trim()
    if (cleaned === '' || cleaned === '-') return
    const v = Number(cleaned)
    if (!isNaN(v)) onChange(v)
    if (localError) setLocalError(undefined)
  }

  // 失焦时显示千分位格式，聚焦时显示可编辑文本
  const displayValue = focused ? localText : formatThousands(value)

  return (
    <FormField label={label} unit={unit} required={required} isDirty={isDirty} hint={hint} tooltip={tooltip} error={displayError}>
      <div className="relative flex items-center">
        <input
          ref={inputRef}
          type="text"
          inputMode="decimal"
          className={`input flex-1 ${unit ? 'pr-10' : ''} ${displayError ? 'input-error' : ''}`}
          value={displayValue}
          onChange={handleChange}
          onBlur={handleBlur}
          onFocus={handleFocus}
          placeholder={placeholder || '0'}
        />
        {unit && (
          <span className="absolute right-3 text-text-secondary text-sm pointer-events-none">
            {unit}
          </span>
        )}
      </div>
    </FormField>
  )
}

// §9.5 滑块+数值联动
interface SliderInputProps {
  label: string
  value: number
  onChange: (v: number) => void
  min: number
  max: number
  step?: number
  unit?: string
  hint?: string
  tooltip?: string
  marks?: Array<{ value: number; label: string }>
}

export function SliderInput({ label, value, onChange, min, max, step = 1, unit, hint, tooltip, marks }: SliderInputProps) {
  const pct = ((value - min) / (max - min)) * 100

  return (
    <div className="flex flex-col gap-1.5">
      <div className="flex items-center justify-between">
        <label className="field-label">
          {label}
          {tooltip && <InfoTooltip text={tooltip} />}
        </label>
        <div className="flex items-center gap-1">
          <input
            type="number"
            className="input w-20 text-right py-1 text-sm"
            value={value}
            onChange={e => {
              const v = Number(e.target.value)
              if (!isNaN(v) && v >= min && v <= max) onChange(v)
            }}
            min={min}
            max={max}
            step={step}
          />
          {unit && <span className="text-text-secondary text-sm">{unit}</span>}
        </div>
      </div>
      <div className="relative">
        <input
          type="range"
          className="w-full h-1.5 appearance-none bg-bg-float rounded-full outline-none cursor-pointer
            [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:h-4
            [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-accent [&::-webkit-slider-thumb]:shadow-md
            [&::-webkit-slider-thumb]:cursor-pointer [&::-webkit-slider-thumb]:border-2 [&::-webkit-slider-thumb]:border-white"
          value={value}
          onChange={e => onChange(Number(e.target.value))}
          min={min}
          max={max}
          step={step}
          style={{ background: `linear-gradient(to right, var(--accent) ${pct}%, var(--bg-float) ${pct}%)` }}
        />
        {marks && (
          <div className="flex justify-between text-[10px] text-text-muted mt-0.5 px-0.5">
            {marks.map(m => (
              <span key={m.value} className={value === m.value ? 'text-accent font-medium' : ''}>{m.label}</span>
            ))}
          </div>
        )}
      </div>
      {hint && <p className="text-text-placeholder text-xs">{hint}</p>}
    </div>
  )
}
