/**
 * Monte Carlo confidence interval chart — P10/P50/P90 area chart
 * Shows cumulative balance distribution across simulations
 */
import ReactECharts from 'echarts-for-react'

interface MonteCarloData {
  years: number[]
  p10: number[]
  p50: number[]
  p90: number[]
  mean: number[]
  successRate: number
}

interface Props {
  data: MonteCarloData
  retirementAge: number
}

const AXIS_COLOR = '#86868B'
const GRID_COLOR = '#E8E8ED'

function formatYuan(v: number): string {
  if (Math.abs(v) >= 100000000) return `${(v / 100000000).toFixed(1)}亿`
  if (Math.abs(v) >= 10000) return `${(v / 10000).toFixed(0)}万`
  return v.toLocaleString()
}

export default function MonteCarloChart({ data, retirementAge }: Props) {
  const { years, p10, p50, p90 } = data

  const option = {
    tooltip: {
      trigger: 'axis' as const,
      backgroundColor: '#FFFFFF',
      borderColor: '#E8E8ED',
      textStyle: { color: '#1D1D1F', fontSize: 12 },
      formatter: (params: Array<{ axisValue: number; seriesName: string; value: number; color: string }>) => {
        const age = params[0]?.axisValue
        let html = `<div style="font-weight:600;margin-bottom:4px">${age}岁</div>`
        params.forEach(p => {
          if (p.seriesName === '_band') return
          html += `<div>${p.seriesName}: <b>${formatYuan(p.value)}元</b></div>`
        })
        return html
      },
    },
    grid: { left: 60, right: 20, top: 30, bottom: 40 },
    xAxis: {
      type: 'category' as const,
      data: years,
      axisLine: { lineStyle: { color: GRID_COLOR } },
      axisLabel: { color: AXIS_COLOR, fontSize: 11, interval: Math.max(0, Math.floor(years.length / 8) - 1) },
      axisTick: { show: false },
    },
    yAxis: {
      type: 'value' as const,
      axisLabel: { color: AXIS_COLOR, fontSize: 11, formatter: (v: number) => formatYuan(v) },
      splitLine: { lineStyle: { color: GRID_COLOR, type: 'dashed' as const } },
    },
    series: [
      // P10-P90 band (stacked area)
      {
        name: '_band',
        type: 'line',
        data: p10,
        lineStyle: { opacity: 0 },
        areaStyle: { opacity: 0 },
        stack: 'confidence',
        symbol: 'none',
      },
      {
        name: '_band',
        type: 'line',
        data: p90.map((v, i) => v - p10[i]),
        lineStyle: { opacity: 0 },
        areaStyle: { color: 'rgba(0, 113, 227, 0.12)' },
        stack: 'confidence',
        symbol: 'none',
      },
      // P10 line
      {
        name: 'P10（悲观10%）',
        type: 'line',
        data: p10,
        lineStyle: { color: '#FF3B30', width: 1, type: 'dashed' as const },
        itemStyle: { color: '#FF3B30' },
        symbol: 'none',
      },
      // P50 line (median)
      {
        name: 'P50（中位数）',
        type: 'line',
        data: p50,
        lineStyle: { color: '#0071E3', width: 2 },
        itemStyle: { color: '#0071E3' },
        symbol: 'none',
      },
      // P90 line
      {
        name: 'P90（乐观10%）',
        type: 'line',
        data: p90,
        lineStyle: { color: '#34C759', width: 1, type: 'dashed' as const },
        itemStyle: { color: '#34C759' },
        symbol: 'none',
      },
    ],
    // Mark retirement age
    ...(retirementAge && years.includes(retirementAge)
      ? {
          markLine: {
            data: [{ xAxis: String(retirementAge) }],
            lineStyle: { color: '#FF9500', type: 'dashed' },
            label: { formatter: '退休', color: '#FF9500' },
          },
        }
      : {}),
  }

  // Add markLine to the P50 series for retirement age
  if (retirementAge && years.includes(retirementAge)) {
    (option.series[3] as Record<string, unknown>).markLine = {
      data: [{ xAxis: String(retirementAge) }],
      lineStyle: { color: '#FF9500', type: 'dashed' as const },
      label: { formatter: '退休', color: '#FF9500', fontSize: 11 },
      symbol: 'none',
    }
  }

  return <ReactECharts option={option} style={{ height: 320 }} />
}
