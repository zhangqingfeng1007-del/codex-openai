/**
 * 教育费用时间轴图 — §9.6 分阶段堆叠柱状图
 * X轴：教育阶段，Y轴：费用（万元），按子女分组
 */
import ReactECharts from 'echarts-for-react'
import type { ChildEducationPlan } from '../../types'

interface Props {
  children: ChildEducationPlan[]
}

const STAGE_LABELS: Record<string, string> = {
  preschool: '学前', primary: '小学', junior: '初中',
  senior: '高中', university: '大学', graduate: '研究生',
}
const CHILD_COLORS = ['#0071E3', '#34C759', '#FF9500', '#FF3B30']
const TOOLTIP_BG = '#FFFFFF'
const GRID_COLOR = '#E8E8ED'
const AXIS_COLOR = '#86868B'

export default function EducationChart({ children }: Props) {
  if (!children.length) return null

  const allStages = ['preschool', 'primary', 'junior', 'senior', 'university', 'graduate']

  const series = children.map((child, idx) => {
    const data = allStages.map(stage => {
      const s = child.stages.find(st => st.stage === stage)
      return s ? +(s.totalCost / 10000).toFixed(1) : 0
    })
    return {
      name: `子女${idx + 1}（路径${child.educationPath}）`,
      type: 'bar',
      data,
      itemStyle: { color: CHILD_COLORS[idx % CHILD_COLORS.length] },
      barMaxWidth: 40,
      label: {
        show: true,
        position: 'top' as const,
        formatter: (p: { value: number }) => p.value > 0 ? `${p.value}万` : '',
        color: AXIS_COLOR,
        fontSize: 10,
      },
    }
  })

  // 兴趣培养叠加到最后一列（合并所有子女的兴趣总计）
  const interestData = allStages.map(() => 0) // interest not stage-bound, shown separately

  const option = {
    backgroundColor: 'transparent',
    grid: { top: 48, bottom: 40, left: 52, right: 16 },
    legend: {
      top: 8,
      textStyle: { color: AXIS_COLOR, fontSize: 11 },
      icon: 'roundRect',
      itemWidth: 10, itemHeight: 10,
    },
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: TOOLTIP_BG,
      borderColor: GRID_COLOR,
      borderWidth: 1,
      textStyle: { color: '#1D1D1F', fontSize: 12 },
      formatter: (params: unknown[]) => {
        const p = params as Array<{ seriesName: string; value: number; color: string; name: string }>
        const label = p[0]?.name ?? ''
        const lines = p.filter(i => i.value > 0)
          .map(i => `<span style="color:${i.color}">●</span> ${i.seriesName}: <b>${i.value}万</b>`)
        return `${STAGE_LABELS[label] ?? label}<br/>${lines.join('<br/>')}`
      },
    },
    xAxis: {
      type: 'category',
      data: allStages,
      axisLabel: {
        formatter: (v: string) => STAGE_LABELS[v] ?? v,
        color: AXIS_COLOR,
        fontSize: 11,
      },
      axisLine: { lineStyle: { color: GRID_COLOR } },
      axisTick: { show: false },
    },
    yAxis: {
      type: 'value',
      name: '万元',
      nameTextStyle: { color: AXIS_COLOR, fontSize: 10 },
      axisLabel: { color: AXIS_COLOR, fontSize: 10 },
      splitLine: { lineStyle: { color: GRID_COLOR, type: 'dashed' } },
    },
    series,
  }

  void interestData // used for future interest breakdown

  return (
    <ReactECharts
      option={option}
      style={{ height: 260, width: '100%' }}
      opts={{ renderer: 'svg' }}
    />
  )
}
