/**
 * 三支柱覆盖图 — §9.6 横向堆叠条形图
 * 第一支柱(蓝) / 第二支柱(绿) / 第三支柱(紫) / 缺口(红)
 */
import ReactECharts from 'echarts-for-react'

interface Props {
  tier1PV: number
  tier2PV: number
  tier3PV: number
  pensionGap: number
  totalNeedPV: number
}

const TOOLTIP_BG = '#FFFFFF'
const GRID_COLOR = '#E8E8ED'
const AXIS_COLOR = '#86868B'

function fmt(v: number) { return (v / 10000).toFixed(0) + '万' }

export default function ThreePillarChart({ tier1PV, tier2PV, tier3PV, pensionGap, totalNeedPV }: Props) {
  const gap = Math.max(0, pensionGap)
  const total = tier1PV + tier2PV + tier3PV + gap

  const option = {
    backgroundColor: 'transparent',
    grid: { top: 12, bottom: 40, left: 16, right: 80 },
    tooltip: {
      trigger: 'axis',
      axisPointer: { type: 'shadow' },
      backgroundColor: TOOLTIP_BG,
      borderColor: GRID_COLOR,
      borderWidth: 1,
      textStyle: { color: '#1D1D1F', fontSize: 12 },
      formatter: (params: unknown[]) => {
        const p = params as Array<{ seriesName: string; value: number; color: string }>
        return p.filter(i => i.value > 0)
          .map(i => `<span style="color:${i.color}">●</span> ${i.seriesName}: <b>${fmt(i.value)}</b>`)
          .join('<br/>')
      },
    },
    legend: {
      bottom: 0,
      textStyle: { color: AXIS_COLOR, fontSize: 11 },
      icon: 'roundRect',
      itemWidth: 10, itemHeight: 10,
    },
    xAxis: {
      type: 'value',
      max: total,
      axisLabel: { formatter: (v: number) => fmt(v), color: AXIS_COLOR, fontSize: 10 },
      splitLine: { lineStyle: { color: GRID_COLOR, type: 'dashed' } },
    },
    yAxis: {
      type: 'category',
      data: ['养老总需求'],
      axisLine: { show: false },
      axisTick: { show: false },
      axisLabel: { color: AXIS_COLOR, fontSize: 12 },
    },
    series: [
      {
        name: '第一支柱（社保）',
        type: 'bar',
        stack: 'total',
        data: [tier1PV],
        itemStyle: { color: '#0071E3', borderRadius: [4, 0, 0, 4] },
        barWidth: 36,
        label: tier1PV / total > 0.08
          ? { show: true, position: 'inside', formatter: () => fmt(tier1PV), color: '#fff', fontSize: 10 }
          : { show: false },
      },
      {
        name: '第二支柱（年金）',
        type: 'bar',
        stack: 'total',
        data: [tier2PV],
        itemStyle: { color: '#34C759' },
        barWidth: 36,
        label: tier2PV / total > 0.08
          ? { show: true, position: 'inside', formatter: () => fmt(tier2PV), color: '#fff', fontSize: 10 }
          : { show: false },
      },
      {
        name: '第三支柱（个人）',
        type: 'bar',
        stack: 'total',
        data: [tier3PV],
        itemStyle: { color: '#AF52DE' },
        barWidth: 36,
        label: tier3PV / total > 0.08
          ? { show: true, position: 'inside', formatter: () => fmt(tier3PV), color: '#fff', fontSize: 10 }
          : { show: false },
      },
      {
        name: gap > 0 ? '缺口' : '盈余',
        type: 'bar',
        stack: 'total',
        data: [gap],
        itemStyle: {
          color: gap > 0 ? '#FF3B30' : '#34C759',
          borderRadius: [0, 4, 4, 0],
        },
        barWidth: 36,
        label: gap / total > 0.08
          ? { show: true, position: 'inside', formatter: () => fmt(gap), color: '#fff', fontSize: 10 }
          : { show: false },
      },
    ],
  }

  return (
    <div>
      <div className="flex justify-between text-xs text-text-muted mb-1 px-0.5">
        <span>总需求：<span className="text-text-primary font-medium">{fmt(totalNeedPV)}</span></span>
        <span>
          已覆盖：<span className="text-accent-success font-medium">
            {totalNeedPV > 0 ? Math.min(100, Math.round((tier1PV + tier2PV + tier3PV) / totalNeedPV * 100)) : 0}%
          </span>
        </span>
      </div>
      <ReactECharts
        option={option}
        style={{ height: 120, width: '100%' }}
        opts={{ renderer: 'svg' }}
      />
    </div>
  )
}
