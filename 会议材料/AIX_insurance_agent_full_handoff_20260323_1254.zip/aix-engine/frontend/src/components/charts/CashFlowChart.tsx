/**
 * 养老现金流图 — §9.6 堆叠柱状图
 * 收入（工资+养老金）/ 支出 / 累计余额折线
 */
import ReactECharts from 'echarts-for-react'
import type { AnnualCashFlowRow } from '../../types'

interface Props {
  data: AnnualCashFlowRow[]
  /** 显示行数，默认取退休后20行或全部取最多30行 */
  maxRows?: number
}

const AXIS_COLOR = '#86868B'
const GRID_COLOR = '#E8E8ED'
const TOOLTIP_BG = '#FFFFFF'

export default function CashFlowChart({ data, maxRows = 30 }: Props) {
  const rows = data.slice(0, maxRows)
  const years = rows.map(r => `${r.year}\n(${r.age}岁)`)
  const salary   = rows.map(r => +(r.salaryIncome  / 10000).toFixed(1))
  const pension  = rows.map(r => +(r.pensionIncome / 10000).toFixed(1))
  const expense  = rows.map(r => +(r.retirementExpense / 10000).toFixed(1))
  const balance  = rows.map(r => +(r.cumulativeBalance / 10000).toFixed(1))

  const option = {
    backgroundColor: 'transparent',
    grid: { top: 48, bottom: 56, left: 56, right: 56 },
    legend: {
      top: 8,
      textStyle: { color: AXIS_COLOR, fontSize: 11 },
      icon: 'roundRect',
      itemWidth: 10,
      itemHeight: 10,
      data: ['工资收入', '养老金', '退休支出', '累计余额'],
    },
    tooltip: {
      trigger: 'axis',
      backgroundColor: TOOLTIP_BG,
      borderColor: GRID_COLOR,
      borderWidth: 1,
      textStyle: { color: '#1D1D1F', fontSize: 12 },
      formatter: (params: unknown[]) => {
        const p = params as Array<{ seriesName: string; value: number; color: string }>
        const label = (years[(p[0] as { dataIndex?: number }).dataIndex ?? 0] ?? '').replace('\n', ' ')
        const lines = p.map(item => `<span style="color:${item.color}">●</span> ${item.seriesName}: <b>${item.value}万</b>`)
        return `${label}<br/>${lines.join('<br/>')}`
      },
    },
    xAxis: {
      type: 'category',
      data: years,
      axisLine: { lineStyle: { color: GRID_COLOR } },
      axisTick: { show: false },
      axisLabel: { color: AXIS_COLOR, fontSize: 10, interval: 4 },
    },
    yAxis: [
      {
        type: 'value',
        name: '万元/年',
        nameTextStyle: { color: AXIS_COLOR, fontSize: 10 },
        axisLabel: { color: AXIS_COLOR, fontSize: 10 },
        splitLine: { lineStyle: { color: GRID_COLOR, type: 'dashed' } },
      },
      {
        type: 'value',
        name: '累计余额(万)',
        nameTextStyle: { color: AXIS_COLOR, fontSize: 10 },
        axisLabel: { color: AXIS_COLOR, fontSize: 10 },
        splitLine: { show: false },
      },
    ],
    series: [
      {
        name: '工资收入',
        type: 'bar',
        stack: 'income',
        data: salary,
        itemStyle: { color: '#0071E3' },
        barMaxWidth: 20,
      },
      {
        name: '养老金',
        type: 'bar',
        stack: 'income',
        data: pension,
        itemStyle: { color: '#34C759' },
      },
      {
        name: '退休支出',
        type: 'bar',
        data: expense.map(v => -v),
        itemStyle: { color: '#FF3B30', opacity: 0.8 },
      },
      {
        name: '累计余额',
        type: 'line',
        yAxisIndex: 1,
        data: balance,
        symbol: 'none',
        lineStyle: { color: '#FF9500', width: 2 },
        areaStyle: {
          color: {
            type: 'linear',
            x: 0, y: 0, x2: 0, y2: 1,
            colorStops: [
              { offset: 0, color: 'rgba(255,149,0,0.15)' },
              { offset: 1, color: 'rgba(255,149,0,0)' },
            ],
          },
        },
      },
    ],
  }

  return (
    <ReactECharts
      option={option}
      style={{ height: 280, width: '100%' }}
      opts={{ renderer: 'svg' }}
    />
  )
}
