/**
 * 财务评分仪表盘 — §9.6 圆形进度环（Gauge Chart）
 * 分档颜色：80+绿 / 60-79蓝 / 40-59橙 / 0-39红
 */
import ReactECharts from 'echarts-for-react'

interface Props {
  score: number
  grade: string
  detail?: string
}

function scoreColor(s: number) {
  if (s >= 80) return '#34C759'
  if (s >= 60) return '#0071E3'
  if (s >= 40) return '#FF9500'
  return '#FF3B30'
}

export default function GaugeChart({ score, grade, detail }: Props) {
  const color = scoreColor(score)

  const option = {
    backgroundColor: 'transparent',
    series: [
      {
        type: 'gauge',
        startAngle: 210,
        endAngle: -30,
        min: 0,
        max: 100,
        splitNumber: 5,
        radius: '88%',
        center: ['50%', '58%'],
        axisLine: {
          lineStyle: {
            width: 14,
            color: [
              [0.4,  '#FF3B30'],
              [0.6,  '#FF9500'],
              [0.8,  '#0071E3'],
              [1.0,  '#34C759'],
            ],
          },
        },
        pointer: {
          icon: 'path://M12.8,0.7l12,40.1H0.7L12.8,0.7z',
          length: '55%',
          width: 8,
          offsetCenter: [0, '-55%'],
          itemStyle: { color },
        },
        axisTick: { show: false },
        splitLine: { show: false },
        axisLabel: { show: false },
        detail: {
          valueAnimation: true,
          formatter: '{value}',
          color,
          fontSize: 36,
          fontWeight: 700,
          fontFamily: '-apple-system, SF Pro Display, Inter, system-ui, sans-serif',
          offsetCenter: [0, '20%'],
        },
        title: {
          offsetCenter: [0, '50%'],
          fontSize: 12,
          color: '#86868B',
          fontFamily: 'system-ui, sans-serif',
        },
        data: [{ value: score, name: grade }],
      },
    ],
  }

  return (
    <div className="flex flex-col items-center">
      <ReactECharts
        option={option}
        style={{ height: 200, width: '100%' }}
        opts={{ renderer: 'svg' }}
      />
      {detail && (
        <p className="text-xs text-text-secondary text-center px-4 -mt-2 leading-relaxed">
          {detail}
        </p>
      )}
    </div>
  )
}
