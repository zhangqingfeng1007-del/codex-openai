/**
 * 语音输入组件 — 接入阿里云 NLS 实时流式语音识别
 *
 * 工作流程：
 *   1. 从 BFF GET /api/v1/asr/token 拿临时 Token + AppKey
 *   2. AudioContext (16kHz) + ScriptProcessorNode → Float32 → Int16 PCM
 *   3. WebSocket 连阿里云 NLS，发送 StartTranscription + 二进制音频块
 *   4. TranscriptionResultChanged → onInterim；SentenceEnd → onTranscript
 *   5. 停止时发送 StopTranscription → 关闭 WebSocket + AudioContext
 *
 * 桌面端：点击开始/再点结束
 * 手机端：长按说话（PTT），松开结束
 */
import { useState, useRef, useCallback } from 'react'
import { Mic, MicOff } from 'lucide-react'

const NLS_GATEWAY = 'wss://nls-gateway.cn-shanghai.aliyuncs.com/ws/v1'

interface VoiceInputProps {
  onTranscript: (text: string) => void   // 最终识别结果
  onInterim: (text: string) => void      // 实时中间结果
  disabled: boolean
}

type RecordState = 'idle' | 'connecting' | 'recording' | 'error'

export function VoiceInput({ onTranscript, onInterim, disabled }: VoiceInputProps) {
  const [state, setStateRaw] = useState<RecordState>('idle')
  const stateRef = useRef<RecordState>('idle')
  const setState = (s: RecordState) => { stateRef.current = s; setStateRaw(s) }
  const [errMsg, setErrMsg] = useState('')
  const isMobile = typeof window !== 'undefined' && window.innerWidth < 768

  const wsRef = useRef<WebSocket | null>(null)
  const audioCtxRef = useRef<AudioContext | null>(null)
  const processorRef = useRef<ScriptProcessorNode | null>(null)
  const streamRef = useRef<MediaStream | null>(null)
  const taskIdRef = useRef<string>('')

  const genTaskId = () => Math.random().toString(36).substring(2) + Date.now().toString(36)

  /** Float32 → Int16 PCM */
  const float32ToInt16 = (f32: Float32Array): ArrayBuffer => {
    const buf = new Int16Array(f32.length)
    for (let i = 0; i < f32.length; i++) {
      const s = Math.max(-1, Math.min(1, f32[i]))
      buf[i] = s < 0 ? s * 0x8000 : s * 0x7fff
    }
    return buf.buffer
  }

  const stopAll = useCallback(() => {
    try {
      if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
        wsRef.current.send(JSON.stringify({
          header: {
            message_id: genTaskId(),
            task_id:    taskIdRef.current,
            namespace:  'SpeechTranscriber',
            name:       'StopTranscription',
            appkey:     '',  // 服务端已记录，停止时不需要
          },
        }))
        wsRef.current.close()
      }
    } catch { /* ignore */ }

    processorRef.current?.disconnect()
    audioCtxRef.current?.close()
    streamRef.current?.getTracks().forEach(t => t.stop())

    wsRef.current = null
    audioCtxRef.current = null
    processorRef.current = null
    streamRef.current = null
    setState('idle')
    onInterim('')
  }, [onInterim])

  const startRecording = useCallback(async () => {
    if (disabled || state !== 'idle') return
    setErrMsg('')
    setState('connecting')

    try {
      // 1. 获取 Token + AppKey
      const tokenRes = await fetch('/api/v1/asr/token')
      if (!tokenRes.ok) throw new Error('获取语音 Token 失败，请稍后再试')
      const { token, appKey } = await tokenRes.json()
      if (!token) throw new Error('Token 为空，请检查 Aliyun NLS 配置')

      // 2. 获取麦克风
      const stream = await navigator.mediaDevices.getUserMedia({
        audio: { sampleRate: 16000, channelCount: 1, echoCancellation: true, noiseSuppression: true },
      })
      streamRef.current = stream

      // 3. 创建 AudioContext（强制 16kHz）
      const audioCtx = new AudioContext({ sampleRate: 16000 })
      audioCtxRef.current = audioCtx
      const source = audioCtx.createMediaStreamSource(stream)

      // ScriptProcessorNode: 缓冲区 4096 帧
      const processor = audioCtx.createScriptProcessor(4096, 1, 1)
      processorRef.current = processor

      // 4. 连接 WebSocket
      const taskId = genTaskId()
      taskIdRef.current = taskId
      const ws = new WebSocket(`${NLS_GATEWAY}?token=${token}`)
      ws.binaryType = 'arraybuffer'
      wsRef.current = ws

      ws.onopen = () => {
        // 发送开始指令
        ws.send(JSON.stringify({
          header: {
            message_id: genTaskId(),
            task_id:    taskId,
            namespace:  'SpeechTranscriber',
            name:       'StartTranscription',
            appkey:     appKey,
          },
          payload: {
            format:                   'pcm',
            sample_rate:              16000,
            enable_intermediate_result: true,
            enable_punctuation_prediction: true,
            enable_inverse_text_normalization: true,
          },
        }))
      }

      ws.onmessage = e => {
        try {
          const msg = JSON.parse(e.data as string)
          const name = msg?.header?.name

          if (name === 'TranscriptionStarted') {
            // NLS 确认开始，启动音频采集
            setState('recording')
            processor.onaudioprocess = evt => {
              const pcm = float32ToInt16(evt.inputBuffer.getChannelData(0))
              if (ws.readyState === WebSocket.OPEN) ws.send(pcm)
            }
            source.connect(processor)
            processor.connect(audioCtx.destination)
          } else if (name === 'TranscriptionResultChanged') {
            onInterim(msg.payload?.result || '')
          } else if (name === 'SentenceEnd') {
            const text = msg.payload?.result || ''
            if (text) onTranscript(text)
            onInterim('')
          } else if (name === 'TranscriptionCompleted') {
            stopAll()
          } else if (name === 'TaskFailed') {
            setErrMsg(msg.payload?.message || '识别失败')
            stopAll()
          }
        } catch { /* ignore malformed messages */ }
      }

      ws.onerror = () => {
        setErrMsg('语音服务连接失败')
        stopAll()
        setState('error')
      }

      ws.onclose = () => {
        if (stateRef.current === 'recording' || stateRef.current === 'connecting') stopAll()
      }

    } catch (err: any) {
      setErrMsg(err.message || '启动录音失败')
      stopAll()
      setState('error')
    }
  }, [disabled, state, onTranscript, onInterim, stopAll])

  const stopRecording = useCallback(() => {
    if (state !== 'recording') return
    stopAll()
  }, [state, stopAll])

  const toggleRecording = useCallback(() => {
    if (state === 'idle' || state === 'error') startRecording()
    else if (state === 'recording') stopRecording()
  }, [state, startRecording, stopRecording])

  const isActive = state === 'recording' || state === 'connecting'

  if (isMobile) {
    return (
      <button
        type="button"
        onTouchStart={e => { e.preventDefault(); startRecording() }}
        onTouchEnd={e => { e.preventDefault(); stopRecording() }}
        onMouseDown={startRecording}
        onMouseUp={stopRecording}
        disabled={disabled}
        className={`
          flex items-center gap-1.5 px-3 py-2 rounded-xl text-sm font-medium
          transition-all duration-150 select-none
          ${isActive
            ? 'bg-red-500 text-white animate-pulse shadow-md'
            : state === 'error'
              ? 'bg-red-50 text-red-400 border border-red-200'
              : 'bg-gray-100 text-gray-500 hover:bg-accent/10 hover:text-accent'
          }
          disabled:opacity-40
        `}
        title={isActive ? '松开结束' : '长按说话'}
      >
        {isActive ? <MicOff size={17} /> : <Mic size={17} />}
        <span className="text-xs">{isActive ? '松开结束' : '长按说话'}</span>
      </button>
    )
  }

  return (
    <div className="relative">
      <button
        type="button"
        onClick={toggleRecording}
        disabled={disabled}
        className={`
          p-2 rounded-lg transition-colors
          ${isActive
            ? 'text-red-500 bg-red-50 animate-pulse'
            : state === 'error'
              ? 'text-orange-400 bg-orange-50'
              : 'text-gray-400 hover:text-accent hover:bg-accent/10'
          }
          disabled:opacity-40
        `}
        title={
          state === 'idle' ? '点击说话'
            : state === 'connecting' ? '连接中…'
            : state === 'recording' ? '点击结束'
            : errMsg || '语音识别出错'
        }
      >
        {isActive ? <MicOff size={19} /> : <Mic size={19} />}
      </button>
      {errMsg && (
        <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-2 whitespace-nowrap
                        text-xs text-red-500 bg-white border border-red-200 rounded-lg px-2 py-1 shadow-sm">
          {errMsg}
        </div>
      )}
    </div>
  )
}
