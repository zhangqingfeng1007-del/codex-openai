/**
 * NeedsSummaryCard — 用户需求画像摘要卡
 *
 * 以标签+字段对的形式展示用户当前画像，
 * 移动端默认折叠，点击展开。
 */
import { useState } from 'react'
import { ChevronDown, ChevronUp, User } from 'lucide-react'
import type { NeedsReportSummary } from '../../../store/useStore'

interface NeedsReportCardProps {
  summary: NeedsReportSummary
  onViewRecommendations?: () => void
}

function formatBudget(v: number | undefined) {
  if (!v) return '—'
  return v >= 10000 ? `${(v / 10000).toFixed(1)}万/年` : `${v.toLocaleString()}元/年`
}

function formatBudgetDisplay(summary: NeedsReportSummary): string {
  if (summary.budget_mode === 'estimated') {
    const min = summary.budget_annual_estimated_min
    const max = summary.budget_annual_estimated_max
    if (min && max) {
      const fmtMin = min >= 10000 ? `${(min / 10000).toFixed(1)}万` : `${min.toLocaleString()}`
      const fmtMax = max >= 10000 ? `${(max / 10000).toFixed(1)}万` : `${max.toLocaleString()}`
      return `${fmtMin}~${fmtMax}元/年（测算）`
    }
  }
  return formatBudget(summary.budget_annual)
}

export function NeedsReportCard({ summary, onViewRecommendations }: NeedsReportCardProps) {
  const [collapsed, setCollapsed] = useState(true)

  const chips = [
    summary.age ? `${summary.age}岁` : null,
    summary.gender || null,
    summary.primary_concern || null,
    summary.family_structure || null,
  ].filter(Boolean) as string[]

  const fields = [
    { label: '年龄', value: summary.age ? `${summary.age}岁` : '—' },
    { label: '性别', value: summary.gender || '—' },
    { label: '年保费预算', value: formatBudgetDisplay(summary) },
    { label: '核心诉求', value: summary.primary_concern || '重大疾病' },
    { label: '家庭结构', value: summary.family_structure || '—' },
    ...(summary.health_status ? [{ label: '健康状况', value: summary.health_status }] : []),
  ]

  return (
    <div className="mt-3 rounded-2xl border border-accent/20 bg-white shadow-sm overflow-hidden">
      {/* 头部 — 点击切换展开/折叠 */}
      <button
        type="button"
        onClick={() => setCollapsed(c => !c)}
        className="w-full flex items-center gap-3 px-4 py-3 text-left hover:bg-bg-float/50 transition-colors"
      >
        <div className="w-7 h-7 rounded-lg bg-accent/10 flex items-center justify-center shrink-0">
          <User size={14} className="text-accent" strokeWidth={2} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-xs font-semibold text-accent mb-1">已识别用户画像</div>
          {/* 摘要标签 */}
          <div className="flex flex-wrap gap-1">
            {chips.map(c => (
              <span key={c} className="text-[11px] px-2 py-0.5 rounded-full bg-accent/8 text-accent border border-accent/15">
                {c}
              </span>
            ))}
          </div>
        </div>
        <span className="text-text-muted shrink-0">
          {collapsed ? <ChevronDown size={15} /> : <ChevronUp size={15} />}
        </span>
      </button>

      {/* 展开详情 */}
      {!collapsed && (
        <div className="px-4 pb-4 pt-1 border-t border-black/[0.05]">
          <div className="grid grid-cols-2 gap-x-4 gap-y-2.5">
            {fields.map(f => (
              <div key={f.label} className="flex flex-col">
                <span className="text-[10px] text-text-muted tracking-wide">{f.label}</span>
                <span className="text-xs text-text-primary font-medium leading-tight mt-0.5">{f.value}</span>
              </div>
            ))}
          </div>

          {onViewRecommendations && (
            <button
              type="button"
              onClick={onViewRecommendations}
              className="mt-3 w-full text-xs text-accent font-medium border border-accent/25 rounded-xl py-2
                         hover:bg-accent hover:text-white transition-colors"
            >
              查看产品推荐 →
            </button>
          )}
        </div>
      )}
    </div>
  )
}
