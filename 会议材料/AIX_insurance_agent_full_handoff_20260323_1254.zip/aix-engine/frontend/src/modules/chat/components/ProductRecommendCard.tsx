/**
 * 产品推荐结果 — 5 张结构化卡片
 *
 * 1. NeedsSummaryCard        用户画像摘要（从 needsReport 中取，此处通过 payload 补充）
 * 2. RecommendationCard × 3  每产品一张卡（亮点标签 + 保费 + 性价比）
 * 3. ProductCompareCard       字段对比（非表格，可滑动）
 * 4. RecommendationConclusionCard 总结建议
 * 5. RiskDisclosureCard       风险提示
 */
import { TrendingDown, TrendingUp, Star, ChevronRight, AlertTriangle, CheckCircle2, Users } from 'lucide-react'
import type { ProductRecommendation, ProductRecommendationsPayload, BudgetAllocation } from '../../../store/useStore'

interface ProductRecommendCardProps {
  payload: ProductRecommendationsPayload
}

// ─── 常量 ────────────────────────────────────────────────────────────────────

const RANK_GRADIENT = [
  'from-amber-400 to-yellow-300',
  'from-slate-400 to-slate-300',
  'from-orange-400 to-orange-300',
]
const RANK_LABEL = ['🥇 首推', '🥈 次选', '🥉 备选']

const SCORE_LABEL: Record<string, string> = {
  age_fit:       '年龄适配',
  budget_match:  '预算匹配',
  coverage:      '保障完整',
  value_score:   '性价比',
  waiting_period:'等待期',
  sale_status:   '在售状态',
  preference:    '公司偏好',
}

// ─── 工具函数 ─────────────────────────────────────────────────────────────────

function fmtPremium(annual_premium: number) {
  if (!annual_premium || annual_premium <= 0) return null
  const yuan = annual_premium / 100
  return yuan >= 10000
    ? `${(yuan / 10000).toFixed(1)}万`
    : `${Math.round(yuan).toLocaleString()}`
}

function deriveHighlights(p: ProductRecommendation): string[] {
  if (p.highlights && p.highlights.length > 0) return p.highlights
  const bd = p.score_breakdown || {}
  const tags: string[] = []
  if ((bd['age_fit'] ?? 0) >= 20)        tags.push('年龄适配')
  if ((bd['budget_match'] ?? 0) >= 20)   tags.push('预算友好')
  if ((bd['coverage'] ?? 0) >= 20)       tags.push('保障完整')
  if ((bd['value_score'] ?? 0) >= 18)    tags.push('性价比高')
  if ((bd['waiting_period'] ?? 0) >= 15) tags.push('等待期短')
  if ((bd['sale_status'] ?? 0) >= 10)    tags.push('现行在售')
  return tags.slice(0, 4)
}

// ─── 1. RecommendationCard（单产品卡）────────────────────────────────────────

function RecommendationCard({ product, rank }: { product: ProductRecommendation; rank: number }) {
  const highlights = deriveHighlights(product)
  const premiumStr = fmtPremium(product.annual_premium)
  const bd = product.score_breakdown || {}
  const valueRatio = bd['value_ratio']
  const hasRatio   = typeof valueRatio === 'number' && valueRatio > 0
  const isCheap    = hasRatio && valueRatio <= 1.0

  return (
    <div className={`
      relative bg-white rounded-2xl border overflow-hidden flex flex-col
      ${rank === 0 ? 'border-amber-300 shadow-[0_0_0_2px_rgba(251,191,36,0.3),0_4px_16px_rgba(0,0,0,0.08)]' : 'border-black/[0.08] shadow-sm'}
    `}>
      {/* 渐变顶条 */}
      <div className={`bg-gradient-to-r ${RANK_GRADIENT[rank]} px-4 py-2.5 flex items-center justify-between`}>
        <span className="text-white text-xs font-bold tracking-wide">{RANK_LABEL[rank]}</span>
        {rank === 0 && <Star size={13} className="text-white fill-white" />}
      </div>

      <div className="px-4 py-3 flex-1 flex flex-col gap-3">
        {/* 产品名 + 公司 */}
        <div>
          <div className="text-[15px] font-bold text-text-primary leading-snug">{product.product_name}</div>
          <div className="text-xs text-text-muted mt-0.5">{product.company_name}</div>
        </div>

        {/* 亮点标签 */}
        {highlights.length > 0 && (
          <div className="flex flex-wrap gap-1.5">
            {highlights.map(tag => (
              <span key={tag} className="inline-flex items-center gap-1 text-[11px] px-2 py-0.5 rounded-full bg-accent/8 text-accent font-medium border border-accent/15">
                <CheckCircle2 size={10} strokeWidth={2.5} />
                {tag}
              </span>
            ))}
          </div>
        )}

        {/* 保费 + 性价比 */}
        <div className="flex items-end justify-between gap-2">
          {premiumStr ? (
            <div>
              <div className="flex items-baseline gap-1">
                <span className="text-xl font-bold text-text-primary">{premiumStr}</span>
                <span className="text-xs text-text-muted">元/年</span>
              </div>
              <div className="text-[10px] text-text-muted mt-0.5">50万保额·20年缴参考</div>
            </div>
          ) : (
            <div className="text-sm text-text-muted">—</div>
          )}

          {hasRatio && (
            <div className={`flex items-center gap-1 text-[11px] rounded-xl px-2.5 py-1 font-medium shrink-0
              ${isCheap ? 'bg-green-50 text-green-600' : 'bg-orange-50 text-orange-500'}`}>
              {isCheap
                ? <TrendingDown size={12} />
                : <TrendingUp size={12} />
              }
              <span>
                {isCheap
                  ? `低于公允 ${((1 - valueRatio) * 100).toFixed(0)}%`
                  : `高于公允 ${((valueRatio - 1) * 100).toFixed(0)}%`}
              </span>
            </div>
          )}
        </div>

        {/* 综合评分 */}
        <div className="flex items-center gap-2 pt-1 border-t border-black/[0.05]">
          <span className="text-xs text-text-muted">综合评分</span>
          <div className="flex-1 h-1.5 bg-bg-float rounded-full overflow-hidden">
            <div
              className={`h-full rounded-full ${rank === 0 ? 'bg-amber-400' : 'bg-accent/60'}`}
              style={{ width: `${Math.min(100, (product.total_score / 100) * 100)}%` }}
            />
          </div>
          <span className={`text-sm font-bold ${rank === 0 ? 'text-amber-500' : 'text-accent'}`}>
            {product.total_score}
          </span>
        </div>
      </div>
    </div>
  )
}

// ─── 2. ProductCompareCard（滑动对比）────────────────────────────────────────

function ProductCompareCard({ products }: { products: ProductRecommendation[] }) {
  const fields = Object.keys(SCORE_LABEL).filter(k => k !== 'value_ratio')
  const maxScore = (k: string) => Math.max(...products.map(p => p.score_breakdown?.[k] ?? 0), 1)

  return (
    <div className="bg-white rounded-2xl border border-black/[0.08] shadow-sm overflow-hidden">
      <div className="px-4 py-3 border-b border-black/[0.06] flex items-center gap-2">
        <span className="text-sm font-semibold text-text-primary">📊 维度对比</span>
        <span className="text-[11px] text-text-muted">（左右滑动）</span>
      </div>

      {/* 横向可滑动对比块 */}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[420px]">
          <thead>
            <tr className="border-b border-black/[0.06]">
              <td className="px-4 py-2 text-xs text-text-muted w-24 shrink-0">维度</td>
              {products.map((p, i) => (
                <td key={p.product_id} className="px-3 py-2 text-center">
                  <div className={`text-[11px] font-bold ${i === 0 ? 'text-amber-500' : 'text-text-secondary'}`}>
                    {RANK_LABEL[i]}
                  </div>
                  <div className="text-[10px] text-text-muted truncate max-w-[90px]">
                    {p.product_name.length > 8 ? p.product_name.slice(0, 8) + '…' : p.product_name}
                  </div>
                </td>
              ))}
            </tr>
          </thead>
          <tbody>
            {fields.map(k => {
              const max = maxScore(k)
              return (
                <tr key={k} className="border-b border-black/[0.04] last:border-0">
                  <td className="px-4 py-2.5 text-xs text-text-muted">{SCORE_LABEL[k]}</td>
                  {products.map((p, i) => {
                    const v = p.score_breakdown?.[k] ?? 0
                    const pct = Math.min(100, (v / max) * 100)
                    const isBest = v === max && v > 0
                    return (
                      <td key={p.product_id} className="px-3 py-2.5">
                        <div className="flex flex-col items-center gap-1">
                          <div className="w-full h-2 bg-bg-float rounded-full overflow-hidden">
                            <div
                              className={`h-full rounded-full ${i === 0 ? 'bg-amber-400' : isBest ? 'bg-accent' : 'bg-accent/40'}`}
                              style={{ width: `${pct}%` }}
                            />
                          </div>
                          <span className={`text-[11px] font-semibold ${isBest ? 'text-accent' : 'text-text-muted'}`}>
                            {Math.round(v)}
                          </span>
                        </div>
                      </td>
                    )
                  })}
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ─── 3. RecommendationConclusionCard ────────────────────────────────────────

const PERSON_LABEL: Record<string, string> = {
  self: '本人', spouse: '配偶', children: '子女',
}

function fmtyuan(v: number) {
  return v >= 10000 ? `${(v / 10000).toFixed(1)}万` : `${v.toLocaleString()}`
}

function RecommendationConclusionCard({
  products,
  conclusion,
  budgetAllocation,
}: {
  products: ProductRecommendation[]
  conclusion?: string
  budgetAllocation?: BudgetAllocation
}) {
  const top = products[0]
  const defaultConclusion = top
    ? `综合保障完整性、性价比和年龄适配度，推荐优先考虑 **${top.product_name}**。` +
      (products[1] ? `如预算有限，**${products[1].product_name}** 也是不错的替代选择。` : '')
    : ''

  const text = conclusion || defaultConclusion
  const allocationEntries = budgetAllocation?.by_person
    ? Object.entries(budgetAllocation.by_person).filter(([, v]) => v && v > 0)
    : []

  return (
    <div className="bg-gradient-to-br from-accent/5 to-blue-50 rounded-2xl border border-accent/15 px-4 py-4 space-y-4">
      {/* 选购建议 */}
      <div>
        <div className="flex items-center gap-2 mb-2">
          <ChevronRight size={16} className="text-accent" strokeWidth={2.5} />
          <span className="text-sm font-semibold text-text-primary">选购建议</span>
        </div>
        <p className="text-sm text-text-secondary leading-relaxed">
          {text.split('**').map((seg, i) =>
            i % 2 === 1
              ? <strong key={i} className="text-text-primary font-semibold">{seg}</strong>
              : <span key={i}>{seg}</span>
          )}
        </p>
        {/* 快速决策卡 */}
        <div className="mt-3 grid grid-cols-1 sm:grid-cols-2 gap-2">
          {products.slice(0, 2).map((p, i) => (
            <div key={p.product_id} className="bg-white/70 rounded-xl px-3 py-2 text-xs">
              <div className="font-medium text-text-primary">{RANK_LABEL[i]}</div>
              <div className="text-text-muted mt-0.5 truncate">{p.product_name}</div>
            </div>
          ))}
        </div>
      </div>

      {/* 预算分配建议 */}
      {allocationEntries.length > 0 && (
        <div className="border-t border-accent/10 pt-3">
          <div className="flex items-center gap-2 mb-2.5">
            <Users size={14} className="text-accent" strokeWidth={2} />
            <span className="text-xs font-semibold text-text-primary">预算分配建议</span>
          </div>
          <div className="grid grid-cols-3 gap-2 mb-2.5">
            {allocationEntries.map(([key, val]) => (
              <div key={key} className="bg-white/80 rounded-xl px-3 py-2.5 text-center border border-accent/10">
                <div className="text-[10px] text-text-muted">{PERSON_LABEL[key] ?? key}</div>
                <div className="text-sm font-bold text-text-primary mt-0.5">{fmtyuan(val!)}</div>
                <div className="text-[10px] text-text-muted">元/年</div>
              </div>
            ))}
          </div>
          {budgetAllocation?.rationale && (
            <p className="text-[11px] text-text-muted leading-relaxed">{budgetAllocation.rationale}</p>
          )}
        </div>
      )}
    </div>
  )
}

// ─── 4. RiskDisclosureCard ───────────────────────────────────────────────────

const DEFAULT_RISKS = [
  '以上产品均为重疾险，确诊首次重疾后一次性赔付保额，理赔后合同通常终止。',
  '保费与年龄正相关，投保越早保费越低，建议尽早配置。',
  '实际核保结果以保险公司审核为准，有基础疾病或特殊职业可能被拒保或加费。',
  '当前数据库覆盖部分主流重疾险产品，如需更全面对比建议咨询专业顾问。',
]

function RiskDisclosureCard({ riskNotes }: { riskNotes?: string[] }) {
  const notes = (riskNotes && riskNotes.length > 0) ? riskNotes : DEFAULT_RISKS

  return (
    <div className="bg-amber-50 rounded-2xl border border-amber-200/60 px-4 py-4">
      <div className="flex items-center gap-2 mb-3">
        <AlertTriangle size={15} className="text-amber-500 shrink-0" strokeWidth={2} />
        <span className="text-sm font-semibold text-amber-800">重要说明</span>
      </div>
      <ul className="space-y-2">
        {notes.map((note, i) => (
          <li key={i} className="flex items-start gap-2 text-xs text-amber-700 leading-relaxed">
            <span className="mt-0.5 w-1.5 h-1.5 rounded-full bg-amber-400 shrink-0" />
            {note}
          </li>
        ))}
      </ul>
    </div>
  )
}

// ─── 主组件 ──────────────────────────────────────────────────────────────────

export function ProductRecommendCard({ payload }: ProductRecommendCardProps) {
  const { top3, conclusion, risk_notes } = payload
  if (!top3?.length) return null

  return (
    <div className="mt-3 space-y-3">
      {/* 标题 */}
      <div className="flex items-center gap-2 px-1">
        <span className="text-xs font-semibold text-text-muted uppercase tracking-wide">推荐方案</span>
        <div className="flex-1 h-px bg-black/[0.06]" />
        <span className="text-[11px] text-text-muted">50万保额 · 20年缴 · 终身</span>
      </div>

      {/* 各产品卡 */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {top3.map((p, i) => (
          <RecommendationCard key={p.product_id || i} product={p} rank={i} />
        ))}
      </div>

      {/* 维度对比（2款及以上才显示） */}
      {top3.length >= 2 && (
        <ProductCompareCard products={top3} />
      )}

      {/* 选购建议 */}
      <RecommendationConclusionCard products={top3} conclusion={conclusion} budgetAllocation={payload.budget_allocation} />

      {/* 风险提示 */}
      <RiskDisclosureCard riskNotes={risk_notes} />

      <p className="text-[10px] text-text-muted px-1">
        * 评分基于公开费率表及精算模型，仅供参考，以保险公司实际核保结果为准
      </p>
    </div>
  )
}
