/**
 * 图片输入组件
 * - 桌面端：点击弹出文件选择（支持拖拽由外层处理）
 * - 手机端：弹出相机/相册选择器（capture="environment"）
 */
import { useRef } from 'react'
import { ImageIcon } from 'lucide-react'

interface ImageInputProps {
  onImage: (base64: string, previewUrl: string) => void
  disabled: boolean
}

export function ImageInput({ onImage, disabled }: ImageInputProps) {
  const inputRef = useRef<HTMLInputElement>(null)
  const isMobile = window.innerWidth < 768

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) return

    // 超过 3MB 提示压缩，但仍允许上传
    const reader = new FileReader()
    reader.onload = e => {
      const base64 = e.target?.result as string    // "data:image/jpeg;base64,..."
      const previewUrl = URL.createObjectURL(file)  // blob: URL 用于本地预览
      onImage(base64, previewUrl)
    }
    reader.readAsDataURL(file)
  }

  return (
    <>
      <input
        ref={inputRef}
        type="file"
        accept="image/*"
        {...(isMobile ? { capture: 'environment' } : {})}
        className="hidden"
        onChange={e => {
          const file = e.target.files?.[0]
          if (file) handleFile(file)
          // 重置 input，允许重复选同一文件
          e.target.value = ''
        }}
      />
      <button
        type="button"
        onClick={() => !disabled && inputRef.current?.click()}
        disabled={disabled}
        className="p-2 rounded-lg text-gray-400 hover:text-accent hover:bg-accent/10 disabled:opacity-40 transition-colors"
        title="上传图片（保险单/体检报告/条款截图）"
      >
        <ImageIcon size={19} />
      </button>
    </>
  )
}
