/**
 * 组合输入栏 — 文字 + 语音 + 图片
 *
 * 桌面布局（单行）：[🖼️][🎤]  [输入框]  [↑发送]
 * 手机布局（两行）：[输入框 ↑]
 *                  [🖼️图片]  [🎤长按说话]
 */
import { useState, useRef, useCallback } from 'react'
import { Send, X } from 'lucide-react'
import { ImageInput } from './ImageInput'
import { VoiceInput } from './VoiceInput'

interface PendingImage {
  base64: string
  previewUrl: string
}

interface ChatInputBarProps {
  onSend: (text: string, image?: { base64: string }) => void
  disabled: boolean
  /** 'bottom' (默认): 固定在底部的对话输入栏; 'centered': 欢迎态居中大输入框 */
  variant?: 'bottom' | 'centered'
}

export function ChatInputBar({ onSend, disabled, variant = 'bottom' }: ChatInputBarProps) {
  const [input, setInput] = useState('')
  const [interimText, setInterimText] = useState('')  // 语音识别中间结果（灰色展示）
  const [pendingImage, setPendingImage] = useState<PendingImage | null>(null)
  const textareaRef = useRef<HTMLTextAreaElement>(null)
  const isMobile = window.innerWidth < 768

  const canSend = (input.trim() || pendingImage) && !disabled

  const handleSend = useCallback(() => {
    const text = input.trim()
    if (!text && !pendingImage) return
    onSend(text, pendingImage ? { base64: pendingImage.base64 } : undefined)
    setInput('')
    setInterimText('')
    setPendingImage(null)
    if (textareaRef.current) textareaRef.current.style.height = 'auto'
  }, [input, pendingImage, onSend])

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey && !isMobile) {
      e.preventDefault()
      handleSend()
    }
  }

  const handleTextareaChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value)
    e.target.style.height = 'auto'
    e.target.style.height = `${Math.min(e.target.scrollHeight, 160)}px`
  }

  const handleTranscript = (text: string) => {
    setInput(prev => prev + text)
    setInterimText('')
    // 自动触发发送（语音结束后直接发）
    // 如不需要自动发送，删除以下两行
    onSend(input + text, pendingImage ? { base64: pendingImage.base64 } : undefined)
    setInput('')
    setPendingImage(null)
  }

  const handleInterim = (text: string) => {
    setInterimText(text)
  }

  const inputTools = (
    <>
      <ImageInput
        onImage={(base64, previewUrl) => setPendingImage({ base64, previewUrl })}
        disabled={disabled}
      />
      <VoiceInput
        onTranscript={handleTranscript}
        onInterim={handleInterim}
        disabled={disabled}
      />
    </>
  )

  // centered 模式：欢迎态嵌入式大输入框
  if (variant === 'centered') {
    return (
      <div className="w-full max-w-2xl">
        {pendingImage && (
          <div className="flex items-center gap-2 mb-2 p-2 bg-gray-50 rounded-xl border border-gray-100">
            <img src={pendingImage.previewUrl} alt="待发送图片" className="w-12 h-12 object-cover rounded-lg border border-gray-200" />
            <span className="text-xs text-gray-500 flex-1">图片已选择，发送时一并提交</span>
            <button type="button" onClick={() => { URL.revokeObjectURL(pendingImage.previewUrl); setPendingImage(null) }}
              className="p-1 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-50 transition-colors">
              <X size={15} />
            </button>
          </div>
        )}
        <div className="rounded-2xl border border-black/[0.12] bg-white shadow-sm focus-within:border-accent/50 focus-within:shadow-md transition-all">
          <textarea
            ref={textareaRef}
            value={input}
            onChange={handleTextareaChange}
            onKeyDown={handleKeyDown}
            placeholder={interimText || '有问题，尽管问…'}
            rows={1}
            disabled={disabled}
            className="
              w-full resize-none bg-transparent px-4 py-4 text-sm text-text-primary
              placeholder:text-text-muted focus:outline-none transition-all overflow-hidden
            "
            style={{ minHeight: '56px', maxHeight: '160px' }}
          />
          {interimText && (
            <div className="px-4 pb-2 text-sm text-gray-300 pointer-events-none truncate">
              {input}{interimText}
            </div>
          )}
          <div className="flex items-center gap-2 px-3 py-2 border-t border-black/[0.06]">
            <ImageInput onImage={(base64, previewUrl) => setPendingImage({ base64, previewUrl })} disabled={disabled} />
            <VoiceInput onTranscript={handleTranscript} onInterim={handleInterim} disabled={disabled} />
            <div className="flex-1" />
            <button
              type="button"
              onClick={handleSend}
              disabled={!canSend}
              className="
                shrink-0 w-9 h-9 rounded-xl bg-accent text-white
                flex items-center justify-center
                hover:bg-accent-light active:scale-95 transition-all
                disabled:opacity-30 disabled:cursor-not-allowed disabled:active:scale-100
              "
              title="发送 (Enter)"
            >
              <Send size={15} />
            </button>
          </div>
        </div>
      </div>
    )
  }

  return (
    <div className="shrink-0 bg-white/90 backdrop-blur-xl border-t border-black/[0.08] px-4 py-3">
      <div className="max-w-3xl mx-auto">

        {/* 图片预览条 */}
        {pendingImage && (
          <div className="flex items-center gap-2 mb-2 p-2 bg-gray-50 rounded-xl border border-gray-100">
            <img
              src={pendingImage.previewUrl}
              alt="待发送图片"
              className="w-12 h-12 object-cover rounded-lg border border-gray-200"
            />
            <span className="text-xs text-gray-500 flex-1">图片已选择，发送时一并提交</span>
            <button
              type="button"
              onClick={() => {
                URL.revokeObjectURL(pendingImage.previewUrl)
                setPendingImage(null)
              }}
              className="p-1 rounded-lg text-gray-400 hover:text-red-400 hover:bg-red-50 transition-colors"
            >
              <X size={15} />
            </button>
          </div>
        )}

        {/* 桌面单行 */}
        {!isMobile && (
          <div className="flex items-end gap-2">
            {inputTools}
            <div className="flex-1 relative">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={handleTextareaChange}
                onKeyDown={handleKeyDown}
                placeholder={interimText || '输入您的问题… (Enter 发送，Shift+Enter 换行)'}
                rows={1}
                disabled={disabled}
                className="
                  w-full resize-none rounded-xl border border-black/[0.1] bg-bg-float
                  px-3.5 py-2.5 text-sm text-text-primary placeholder:text-text-muted
                  focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent/50
                  disabled:opacity-50 transition-all overflow-hidden
                "
                style={{ minHeight: '42px', maxHeight: '160px' }}
              />
              {interimText && (
                <div className="absolute inset-0 px-3.5 py-2.5 text-sm text-gray-300 pointer-events-none truncate">
                  {input}{interimText}
                </div>
              )}
            </div>
            <button
              type="button"
              onClick={handleSend}
              disabled={!canSend}
              className="
                shrink-0 w-10 h-10 rounded-xl bg-accent text-white
                flex items-center justify-center
                hover:bg-accent-light active:scale-95 transition-all
                disabled:opacity-40 disabled:cursor-not-allowed disabled:active:scale-100
              "
              title="发送"
            >
              <Send size={16} />
            </button>
          </div>
        )}

        {/* 手机两行 */}
        {isMobile && (
          <>
            <div className="flex items-end gap-2 mb-2">
              <textarea
                ref={textareaRef}
                value={input}
                onChange={handleTextareaChange}
                onKeyDown={handleKeyDown}
                placeholder={interimText || '输入问题…'}
                rows={1}
                disabled={disabled}
                className="
                  flex-1 resize-none rounded-xl border border-black/[0.1] bg-bg-float
                  px-3.5 py-2.5 text-sm text-text-primary placeholder:text-text-muted
                  focus:outline-none focus:ring-2 focus:ring-accent/40 focus:border-accent/50
                  disabled:opacity-50 transition-all overflow-hidden
                "
                style={{ minHeight: '42px', maxHeight: '120px' }}
              />
              <button
                type="button"
                onClick={handleSend}
                disabled={!canSend}
                className="
                  shrink-0 w-10 h-10 rounded-xl bg-accent text-white
                  flex items-center justify-center
                  hover:bg-accent-light active:scale-95 transition-all
                  disabled:opacity-40 disabled:cursor-not-allowed disabled:active:scale-100
                "
                title="发送"
              >
                <Send size={16} />
              </button>
            </div>
            <div className="flex items-center gap-3">
              {inputTools}
            </div>
          </>
        )}

        <p className="text-center text-text-muted text-[10px] mt-2">
          AI建议仅供参考，不构成投保依据，具体以保险公司核保结果为准
        </p>
      </div>
    </div>
  )
}
