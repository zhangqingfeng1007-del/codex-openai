/**
 * HomeQuickEntry — 首页快捷入口
 *
 * 仅在对话消息 ≤ 1 条时展示，用户发出第一条消息后消失。
 *
 * 规则：
 *   send_message → 发送预设文字（AI 会根据意图决定是否弹出路由卡）
 *   navigate     → 直接跳转（仅非规划类短捷路径使用）
 */

interface QuickEntry {
  label:  string
  icon:   string
  action: 'navigate' | 'send_message'
  target: string
  desc:   string
}

// "家庭保障规划" 改为发消息，让 AI 弹出二选一路由卡，而非直接跳页面
const ENTRIES: QuickEntry[] = [
  {
    label:  '帮我规划家庭保障',
    icon:   '👨‍👩‍👧',
    action: 'send_message',
    target: '帮我规划家庭保险方案',
    desc:   '填表或对话，AI 生成专属方案',
  },
  {
    label:  '帮我推荐适合的重疾险',
    icon:   '🔍',
    action: 'send_message',
    target: '帮我推荐一款适合我的重疾险',
    desc:   '对话了解需求，智能匹配产品',
  },
  {
    label:  '帮我看看现有保单',
    icon:   '📋',
    action: 'send_message',
    target: '帮我做一个保单体检分析',
    desc:   '识别保障缺口，优化配置',
  },
  {
    label:  '保险一般怎么配置更合理',
    icon:   '💬',
    action: 'send_message',
    target: '保险一般怎么配置更合理',
    desc:   '任意提问，专业解答',
  },
]

interface HomeQuickEntryProps {
  onNavigate:    (target: string) => void
  onSendMessage: (text: string) => void
  disabled:      boolean
}

export function HomeQuickEntry({ onNavigate, onSendMessage, disabled }: HomeQuickEntryProps) {
  const handleClick = (entry: QuickEntry) => {
    if (disabled) return
    if (entry.action === 'navigate') {
      onNavigate(entry.target)
    } else {
      onSendMessage(entry.target)
    }
  }

  return (
    <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 w-full">
      {ENTRIES.map(entry => (
        <button
          key={entry.label}
          onClick={() => handleClick(entry)}
          disabled={disabled}
          className="
            flex flex-col items-start gap-1.5 p-3.5 rounded-2xl border border-black/[0.08]
            bg-white text-left shadow-sm
            hover:border-accent/30 hover:shadow-md hover:bg-accent/[0.02]
            active:scale-[0.97] transition-all duration-150
            disabled:opacity-40 disabled:cursor-not-allowed disabled:active:scale-100
          "
        >
          <span className="text-xl leading-none">{entry.icon}</span>
          <span className="text-xs font-semibold text-text-primary mt-0.5">{entry.label}</span>
          <span className="text-[10px] text-text-muted leading-snug">{entry.desc}</span>
        </button>
      ))}
    </div>
  )
}
