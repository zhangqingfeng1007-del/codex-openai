/**
 * RouteCard — 意图路由卡片
 *
 * 触发链路：
 *   AI 调用 show_options(route_options=[...])
 *   → Python tool_handler emit SSE event: route_options
 *   → streamChat.onRouteOptions() 回调
 *   → ChatPage 写入 msg.routeOptions
 *   → 本组件渲染
 *
 * ⚠️  由 route_options SSE 事件触发，不是普通 options 事件
 */

import type { RouteOption } from '../../../store/useStore'

interface RouteCardProps {
  options:    RouteOption[]
  onNavigate: (target: string) => void   // action=navigate 时由 ChatPage 处理跳转
  onContinue: () => void                 // action=continue_chat 时关闭卡片继续对话
  disabled:   boolean
}

export function RouteCard({ options, onNavigate, onContinue, disabled }: RouteCardProps) {
  const handleClick = (opt: RouteOption) => {
    if (disabled) return
    if (opt.action === 'navigate' && opt.target) {
      onNavigate(opt.target)
    } else {
      onContinue()
    }
  }

  return (
    <div className="flex flex-wrap gap-2 mt-2">
      {options.map(opt => (
        <button
          key={opt.label}
          onClick={() => handleClick(opt)}
          disabled={disabled}
          className={`
            flex items-center gap-1.5 px-4 py-2 text-sm rounded-xl border font-medium
            transition-all duration-150 active:scale-95
            disabled:opacity-40 disabled:cursor-not-allowed disabled:active:scale-100
            ${opt.action === 'navigate'
              ? 'bg-accent text-white border-accent hover:bg-accent/90'
              : 'bg-white text-accent border-accent/30 hover:bg-accent/5 hover:border-accent'
            }
          `}
        >
          {opt.action === 'navigate' ? '📋' : '💬'}
          <span>{opt.label}</span>
        </button>
      ))}
    </div>
  )
}
