/**
 * 保险智能体 — 主对话页面 v4.0
 *
 * 欢迎态（messages.length <= 1 && !isStreaming）：
 *   居中 logo + "保险智能体" + 副标题 + 快捷入口 + 输入栏
 *
 * 对话态（messages.length > 1 || isStreaming）：
 *   紧凑顶栏 + 消息列表 + 输入栏
 *
 * SSE 事件类型：
 *   chunk               → 追加文字内容
 *   options             → 快捷选项卡片
 *   route_options       → 意图路由卡片（navigate / continue_chat）
 *   needs_report        → 需求分析报告卡片
 *   product_recommendations → Top3 产品推荐卡片（含 conclusion / risk_notes）
 *   done                → 对话结束
 *   error               → 错误提示
 */
import { useState, useEffect, useRef, useCallback } from 'react'
import { v4 as uuidv4 } from 'uuid'
import { Trash2, ShieldCheck } from 'lucide-react'
import {
  useStore,
  type ChatMessage,
  type NeedsReportSummary,
  type ProductRecommendationsPayload,
  type RouteOption,
} from '../../store/useStore'
import { ChatInputBar } from './components/ChatInputBar'
import { NeedsReportCard } from './components/NeedsReportCard'
import { ProductRecommendCard } from './components/ProductRecommendCard'
import { RouteCard } from './components/RouteCard'
import { HomeQuickEntry } from './components/HomeQuickEntry'

// 模块 key → activeModule 值映射
// "aix-engine" = 复用现有 AIX 保险智能测算引擎（从 module1 基本信息开始）
// "policy-check" = 保单体检（module3 保障需求）
const TARGET_MODULE_MAP: Record<string, 'home' | 1 | 2 | 3 | 4 | 5 | 6 | 7 | 'admin' | 'chat'> = {
  'aix-engine':  1,   // 填写信息规划 → AIX 测算引擎入口（module1 基本信息）
  'policy-check': 3,
}

// ─── SSE 流式对话 ────────────────────────────────────────────────────────────

interface StreamCallbacks {
  onChunk:                  (text: string) => void
  onOptions:                (opts: string[]) => void
  onRouteOptions:           (opts: RouteOption[]) => void
  onNeedsReport:            (data: { report_id: string; summary: NeedsReportSummary }) => void
  onProductRecommendations: (data: ProductRecommendationsPayload) => void
  onDone:                   () => void
  onError:                  (msg: string) => void
}

async function streamChat(
  messages: { role: 'user' | 'assistant'; content: string }[],
  callbacks: StreamCallbacks,
  signal: AbortSignal,
  profileId?: string | null,
  image?: { base64: string },
) {
  const response = await fetch('/api/v1/chat', {
    method:  'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      messages,
      profile_id: profileId ?? null,
      ...(image ? { image: { base64: image.base64 } } : {}),
    }),
    signal,
  })

  if (!response.ok || !response.body) {
    callbacks.onError(`请求失败 (${response.status})`)
    return
  }

  const reader  = response.body.getReader()
  const decoder = new TextDecoder()
  let buffer    = ''

  while (true) {
    const { done, value } = await reader.read()
    if (done) break

    buffer += decoder.decode(value, { stream: true })
    const parts = buffer.split('\n\n')
    buffer = parts.pop() ?? ''

    for (const part of parts) {
      const lines = part.trim().split('\n')
      let eventType = 'message'
      let dataLine  = ''

      for (const line of lines) {
        if (line.startsWith('event:')) eventType = line.slice(6).trim()
        else if (line.startsWith('data:')) dataLine = line.slice(5).trim()
      }

      if (!dataLine) continue

      try {
        const parsed = JSON.parse(dataLine)

        switch (eventType) {
          case 'chunk':
            if (parsed.content) callbacks.onChunk(parsed.content)
            break
          case 'options':
            if (Array.isArray(parsed.options)) callbacks.onOptions(parsed.options)
            break
          case 'route_options':
            if (Array.isArray(parsed.route_options)) callbacks.onRouteOptions(parsed.route_options)
            break
          case 'needs_report':
            if (parsed.summary) callbacks.onNeedsReport(parsed)
            break
          case 'product_recommendations':
            if (Array.isArray(parsed.top3)) callbacks.onProductRecommendations(parsed as ProductRecommendationsPayload)
            break
          case 'done':
            callbacks.onDone()
            return
          case 'error':
            callbacks.onError(parsed.message || '未知错误')
            return
        }
      } catch {
        if (eventType === 'error') callbacks.onError(dataLine)
      }
    }
  }

  callbacks.onDone()
}

// ─── 子组件 ──────────────────────────────────────────────────────────────────

function TypingIndicator() {
  return (
    <div className="flex items-center gap-1.5 px-1 py-1">
      <span className="w-2 h-2 rounded-full bg-text-muted/60 animate-bounce [animation-delay:0ms]" />
      <span className="w-2 h-2 rounded-full bg-text-muted/60 animate-bounce [animation-delay:150ms]" />
      <span className="w-2 h-2 rounded-full bg-text-muted/60 animate-bounce [animation-delay:300ms]" />
    </div>
  )
}

function MessageContent({ content }: { content: string }) {
  const paragraphs = content.split('\n')
  return (
    <div className="text-sm leading-relaxed whitespace-pre-wrap break-words">
      {paragraphs.map((line, i) => (
        <span key={i}>
          {line}
          {i < paragraphs.length - 1 && <br />}
        </span>
      ))}
    </div>
  )
}

function QuickOptions({
  options,
  onSelect,
  disabled,
}: {
  options: string[]
  onSelect: (text: string) => void
  disabled: boolean
}) {
  return (
    <div className="flex flex-wrap gap-2 mt-2">
      {options.map(opt => (
        <button
          key={opt}
          onClick={() => !disabled && onSelect(opt)}
          disabled={disabled}
          className="
            px-3 py-1.5 text-xs rounded-xl border border-accent/30
            bg-white text-accent font-medium
            hover:bg-accent hover:text-white hover:border-accent
            active:scale-95 transition-all duration-150
            disabled:opacity-40 disabled:cursor-not-allowed disabled:active:scale-100
          "
        >
          {opt}
        </button>
      ))}
    </div>
  )
}


// ─── 主页面 ──────────────────────────────────────────────────────────────────

export default function ChatPage() {
  const {
    activeProfileId,
    chatMessages: messages,
    setChatMessages: setMessages,
    clearChatMessages,
    setActiveModule,
  } = useStore()
  const [isStreaming, setIsStreaming]   = useState(false)
  const [isWelcoming, setIsWelcoming]   = useState(true)
  const bottomRef      = useRef<HTMLDivElement>(null)
  const abortRef       = useRef<AbortController | null>(null)
  const streamingIdRef = useRef<string | null>(null)

  const isWelcomeState = messages.length <= 1 && !isStreaming

  useEffect(() => {
    const handler = () => bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
    window.visualViewport?.addEventListener('resize', handler)
    return () => window.visualViewport?.removeEventListener('resize', handler)
  }, [])

  const scrollToBottom = useCallback(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [])

  useEffect(() => {
    scrollToBottom()
  }, [messages, isStreaming, scrollToBottom])

  const sendRequest = useCallback(
    (
      conversationHistory: { role: 'user' | 'assistant'; content: string }[],
      image?: { base64: string },
    ) => {
      abortRef.current?.abort()
      const controller = new AbortController()
      abortRef.current = controller

      const assistantId = uuidv4()
      streamingIdRef.current = assistantId

      setMessages(prev => [...prev, { id: assistantId, role: 'assistant', content: '' }])
      setIsStreaming(true)

      streamChat(
        conversationHistory,
        {
          onChunk: chunk => {
            setMessages(prev =>
              prev.map(m => m.id === assistantId
                ? { ...m, content: m.content + chunk }
                : m
              )
            )
          },
          onOptions: opts => {
            setMessages(prev =>
              prev.map(m => m.id === assistantId ? { ...m, options: opts } : m)
            )
          },
          onRouteOptions: opts => {
            setMessages(prev =>
              prev.map(m => m.id === assistantId ? { ...m, routeOptions: opts } : m)
            )
          },
          onNeedsReport: data => {
            setMessages(prev =>
              prev.map(m => m.id === assistantId ? { ...m, needsReport: data } : m)
            )
          },
          onProductRecommendations: data => {
            setMessages(prev =>
              prev.map(m => m.id === assistantId
                ? { ...m, productRecommendations: data.top3, recommendationsPayload: data }
                : m
              )
            )
          },
          onDone: () => {
            setIsStreaming(false)
            setIsWelcoming(false)
            streamingIdRef.current = null
          },
          onError: errMsg => {
            setIsStreaming(false)
            setIsWelcoming(false)
            streamingIdRef.current = null
            setMessages(prev =>
              prev.map(m => m.id === assistantId
                ? { ...m, content: `⚠️ ${errMsg}` }
                : m
              )
            )
          },
        },
        controller.signal,
        activeProfileId,
        image,
      ).catch(err => {
        if (err?.name === 'AbortError') return
        setIsStreaming(false)
        setIsWelcoming(false)
        streamingIdRef.current = null
        setMessages(prev =>
          prev.map(m => m.id === assistantId
            ? { ...m, content: `⚠️ 网络错误：${err.message}` }
            : m
          )
        )
      })
    },
    [activeProfileId, setMessages],
  )

  useEffect(() => {
    if (messages.length === 0) {
      sendRequest([])
    } else {
      setIsWelcoming(false)
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const sendText = useCallback(
    (text: string, image?: { base64: string }) => {
      if (!text.trim() && !image) return
      if (isStreaming) return

      const current = useStore.getState().chatMessages
      const cleared = current.map(m =>
        (m.options || m.routeOptions)
          ? { ...m, options: undefined, routeOptions: undefined }
          : m
      )

      const userMsg: ChatMessage = {
        id:      uuidv4(),
        role:    'user',
        content: text,
        ...(image ? { imageUrl: undefined } : {}),
      }

      const newMsgs = [...cleared, userMsg]
      const history = newMsgs
        .filter(m => m.content.trim())
        .map(m => ({ role: m.role as 'user' | 'assistant', content: m.content }))

      setMessages(newMsgs)
      sendRequest(history, image)
    },
    [isStreaming, sendRequest, setMessages],
  )

  const handleNavigate = useCallback(
    (target: string) => {
      const mod = TARGET_MODULE_MAP[target]
      if (mod !== undefined) setActiveModule(mod)
    },
    [setActiveModule],
  )

  const handleContinueChat = useCallback(() => {
    setMessages(prev =>
      prev.map(m => m.routeOptions ? { ...m, routeOptions: undefined } : m)
    )
  }, [setMessages])

  const handleNewChat = () => {
    clearChatMessages()
    setIsWelcoming(true)
    sendRequest([])
  }

  // ─── 消息渲染 ──────────────────────────────────────────────────────────────

  const renderMessage = (msg: ChatMessage, idx: number) => {
    const isUser   = msg.role === 'user'
    const isLast   = idx === messages.length - 1
    const showTyping = isLast && isStreaming && !isUser && msg.content === ''

    return (
      <div key={msg.id} className={`flex flex-col ${isUser ? 'items-end' : 'items-start'}`}>
        {/* 消息气泡 */}
        <div
          className={`
            max-w-[80%] sm:max-w-[68%] rounded-2xl px-4 py-3
            ${isUser
              ? 'bg-accent text-white rounded-tr-sm'
              : 'bg-bg-float text-text-primary rounded-tl-sm shadow-sm'
            }
          `}
        >
          {isUser && msg.imageUrl && (
            <img
              src={msg.imageUrl}
              alt="已上传图片"
              className="w-32 h-32 object-cover rounded-lg mb-2 border border-white/20"
            />
          )}
          {showTyping ? <TypingIndicator /> : <MessageContent content={msg.content} />}
        </div>

        {/* 快捷选项 */}
        {!isUser && msg.options && msg.options.length > 0 && (
          <div className="max-w-[80%] sm:max-w-[68%] pl-1">
            <QuickOptions
              options={msg.options}
              onSelect={text => sendText(text)}
              disabled={isStreaming}
            />
          </div>
        )}

        {/* 意图路由卡片 */}
        {!isUser && msg.routeOptions && msg.routeOptions.length > 0 && (
          <div className="max-w-[80%] sm:max-w-[68%] pl-1">
            <RouteCard
              options={msg.routeOptions}
              onNavigate={handleNavigate}
              onContinue={handleContinueChat}
              disabled={isStreaming}
            />
          </div>
        )}

        {/* 需求摘要卡片 */}
        {!isUser && msg.needsReport && (
          <div className="max-w-[80%] sm:max-w-[72%]">
            <NeedsReportCard summary={msg.needsReport.summary} />
          </div>
        )}

        {/* 产品推荐卡片（使用完整 payload） */}
        {!isUser && msg.recommendationsPayload && msg.recommendationsPayload.top3.length > 0 && (
          <div className="w-full max-w-[760px]">
            <ProductRecommendCard payload={msg.recommendationsPayload} />
          </div>
        )}
        {/* 兼容旧格式（无 payload 时） */}
        {!isUser && !msg.recommendationsPayload && msg.productRecommendations && msg.productRecommendations.length > 0 && (
          <div className="w-full max-w-[760px]">
            <ProductRecommendCard payload={{ top3: msg.productRecommendations }} />
          </div>
        )}
      </div>
    )
  }

  // ─── 欢迎态布局（ChatGPT 风格：中心焦点，顶部品牌由 MainLayout 提供）────

  if (isWelcomeState) {
    return (
      <div className="flex flex-col h-full bg-bg-base">
        {/* 居中主区 — 页面唯一交互焦点 */}
        <div className="flex-1 flex flex-col items-center justify-center px-4 sm:px-8 gap-6 pb-4">

          {/* 品牌文案区：主标题 + 副标（口号） */}
          <div className="text-center select-none space-y-1.5">
            <h1 className="text-[2rem] font-bold text-text-primary tracking-tight leading-tight">
              保险智能体
            </h1>
            <p className="text-sm font-medium" style={{ color: '#2B7FE0' }}>
              人人都是保险专家
            </p>
            <p className="text-xs text-text-muted pt-1">有任何保险问题，尽管问我</p>
          </div>

          {/* 核心焦点：居中大输入框 */}
          <ChatInputBar variant="centered" onSend={sendText} disabled={isStreaming} />

          {/* 快捷建议 — 输入框下方，像"我可以这样问" */}
          {!isWelcoming && (
            <div className="w-full max-w-2xl">
              <HomeQuickEntry
                onNavigate={handleNavigate}
                onSendMessage={text => sendText(text)}
                disabled={isStreaming}
              />
            </div>
          )}
        </div>

        {/* 免责声明 */}
        <p className="shrink-0 text-center text-text-muted text-[10px] pb-4">
          AI 建议仅供参考，不构成投保依据，具体以保险公司核保结果为准
        </p>
      </div>
    )
  }

  // ─── 对话态布局 ──────────────────────────────────────────────────────────

  return (
    <div className="flex flex-col h-full bg-bg-base">
      {/* 紧凑顶栏 */}
      <div className="shrink-0 bg-white/80 backdrop-blur-xl border-b border-black/[0.08] px-4 py-2.5 flex items-center gap-3">
        <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-accent to-blue-600 flex items-center justify-center shrink-0">
          <ShieldCheck size={14} className="text-white" strokeWidth={2} />
        </div>
        <div className="flex-1 min-w-0">
          <div className="text-text-primary font-semibold text-sm">保险智能体</div>
        </div>
        {messages.length > 0 && !isStreaming && (
          <button
            onClick={handleNewChat}
            className="flex items-center gap-1 text-text-muted text-xs hover:text-red-400 transition-colors px-2 py-1 rounded-lg hover:bg-red-50"
            title="开启新对话"
          >
            <Trash2 size={13} />
            <span className="hidden sm:inline">新对话</span>
          </button>
        )}
      </div>

      {/* 消息列表 */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4">
        {messages.map((msg, idx) => renderMessage(msg, idx))}
        <div ref={bottomRef} />
      </div>

      {/* 输入栏 */}
      <ChatInputBar onSend={sendText} disabled={isStreaming} />
    </div>
  )
}
