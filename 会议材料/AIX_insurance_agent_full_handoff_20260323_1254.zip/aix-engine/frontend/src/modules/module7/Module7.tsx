/**
 * 保障需求分析 — V2.0
 * 新增：医院偏好选择、家庭责任法寿险、重疾治疗费模型
 * 位置：流程第3步（基本信息→财务→保障需求→教育→养老）
 */
import { useState } from 'react'
import { motion } from 'framer-motion'
import { Shield, AlertTriangle, CheckCircle, RefreshCw, Building2 } from 'lucide-react'
import ReactEChartsCore from 'echarts-for-react'
import { useStore } from '../../store/useStore'
import { NumberInput, RadioGroup } from '../../components/FormField'
import { calcInsuranceNeeds } from '../../api/client'
import type { InsuranceNeedsResult, CityTier, HospitalPreference } from '../../types'

function formatWan(v: number) {
  return `${(v / 10000).toFixed(0)}万`
}

const PRIORITY_META: Record<string, { label: string; color: string; emoji: string }> = {
  critical_illness: { label: '重疾险', color: 'text-accent-danger', emoji: '🏥' },
  life:             { label: '寿险',   color: 'text-accent-warning', emoji: '🛡️' },
  medical:          { label: '医疗险', color: 'text-accent',         emoji: '💊' },
  education:        { label: '教育保障', color: 'text-accent-success', emoji: '🎓' },
}

const HOSPITAL_OPTIONS: Array<{ value: HospitalPreference; label: string }> = [
  { value: 'public', label: '公立医院' },
  { value: 'vip', label: '特需门诊' },
  { value: 'private', label: '私立医院' },
  { value: 'international', label: '外资昂贵医院' },
]

function GapBarChart({ result }: { result: InsuranceNeedsResult }) {
  const items = [
    { name: '寿险', need: result.lifeInsuranceNeed, gap: result.lifeInsuranceGap, covered: result.lifeInsuranceNeed - result.lifeInsuranceGap },
    { name: '重疾险', need: result.criticalIllnessNeed, gap: result.criticalIllnessGap, covered: result.criticalIllnessNeed - result.criticalIllnessGap },
    { name: '医疗险', need: result.medicalNeed, gap: result.medicalGap, covered: result.medicalNeed - result.medicalGap },
    { name: '教育保障', need: result.educationProtectionNeed, gap: result.educationProtectionNeed, covered: 0 },
  ].filter(i => i.need > 0)

  const option = {
    tooltip: { trigger: 'axis' as const, axisPointer: { type: 'shadow' as const } },
    grid: { left: 80, right: 20, top: 10, bottom: 30 },
    xAxis: { type: 'value' as const, axisLabel: { formatter: (v: number) => `${(v / 10000).toFixed(0)}万`, color: '#86868B' }, splitLine: { lineStyle: { color: '#E8E8ED' } } },
    yAxis: { type: 'category' as const, data: items.map(i => i.name), axisLabel: { color: '#86868B' } },
    series: [
      { name: '已有保障', type: 'bar', stack: 'total', data: items.map(i => i.covered), itemStyle: { color: '#34C759' }, barWidth: 24 },
      { name: '保障缺口', type: 'bar', stack: 'total', data: items.map(i => i.gap), itemStyle: { color: '#FF3B30' }, barWidth: 24 },
    ],
  }

  return <ReactEChartsCore option={option} style={{ height: 180 }} />
}

export default function Module7() {
  const { customer, financial, educationResult, setInsuranceNeedsResult, setActiveModule } = useStore()
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [result, setResult] = useState<InsuranceNeedsResult | null>(null)

  // 已有保障输入
  const [existingLife, setExistingLife] = useState(0)
  const [existingCI, setExistingCI] = useState(0)
  const [existingMedical, setExistingMedical] = useState(0)

  // 医院偏好
  const [hospitalPreference, setHospitalPreference] = useState<HospitalPreference>('public')

  // 派生：负债余额
  const totalDebt = ((financial?.mortgageMonthly ?? 0) + (financial?.otherLoanMonthly ?? 0)) * 12 * 20
  const liquidAssets = financial?.availableAssets ?? 0
  const annualExpense = (financial?.fixedMonthlyExpense ?? 0) * 12
  const monthlyIncome = customer?.monthlyIncome ?? 0

  // 城市 tier 推断
  const tierMap: Record<string, CityTier> = {
    beijing: 1, shanghai: 1, guangzhou: 1, shenzhen: 1,
  }
  const cityTier = (tierMap[customer?.cityWork ?? ''] ?? 3) as CityTier

  async function handleCalc() {
    if (!customer?.age) {
      setError('请先完成基本信息填写')
      return
    }
    setLoading(true)
    setError(null)
    try {
      const r: InsuranceNeedsResult = await calcInsuranceNeeds({
        customerAge: customer.age,
        gender: customer.gender ?? 'male',
        monthlyIncome,
        totalFamilyMonthlyIncome: financial?.totalFamilyMonthlyIncome ?? monthlyIncome,
        retirementAge: customer.retirementAge ?? (customer.gender === 'male' ? 60 : 55),
        totalDebt,
        liquidAssets,
        existingLifeCoverage: existingLife * 10000,
        existingCriticalIllnessCoverage: existingCI * 10000,
        existingMedicalCoverage: existingMedical * 10000,
        annualExpense,
        socialSecurityType: customer.socialSecurityType ?? 'employee',
        cityTier,
        hasChildren: ((customer.children ?? []).length > 0),
        childrenCount: (customer.children ?? []).length,
        remainingEducationCost: educationResult?.familyTotal ?? 0,
        hospitalPreference,
      })
      setResult(r)
      setInsuranceNeedsResult(r)
    } catch (e: unknown) {
      const msg = (e as { response?: { data?: { error?: string } } })?.response?.data?.error
      setError(msg || '计算失败，请确认已正确填写前序模块')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">保障需求分析</h1>
        <p className="text-text-secondary text-sm mt-1">量化家庭保障缺口，明确保险配置优先级 — 保障是家庭风险管理的核心</p>
      </div>

      {/* 已有保障录入 */}
      <div className="card-accent p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Shield size={18} className="text-accent" />
          <h2 className="font-semibold text-sm">已有保险保障</h2>
        </div>
        <p className="text-xs text-text-muted">请填写您当前持有的保险保额，用于计算保障缺口</p>
        <div className="grid grid-cols-3 gap-4">
          <NumberInput
            label="寿险保额" value={existingLife}
            onChange={v => setExistingLife(v ?? 0)}
            unit="万元" min={0} hint="定期寿险 + 终身寿险"
          />
          <NumberInput
            label="重疾险保额" value={existingCI}
            onChange={v => setExistingCI(v ?? 0)}
            unit="万元" min={0} hint="重大疾病保险"
          />
          <NumberInput
            label="医疗险年度额度" value={existingMedical}
            onChange={v => setExistingMedical(v ?? 0)}
            unit="万元" min={0} hint="百万医疗 / 补充医疗"
          />
        </div>
      </div>

      {/* 医院偏好 */}
      <div className="card-accent p-6 space-y-4">
        <div className="flex items-center gap-2">
          <Building2 size={18} className="text-accent" />
          <h2 className="font-semibold text-sm">就医偏好</h2>
        </div>
        <p className="text-xs text-text-muted">您日常及重大疾病就医时，倾向选择哪类医院？这将影响医疗险产品推荐</p>
        <RadioGroup
          label=""
          value={hospitalPreference}
          options={HOSPITAL_OPTIONS}
          onChange={v => setHospitalPreference(v as HospitalPreference)}
        />
        <div className="text-xs text-text-muted bg-bg-float rounded-lg p-3">
          {hospitalPreference === 'public' && '公立医院：费用较低，百万医疗险（100万保额）即可覆盖'}
          {hospitalPreference === 'vip' && '特需门诊：部分费用不在普通医保范围，建议200万保额中高端医疗险'}
          {hospitalPreference === 'private' && '私立医院：就医体验好但费用高，建议300万保额高端医疗险'}
          {hospitalPreference === 'international' && '外资昂贵医院：费用极高，建议500万保额全球医疗险'}
        </div>
      </div>

      {/* 自动带入数据 */}
      <div className="card p-4 space-y-1 text-xs text-text-muted">
        <div className="font-semibold text-text-secondary text-sm mb-2">自动带入数据</div>
        <div>家庭年支出：<span className="text-text-primary font-medium">{annualExpense > 0 ? `${formatWan(annualExpense)}/年` : '—（请先完成财务分析）'}</span></div>
        <div>流动资产：<span className="text-text-primary font-medium">{liquidAssets > 0 ? formatWan(liquidAssets) : '—'}</span></div>
        <div>负债余额（估算）：<span className="text-text-primary font-medium">{totalDebt > 0 ? formatWan(totalDebt) : '—'}</span></div>
        <div>子女教育总费用：<span className="text-text-primary font-medium">{educationResult ? formatWan(educationResult.familyTotal) : '—（完成教育规划后自动带入）'}</span></div>
      </div>

      {error && (
        <div className="card border border-accent-danger/30 bg-accent-danger/10 p-4 text-sm text-accent-danger flex items-center gap-2">
          <AlertTriangle size={15} className="shrink-0" />{error}
        </div>
      )}

      <button onClick={handleCalc} disabled={loading} className="btn-primary flex items-center gap-2 px-6">
        {loading ? <RefreshCw size={16} className="animate-spin" /> : <Shield size={16} />}
        {loading ? '计算中...' : '分析保障缺口'}
      </button>

      {/* 加载骨架屏 */}
      {loading && !result && (
        <div className="space-y-4">
          <div className="card-accent p-5 space-y-3">
            <div className="h-5 w-32 bg-bg-float rounded animate-pulse" />
            <div className="h-8 w-24 bg-bg-float rounded animate-pulse" />
          </div>
          <div className="card p-5 space-y-3">
            <div className="h-4 w-48 bg-bg-float rounded animate-pulse" />
            <div className="h-40 bg-bg-float rounded animate-pulse" />
          </div>
          <div className="grid grid-cols-2 gap-3">
            {[1, 2, 3, 4].map(i => (
              <div key={i} className="card p-4 space-y-2">
                <div className="h-3 w-20 bg-bg-float rounded animate-pulse" />
                <div className="h-5 w-16 bg-bg-float rounded animate-pulse" />
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 计算结果 */}
      {result && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">

          {/* 总缺口概览 */}
          <div className="card-accent p-5">
            <div className="flex items-center gap-3 mb-3">
              {result.totalProtectionGap > 0
                ? <AlertTriangle size={22} className="text-accent-danger" />
                : <CheckCircle size={22} className="text-accent-success" />
              }
              <div>
                <div className="text-text-secondary text-sm">家庭保障总缺口</div>
                <div className={`text-3xl font-bold text-number ${result.totalProtectionGap > 0 ? 'text-accent-danger' : 'text-accent-success'}`}>
                  {result.totalProtectionGap > 0 ? formatWan(result.totalProtectionGap) : '保障充足'}
                </div>
              </div>
            </div>
          </div>

          {/* 缺口柱状图 */}
          <div className="card p-5 space-y-3">
            <h3 className="font-semibold text-sm flex items-center gap-2">
              <Shield size={16} className="text-accent" />
              保障需求 vs 已有保障
            </h3>
            <GapBarChart result={result} />
            <div className="flex gap-4 text-xs justify-center">
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-accent-success" />已有保障</span>
              <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-accent-danger" />保障缺口</span>
            </div>
          </div>

          {/* 优先级排序 */}
          {result.priorityOrder.length > 0 && (
            <div className="card p-5 space-y-3">
              <h3 className="font-semibold text-sm">配置优先级</h3>
              <div className="space-y-2">
                {result.priorityOrder.map((key, i) => {
                  const meta = PRIORITY_META[key]
                  if (!meta) return null
                  return (
                    <div key={key} className="flex items-start gap-3 bg-bg-float rounded-lg p-3">
                      <span className="text-lg leading-none shrink-0">{meta.emoji}</span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2">
                          <span className={`font-semibold text-sm ${meta.color}`}>
                            #{i + 1} {meta.label}
                          </span>
                        </div>
                        <p className="text-xs text-text-secondary mt-0.5 leading-relaxed">
                          {result.details[key]}
                        </p>
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>
          )}

          {/* 四项明细 */}
          <div className="grid grid-cols-2 gap-3">
            {[
              { label: '寿险（家庭责任）', need: result.lifeInsuranceNeed, gap: result.lifeInsuranceGap, color: 'accent-warning' },
              { label: '重疾险', need: result.criticalIllnessNeed, gap: result.criticalIllnessGap, color: 'accent-danger' },
              { label: '医疗险', need: result.medicalNeed, gap: result.medicalGap, color: 'accent' },
              { label: '教育保障', need: result.educationProtectionNeed, gap: result.educationProtectionNeed, color: 'accent-success' },
            ].map(item => (
              <div key={item.label} className="card p-4">
                <div className="text-text-muted text-xs mb-1">{item.label}</div>
                <div className="text-text-primary font-semibold text-number">
                  需求 {item.need > 0 ? formatWan(item.need) : '—'}
                </div>
                <div className={`text-xs mt-1 ${item.gap > 0 ? `text-${item.color}` : 'text-accent-success'}`}>
                  {item.gap > 0 ? `缺口 ${formatWan(item.gap)}` : '✓ 已覆盖'}
                </div>
              </div>
            ))}
          </div>
        </motion.div>
      )}

      <div className="flex justify-between pt-2">
        <button onClick={() => setActiveModule(2)} className="btn-secondary px-6 py-2.5">上一步</button>
        <button onClick={() => setActiveModule(5)} className="btn-primary px-8 py-2.5">下一步：养老测算</button>
      </div>
    </div>
  )
}
