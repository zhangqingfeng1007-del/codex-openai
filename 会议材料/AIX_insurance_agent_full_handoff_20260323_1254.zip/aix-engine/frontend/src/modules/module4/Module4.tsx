/**
 * 模块四：养老缺口测算 — V1.0
 * 包含：5.1新增字段（健康状况、退休城市）、5.3养老支出、5.6储备、5.7三情景
 */
import { useState, useEffect, useRef, useCallback } from 'react'
import { motion } from 'framer-motion'
import { TrendingDown, TrendingUp, Landmark, PiggyBank, AlertCircle, RefreshCw, ChevronDown, ChevronUp, Sun, Cloud, CloudRain } from 'lucide-react'
import { useStore } from '../../store/useStore'
import { NumberInput, RadioGroup, CitySelect, SliderInput } from '../../components/FormField'
import { fetchCities, fetchScenarioParams, fetchExpenseDefaults, calcPensionGap } from '../../api/client'
import CashFlowChart from '../../components/charts/CashFlowChart'
import ThreePillarChart from '../../components/charts/ThreePillarChart'
import MonteCarloChart from '../../components/charts/MonteCarloChart'
import type { PensionCalculationResult, HealthStatus, RetirementLivingType, RetirementExpense, PensionReserve, Scenario, CityOption, ScenarioParams } from '../../types'

function formatYuan(v: number): string {
  if (Math.abs(v) >= 10000) return `${(v / 10000).toFixed(1)}万`
  return v.toLocaleString()
}

function fmtPct(v: number) { return `${(v * 100).toFixed(1)}%` }

const HEALTH_OPTIONS: Array<{ value: HealthStatus; label: string }> = [
  { value: 'good', label: '良好' }, { value: 'average', label: '一般' }, { value: 'poor', label: '较差' },
]
const LIVING_OPTIONS: Array<{ value: RetirementLivingType; label: string }> = [
  { value: 'own_home', label: '自有住房' }, { value: 'rent', label: '租房' }, { value: 'senior_community', label: '养老社区' },
]
const TIER_OPTIONS: Array<{ value: 'low' | 'mid' | 'high'; label: string }> = [
  { value: 'low', label: '基础' }, { value: 'mid', label: '中等' }, { value: 'high', label: '较高' },
]

const SCENARIO_STYLE: Record<Scenario, { label: string; icon: React.ReactNode; color: string }> = {
  pessimistic: { label: '悲观', icon: <CloudRain size={16} />, color: 'border-accent-danger text-accent-danger bg-accent-danger/10' },
  neutral:     { label: '中性', icon: <Cloud size={16} />,     color: 'border-accent text-accent bg-accent/10' },
  optimistic:  { label: '乐观', icon: <Sun size={16} />,       color: 'border-accent-success text-accent-success bg-accent-success/10' },
}

const FALLBACK_EXPENSE: RetirementExpense = {
  activeLivingType: 'own_home', activeMonthlyResidence: 0,
  semiCareMonthlyNursing: 8000, fullCareMonthlyNursing: 15000,
  medicalTier: 'mid', leisureTier: 'mid', monthlyLiving: 5000, otherAnnual: 20000,
}
const DEFAULT_RESERVE: PensionReserve = {
  enterpriseAnnuityBalance: 0, personalPensionBalance: 0, otherSavings: 0,
  enterpriseAnnuityMonthly: 0, personalPensionAnnual: 12000, otherMonthlySaving: 0,
}

type ExpenseDefaults = Record<string, Record<string, { monthlyLiving: number; otherAnnual: number; activeMonthlyResidence: number; semiCareMonthlyNursing: number; fullCareMonthlyNursing: number }>>

function CollapsibleSection({ title, children, defaultOpen = true }: { title: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="card overflow-hidden">
      <button className="w-full flex items-center justify-between px-5 py-4 text-left" onClick={() => setOpen(v => !v)}>
        <span className="font-semibold text-sm">{title}</span>
        {open ? <ChevronUp size={16} className="text-text-muted" /> : <ChevronDown size={16} className="text-text-muted" />}
      </button>
      {open && <div className="px-5 pb-5 space-y-4 border-t border-bg-border pt-4">{children}</div>}
    </div>
  )
}

export default function Module4() {
  const { customer, updateCustomer, scenario, setScenario, scenarioParams, setPensionResult, pensionResult, setActiveModule, setScenariosConfig } = useStore()
  const [cities, setCities] = useState<CityOption[]>([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [remoteScenariosConfig, setRemoteScenariosConfig] = useState<Record<Scenario, ScenarioParams> | null>(null)
  const [expenseDefaults, setExpenseDefaults] = useState<ExpenseDefaults | null>(null)

  // 5.1 健康状况 & 退休城市
  const [health, setHealth] = useState<HealthStatus>('average')
  const [spouseHealth, setSpouseHealth] = useState<HealthStatus>('average')
  const [cityRetire, setCityRetireLocal] = useState<string>(customer?.cityRetire || customer?.cityWork || '')
  const [spouseCityRetire, setSpouseCityRetireLocal] = useState<string>(customer?.spouse?.cityRetire || customer?.spouse?.cityWork || customer?.cityRetire || customer?.cityWork || '')

  // Sync city_retire changes back to Module1 store (bidirectional)
  const setCityRetire = (v: string) => {
    setCityRetireLocal(v)
    updateCustomer({ cityRetire: v })
  }
  const setSpouseCityRetire = (v: string) => {
    setSpouseCityRetireLocal(v)
    if (customer?.spouse) {
      updateCustomer({ spouse: { ...customer.spouse, cityRetire: v } as any })
    }
  }

  // 5.3 退休支出
  const [expense, setExpense] = useState<RetirementExpense>(FALLBACK_EXPENSE)
  // 5.6 储备
  const [reserve, setReserve] = useState<PensionReserve>(DEFAULT_RESERVE)
  // 可选：自定义退休年龄
  const [overrideRetirementAge, setOverrideRetirementAge] = useState<number | undefined>()

  const patchExpense = (patch: Partial<RetirementExpense>) => setExpense(prev => ({ ...prev, ...patch }))
  const patchReserve = (patch: Partial<PensionReserve>) => setReserve(prev => ({ ...prev, ...patch }))

  useEffect(() => {
    fetchCities().then(setCities).catch(console.error)
    fetchScenarioParams().then((cfg: Record<Scenario, ScenarioParams>) => {
      setRemoteScenariosConfig(cfg)
      setScenariosConfig(cfg)
    }).catch(console.error)
    fetchExpenseDefaults().then(setExpenseDefaults).catch(console.error)
  }, [])

  // 当退休城市变化时，用 admin-config 的支出默认值预填充
  useEffect(() => {
    if (!expenseDefaults || !cityRetire) return
    const tierCity = cities.find(c => c.code === cityRetire)
    if (!tierCity) return
    const tierKey = `tier${tierCity.tier}`
    const row = expenseDefaults[tierKey]?.['mid']
    if (!row) return
    setExpense(prev => ({
      ...prev,
      monthlyLiving: row.monthlyLiving,
      otherAnnual: row.otherAnnual,
      activeMonthlyResidence: row.activeMonthlyResidence,
      semiCareMonthlyNursing: row.semiCareMonthlyNursing,
      fullCareMonthlyNursing: row.fullCareMonthlyNursing,
    }))
  }, [cityRetire, expenseDefaults, cities])

  async function handleCalc() {
    if (!customer?.age) { setError('请先完成模块一（客户基本信息）'); return }
    setLoading(true); setError(null)
    try {
      const result: PensionCalculationResult = await calcPensionGap({
        customer: { ...customer, retirementAge: overrideRetirementAge || customer.retirementAge },
        cityRetire: cityRetire || customer.cityWork,
        health,
        spouseHealth: customer.hasSpouse ? spouseHealth : undefined,
        expense,
        reserve,
        scenario,
        scenarioParams,
      })
      setPensionResult(result)
    } catch (e: unknown) {
      const msg = (e as { response?: { data?: { error?: string } } })?.response?.data?.error
      setError(msg || '计算失败，请确认已正确填写模块一信息')
    } finally {
      setLoading(false)
    }
  }

  // 三情景对比
  const [comparing, setComparing] = useState(false)
  const [compLoading, setCompLoading] = useState(false)
  const [compResults, setCompResults] = useState<Record<Scenario, PensionCalculationResult> | null>(null)

  async function handleCompare() {
    if (!customer?.age) return
    setCompLoading(true)
    try {
      const scenarios: Scenario[] = ['pessimistic', 'neutral', 'optimistic']
      const cfgs = remoteScenariosConfig ?? ({} as Record<Scenario, ScenarioParams>)
      const results = await Promise.all(scenarios.map(s =>
        calcPensionGap({
          customer: { ...customer, retirementAge: overrideRetirementAge || customer.retirementAge },
          cityRetire: cityRetire || customer.cityWork,
          health,
          spouseHealth: customer.hasSpouse ? spouseHealth : undefined,
          expense,
          reserve,
          scenario: s,
          scenarioParams: cfgs[s] ?? scenarioParams,
        })
      ))
      setCompResults({
        pessimistic: results[0],
        neutral: results[1],
        optimistic: results[2],
      })
      setComparing(true)
    } catch {
      setError('对比计算失败')
    } finally {
      setCompLoading(false)
    }
  }

  // Monte Carlo simulation
  interface MCData { years: number[]; p10: number[]; p50: number[]; p90: number[]; mean: number[]; successRate: number }
  const [mcRunning, setMcRunning] = useState(false)
  const [mcProgress, setMcProgress] = useState(0)
  const [mcData, setMcData] = useState<MCData | null>(null)
  const workerRef = useRef<Worker | null>(null)

  const handleMonteCarlo = useCallback(() => {
    if (!pensionResult || !customer?.age) return
    setMcRunning(true)
    setMcProgress(0)
    setMcData(null)

    // Terminate previous worker if any
    workerRef.current?.terminate()

    const worker = new Worker(new URL('../../workers/monte-carlo.worker.ts', import.meta.url), { type: 'module' })
    workerRef.current = worker

    worker.onmessage = (e) => {
      const msg = e.data as { type: string; progress?: number; data?: MCData }
      if (msg.type === 'progress') {
        setMcProgress(msg.progress || 0)
      } else if (msg.type === 'result' && msg.data) {
        setMcData(msg.data)
        setMcRunning(false)
        worker.terminate()
        workerRef.current = null
      }
    }

    worker.onerror = () => {
      setMcRunning(false)
      worker.terminate()
      workerRef.current = null
    }

    worker.postMessage({
      currentAge: customer.age,
      retirementAge: pensionResult.retirementAge,
      expectedLifespan: pensionResult.expectedLifespan,
      monthlyIncome: customer.monthlyIncome || 0,
      monthlyExpenseAtRetirement: expense.monthlyLiving + (expense.otherAnnual / 12),
      totalReservePV: pensionResult.totalReservePV,
      monthlyPension: pensionResult.monthlyPension,
      wageGrowthRate: scenarioParams.wageGrowthRate,
      inflationRate: scenarioParams.inflationRate,
      returnRate: scenarioParams.returnRate,
      numSimulations: 10000,
    })
  }, [pensionResult, customer, expense, scenarioParams])

  // Cleanup worker on unmount
  useEffect(() => () => { workerRef.current?.terminate() }, [])

  const r = pensionResult

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">养老缺口测算</h1>
        <p className="text-text-secondary text-sm mt-1">设置退休生活预期，测算三支柱养老缺口</p>
      </div>

      {/* ===== 5.7 三情景选择（文档5.7） ===== */}
      <div className="card p-5 space-y-3">
        <h2 className="font-semibold text-sm">情景假设（5.7）</h2>
        <p className="text-xs text-text-muted">选择不同假设情景，测算结果实时更新。默认中性情景。</p>
        <div className="grid grid-cols-3 gap-3">
          {(Object.keys(SCENARIO_STYLE) as Scenario[]).map(s => {
            const st = SCENARIO_STYLE[s]
            const p = (remoteScenariosConfig ?? {})[s]
            const desc = p ? `工资增速${fmtPct(p.wageGrowthRate)}·通胀${fmtPct(p.inflationRate)}·收益${fmtPct(p.returnRate)}` : '—'
            return (
            <button
              key={s}
              onClick={() => setScenario(s)}
              className={`flex flex-col items-center gap-1.5 p-3 rounded-lg border-2 transition-all ${
                scenario === s ? st.color : 'border-bg-border text-text-secondary hover:border-accent/40'
              }`}
            >
              {st.icon}
              <span className="font-semibold text-sm">{st.label}</span>
              <span className="text-xs text-center leading-tight opacity-80">{desc}</span>
            </button>
          )})}
        </div>
        <div className="grid grid-cols-3 gap-2 text-xs text-text-muted bg-bg-float rounded-lg p-3">
          <div>工资增速：<span className="text-text-primary font-medium">{(scenarioParams.wageGrowthRate * 100).toFixed(1)}%</span></div>
          <div>通胀率：<span className="text-text-primary font-medium">{(scenarioParams.inflationRate * 100).toFixed(1)}%</span></div>
          <div>投资收益：<span className="text-text-primary font-medium">{(scenarioParams.returnRate * 100).toFixed(1)}%</span></div>
        </div>
      </div>

      {/* ===== 5.1 健康状况 & 退休城市 ===== */}
      <CollapsibleSection title="健康状况与退休城市（5.1）">
        <div className="grid grid-cols-1 gap-4">
          <RadioGroup label="本人健康状况" value={health} options={HEALTH_OPTIONS} onChange={setHealth}
            hint="影响预期寿命（良好+3年/较差-3年）及退休三阶段划分" />
          {customer?.hasSpouse && (
            <RadioGroup label="配偶健康状况" value={spouseHealth} options={HEALTH_OPTIONS} onChange={setSpouseHealth} />
          )}
        </div>
        <div className="grid grid-cols-2 gap-4 mt-2">
          <CitySelect label="本人预计退休城市" value={cityRetire} onChange={setCityRetire} cities={cities}
            hint="默认=工作城市，影响养老支出默认值" />
          {customer?.hasSpouse && (
            <CitySelect label="配偶预计退休城市" value={spouseCityRetire} onChange={setSpouseCityRetire} cities={cities} />
          )}
        </div>
      </CollapsibleSection>

      {/* ===== 5.3 退休居住与生活支出 ===== */}
      <CollapsibleSection title="退休居住与生活支出（5.3）">
        <RadioGroup label="活跃期居住方式" value={expense.activeLivingType} options={LIVING_OPTIONS}
          onChange={v => patchExpense({ activeLivingType: v })} />
        {expense.activeLivingType !== 'own_home' && (
          <NumberInput label="活跃期每月居住支出" value={expense.activeMonthlyResidence}
            onChange={v => patchExpense({ activeMonthlyResidence: v })} unit="元" min={0} />
        )}
        <div className="grid grid-cols-2 gap-4">
          <NumberInput label="日常月生活费" value={expense.monthlyLiving}
            onChange={v => patchExpense({ monthlyLiving: v })} unit="元" min={0}
            hint="餐饮、交通、日常消费" />
          <NumberInput label="年度其他支出" value={expense.otherAnnual}
            onChange={v => patchExpense({ otherAnnual: v })} unit="元/年" min={0}
            hint="旅游、礼品、维修等" />
          <RadioGroup label="医疗费用档次" value={expense.medicalTier} options={TIER_OPTIONS}
            onChange={v => patchExpense({ medicalTier: v })}
            hint="基础2万/中等5万/高档10万（年）" />
          <RadioGroup label="休闲娱乐档次" value={expense.leisureTier} options={TIER_OPTIONS}
            onChange={v => patchExpense({ leisureTier: v })}
            hint="基础1万/中等3万/高档5万（年）" />
        </div>
      </CollapsibleSection>

      {/* ===== 护理期支出 ===== */}
      <CollapsibleSection title="护理期支出（半自理/全护理）" defaultOpen={false}>
        <div className="grid grid-cols-2 gap-4">
          <NumberInput label="半自理期月护理费" value={expense.semiCareMonthlyNursing}
            onChange={v => patchExpense({ semiCareMonthlyNursing: v })} unit="元" min={0} />
          <NumberInput label="全护理期月护理费" value={expense.fullCareMonthlyNursing}
            onChange={v => patchExpense({ fullCareMonthlyNursing: v })} unit="元" min={0} />
        </div>
      </CollapsibleSection>

      {/* ===== 5.6 养老储备 ===== */}
      <CollapsibleSection title="已有养老储备（5.6）" defaultOpen={false}>
        <div className="grid grid-cols-2 gap-4">
          <NumberInput label="企业年金账户余额" value={reserve.enterpriseAnnuityBalance}
            onChange={v => patchReserve({ enterpriseAnnuityBalance: v })} unit="元" min={0} />
          <NumberInput label="企业年金月新增缴纳" value={reserve.enterpriseAnnuityMonthly}
            onChange={v => patchReserve({ enterpriseAnnuityMonthly: v })} unit="元/月" min={0} />
          <NumberInput label="个人养老金账户余额" value={reserve.personalPensionBalance}
            onChange={v => patchReserve({ personalPensionBalance: v })} unit="元" min={0} />
          <NumberInput label="个人养老金年新增" value={reserve.personalPensionAnnual}
            onChange={v => patchReserve({ personalPensionAnnual: v })} unit="元/年" min={0}
            hint="税优上限12,000元/年" />
          <NumberInput label="专项养老存款/投资" value={reserve.otherSavings}
            onChange={v => patchReserve({ otherSavings: v })} unit="元" min={0} />
          <NumberInput label="其他月新增养老储蓄" value={reserve.otherMonthlySaving}
            onChange={v => patchReserve({ otherMonthlySaving: v })} unit="元/月" min={0} />
        </div>
      </CollapsibleSection>

      {/* ===== 可选：覆盖退休年龄 ===== */}
      <div className="card-accent p-5 space-y-3">
        <h2 className="font-semibold text-sm">可选：自定义退休年龄</h2>
        <SliderInput label="退休年龄（覆盖法定值）" value={overrideRetirementAge ?? 60}
          onChange={v => setOverrideRetirementAge(v)}
          min={50} max={70} unit="岁"
          hint="拖动滑块或输入数字，不填则使用系统计算的法定退休年龄"
          tooltip="弹性退休年龄范围：法定退休年龄±3年"
          marks={[{ value: 50, label: '50' }, { value: 55, label: '55' }, { value: 60, label: '60' }, { value: 65, label: '65' }, { value: 70, label: '70' }]} />
        {error && (
          <div className="card border border-accent-danger/30 bg-accent-danger/10 p-4 text-sm text-accent-danger flex items-center gap-2">
            <AlertCircle size={15} className="shrink-0" />{error}
          </div>
        )}
        <button onClick={handleCalc} disabled={loading} className="btn-primary flex items-center gap-2 px-6">
          {loading ? <RefreshCw size={16} className="animate-spin" /> : <TrendingDown size={16} />}
          {loading ? '计算中...' : '开始测算养老缺口'}
        </button>
      </div>

      {/* 加载骨架屏 */}
      {loading && !r && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            {[1, 2].map(i => (
              <div key={i} className="card-accent p-5 space-y-3">
                <div className="h-4 w-24 bg-bg-float rounded animate-pulse" />
                <div className="h-8 w-32 bg-bg-float rounded animate-pulse" />
                <div className="h-3 w-40 bg-bg-float rounded animate-pulse" />
              </div>
            ))}
          </div>
          <div className="card p-5 space-y-3">
            <div className="h-4 w-48 bg-bg-float rounded animate-pulse" />
            <div className="h-32 bg-bg-float rounded animate-pulse" />
          </div>
        </div>
      )}

      {/* ===== 计算结果 ===== */}
      {r && (
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="card-accent p-5">
              <div className="flex items-center gap-2 mb-3">
                <TrendingDown size={18} className="text-accent-danger" />
                <span className="text-text-secondary text-sm">养老缺口</span>
              </div>
              <div className={`text-3xl font-bold text-number ${r.pensionGap > 0 ? 'text-accent-danger' : 'text-accent-success'}`}>
                {r.pensionGap > 0 ? '-' : '+'}{formatYuan(Math.abs(r.pensionGap))}元
              </div>
              <p className="text-text-secondary text-xs mt-1">{r.pensionGap > 0 ? '养老收入不足，需补充储蓄' : '养老收入充足，有盈余'}</p>
            </div>
            <div className="card-accent p-5">
              <div className="flex items-center gap-2 mb-3">
                <PiggyBank size={18} className="text-accent" />
                <span className="text-text-secondary text-sm">建议月储蓄</span>
              </div>
              <div className="text-3xl font-bold text-number text-accent">{formatYuan(r.monthlyPMT)}元</div>
              <p className="text-text-secondary text-xs mt-1">退休 {r.retirementAge}岁 · 寿命 {r.expectedLifespan}岁</p>
            </div>
          </div>

          {/* §9.6 三支柱覆盖横向堆叠图 */}
          <div className="card p-5 space-y-3">
            <div className="flex items-center gap-2 mb-1">
              <Landmark size={18} className="text-accent" />
              <h3 className="font-semibold text-sm">三支柱养老金分解（折现到退休时）</h3>
            </div>
            <ThreePillarChart
              tier1PV={r.tier1PV}
              tier2PV={r.tier2PV}
              tier3PV={r.tier3PV}
              pensionGap={r.pensionGap}
              totalNeedPV={r.totalNeedPV}
            />
            <div className="grid grid-cols-3 gap-2 text-center text-xs">
              {[
                { label: '第一支柱', sub: '社保', val: r.tier1PV, color: 'text-accent' },
                { label: '第二支柱', sub: '年金', val: r.tier2PV, color: 'text-accent-success' },
                { label: '第三支柱', sub: '个人', val: r.tier3PV, color: 'text-accent-warning' },
              ].map(({ label, sub, val, color }) => (
                <div key={label} className="bg-bg-float rounded-lg py-2">
                  <div className="text-text-muted">{label} · {sub}</div>
                  <div className={`font-semibold mt-0.5 text-number ${color}`}>{formatYuan(val)}元</div>
                </div>
              ))}
            </div>
            {r.pensionGap > 0 && (
              <div className="flex items-center gap-2 text-accent-danger text-sm bg-accent-danger/8 rounded-lg px-3 py-2">
                <TrendingDown size={15} />缺口：<strong>{formatYuan(r.pensionGap)}元</strong>，建议通过商业保险或储蓄补足
              </div>
            )}
          </div>

          {/* 三情景对比按钮 */}
          <div className="flex justify-center">
            <button
              onClick={handleCompare}
              disabled={compLoading}
              className="btn-secondary text-sm flex items-center gap-2 px-5 py-2"
            >
              {compLoading ? <RefreshCw size={14} className="animate-spin" /> : '📊'}
              {compLoading ? '计算中...' : '三情景对比'}
            </button>
          </div>

          {/* 三情景对比表 */}
          {comparing && compResults && (
            <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="card p-5 space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-semibold text-sm">悲观 / 中性 / 乐观 对比</h3>
                <button onClick={() => setComparing(false)} className="text-xs text-text-muted hover:text-accent">收起</button>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-text-secondary border-b border-bg-border">
                      <th className="pb-2 text-left font-normal">指标</th>
                      {(['pessimistic', 'neutral', 'optimistic'] as Scenario[]).map(s => (
                        <th key={s} className={`pb-2 text-right font-semibold ${SCENARIO_STYLE[s].color.split(' ')[1]}`}>
                          {SCENARIO_STYLE[s].label}
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {[
                      { label: '养老缺口', key: 'pensionGap', fmt: (v: number) => `${v > 0 ? '-' : '+'}${formatYuan(Math.abs(v))}` },
                      { label: '建议月储蓄', key: 'monthlyPMT', fmt: formatYuan },
                      { label: '第一支柱(社保)', key: 'tier1PV', fmt: formatYuan },
                      { label: '第二支柱(年金)', key: 'tier2PV', fmt: formatYuan },
                      { label: '第三支柱(个人)', key: 'tier3PV', fmt: formatYuan },
                      { label: '总需求现值', key: 'totalNeedPV', fmt: formatYuan },
                      { label: '退休年龄', key: 'retirementAge', fmt: (v: number) => `${v}岁` },
                      { label: '预期寿命', key: 'expectedLifespan', fmt: (v: number) => `${v}岁` },
                    ].map(row => (
                      <tr key={row.key} className="border-b border-bg-border/40">
                        <td className="py-2 text-text-secondary">{row.label}</td>
                        {(['pessimistic', 'neutral', 'optimistic'] as Scenario[]).map(s => (
                          <td key={s} className={`py-2 text-right text-number font-medium ${
                            row.key === 'pensionGap' && (compResults[s] as unknown as Record<string, number>)[row.key] > 0 ? 'text-accent-danger' : ''
                          }`}>
                            {row.fmt((compResults[s] as unknown as Record<string, number>)[row.key])}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
              {/* 三柱迷你图并排 */}
              <div className="grid grid-cols-3 gap-3">
                {(['pessimistic', 'neutral', 'optimistic'] as Scenario[]).map(s => {
                  const cr = compResults[s]
                  return (
                    <div key={s} className="text-center">
                      <div className={`text-xs font-semibold mb-1 ${SCENARIO_STYLE[s].color.split(' ')[1]}`}>
                        {SCENARIO_STYLE[s].label}
                      </div>
                      <ThreePillarChart tier1PV={cr.tier1PV} tier2PV={cr.tier2PV} tier3PV={cr.tier3PV} pensionGap={cr.pensionGap} totalNeedPV={cr.totalNeedPV} />
                    </div>
                  )
                })}
              </div>
            </motion.div>
          )}

          {/* §5.9 蒙特卡洛模拟 */}
          <div className="card p-5 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-semibold text-sm">蒙特卡洛模拟（§5.9）</h3>
              <button
                onClick={handleMonteCarlo}
                disabled={mcRunning}
                className="btn-secondary text-xs flex items-center gap-2 px-4 py-1.5"
              >
                {mcRunning ? <RefreshCw size={14} className="animate-spin" /> : null}
                {mcRunning ? `模拟中 ${mcProgress}%` : '运行10,000次模拟'}
              </button>
            </div>
            <p className="text-xs text-text-muted">基于当前参数，随机模拟工资增速、通胀率和投资回报率的波动，展示养老资产余额的概率分布。</p>
            {mcRunning && (
              <div className="w-full bg-bg-float rounded-full h-2 overflow-hidden">
                <div className="bg-accent h-full rounded-full transition-all duration-300" style={{ width: `${mcProgress}%` }} />
              </div>
            )}
            {mcData && (
              <>
                <MonteCarloChart data={mcData} retirementAge={r.retirementAge} />
                <div className="grid grid-cols-3 gap-3 text-center text-xs">
                  <div className="bg-accent-danger/10 rounded-lg p-2">
                    <div className="text-text-muted">P10（悲观）</div>
                    <div className="font-semibold text-accent-danger mt-0.5">{formatYuan(mcData.p10[mcData.p10.length - 1])}元</div>
                  </div>
                  <div className="bg-accent/10 rounded-lg p-2">
                    <div className="text-text-muted">P50（中位数）</div>
                    <div className="font-semibold text-accent mt-0.5">{formatYuan(mcData.p50[mcData.p50.length - 1])}元</div>
                  </div>
                  <div className="bg-accent-success/10 rounded-lg p-2">
                    <div className="text-text-muted">P90（乐观）</div>
                    <div className="font-semibold text-accent-success mt-0.5">{formatYuan(mcData.p90[mcData.p90.length - 1])}元</div>
                  </div>
                </div>
                <div className="flex items-center gap-2 text-sm bg-bg-float rounded-lg px-4 py-2">
                  <span className="text-text-muted">养老充足概率：</span>
                  <span className={`font-bold ${mcData.successRate >= 70 ? 'text-accent-success' : mcData.successRate >= 40 ? 'text-accent-warning' : 'text-accent-danger'}`}>
                    {mcData.successRate.toFixed(1)}%
                  </span>
                  <span className="text-text-muted text-xs">（资产余额在寿命终点 &gt; 0 的模拟比例）</span>
                </div>
              </>
            )}
          </div>

          {/* §9.6 逐年现金流图 + 表格 */}
          <div className="card p-5 space-y-3">
            <div className="flex items-center gap-2">
              <TrendingUp size={18} className="text-accent" />
              <h3 className="font-semibold text-sm">逐年现金流（工作期至寿命终点）</h3>
            </div>
            <CashFlowChart data={r.annualCashFlow} />
            <details className="text-xs">
              <summary className="text-text-muted cursor-pointer hover:text-text-primary transition-colors py-1">
                展开数据表格（前15年）
              </summary>
              <div className="overflow-x-auto mt-2">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-text-secondary border-b border-bg-border">
                      {['年份','年龄','阶段','工资收入','养老金','退休支出','净现金流','累计余额'].map(h => (
                        <th key={h} className="pb-2 pr-2 text-right first:text-left font-normal">{h}</th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {r.annualCashFlow.slice(0, 15).map(row => (
                      <tr key={row.year} className={`border-b border-bg-border/40 ${row.phase !== '工作期' ? 'bg-accent/3' : ''}`}>
                        <td className="py-1.5 pr-2 text-text-secondary">{row.year}</td>
                        <td className="py-1.5 pr-2 text-right">{row.age}</td>
                        <td className="py-1.5 pr-2 text-right">
                          <span className={`text-xs px-1 py-0.5 rounded ${row.phase === '工作期' ? 'bg-accent-success/20 text-accent-success' : 'bg-accent/20 text-accent'}`}>{row.phase}</span>
                        </td>
                        <td className="py-1.5 pr-2 text-right text-number">{row.salaryIncome > 0 ? formatYuan(row.salaryIncome) : '—'}</td>
                        <td className="py-1.5 pr-2 text-right text-number">{row.pensionIncome > 0 ? formatYuan(row.pensionIncome) : '—'}</td>
                        <td className="py-1.5 pr-2 text-right text-number">{row.retirementExpense > 0 ? formatYuan(row.retirementExpense) : '—'}</td>
                        <td className={`py-1.5 pr-2 text-right text-number font-medium ${row.netCashFlow < 0 ? 'text-accent-danger' : 'text-accent-success'}`}>{formatYuan(row.netCashFlow)}</td>
                        <td className={`py-1.5 text-right text-number ${row.cumulativeBalance < 0 ? 'text-accent-danger font-semibold' : ''}`}>{formatYuan(row.cumulativeBalance)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </details>
          </div>
        </motion.div>
      )}

      <div className="flex justify-between pt-2">
        <button onClick={() => setActiveModule(4)} className="btn-secondary px-6 py-2.5">上一步</button>
        <button onClick={() => setActiveModule(6)} disabled={!r} className="btn-primary px-8 py-2.5 disabled:opacity-50">下一步：综合分析</button>
      </div>
    </div>
  )
}
