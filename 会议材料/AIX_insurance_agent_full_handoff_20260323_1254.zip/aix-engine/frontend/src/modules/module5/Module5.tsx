/**
 * 模块五：AI综合规划报告 + 产品推荐 + 对话 — V1.0
 */
import { useState, useRef } from 'react'
import { useStore } from '../../store/useStore'
import { generateReport, chatWithAI, exportPdf } from '../../api/client'
import { FileText, Sparkles, RefreshCw, ChevronDown, ChevronUp, Send, Bot, User, Printer, Download } from 'lucide-react'
import type { ProductRecord } from '../../types'

/** 内联格式：**bold** `code` *italic* */
function inlineHtml(raw: string): string {
  return raw
    .replace(/\*\*(.*?)\*\*/g, '<strong class="text-text-primary font-semibold">$1</strong>')
    .replace(/\*(.*?)\*/g, '<em class="text-text-secondary italic">$1</em>')
    .replace(/`([^`]+)`/g, '<code class="bg-bg-float text-accent-warning px-1 py-0.5 rounded text-xs font-mono">$1</code>')
}

/** Markdown 渲染 — 支持标题/列表/表格/代码块/分割线 */
function SimpleMarkdown({ text }: { text: string }) {
  const nodes: React.ReactNode[] = []
  const lines = text.split('\n')
  let i = 0

  while (i < lines.length) {
    const line = lines[i]

    // 代码块
    if (line.startsWith('```')) {
      const lang = line.slice(3).trim()
      const codeLines: string[] = []
      i++
      while (i < lines.length && !lines[i].startsWith('```')) {
        codeLines.push(lines[i])
        i++
      }
      nodes.push(
        <pre key={i} className="bg-bg-float rounded-lg p-3 my-2 overflow-x-auto text-xs font-mono text-text-secondary leading-relaxed">
          {lang && <div className="text-text-muted text-[10px] mb-1 uppercase tracking-widest">{lang}</div>}
          {codeLines.join('\n')}
        </pre>
      )
      i++
      continue
    }

    // 表格 — 收集连续 | 开头的行
    if (line.trimStart().startsWith('|')) {
      const tableLines: string[] = []
      while (i < lines.length && lines[i].trimStart().startsWith('|')) {
        tableLines.push(lines[i])
        i++
      }
      const rows = tableLines.filter(l => !/^\s*\|[-:| ]+\|\s*$/.test(l))
      if (rows.length > 0) {
        const parseRow = (r: string) => r.replace(/^\||\|$/g, '').split('|').map(c => c.trim())
        const [header, ...body] = rows
        nodes.push(
          <div key={i} className="overflow-x-auto my-3">
            <table className="w-full text-xs text-left border-collapse">
              <thead>
                <tr>
                  {parseRow(header).map((cell, ci) => (
                    <th key={ci} className="px-3 py-2 bg-bg-float text-text-primary font-semibold border-b border-bg-border"
                      dangerouslySetInnerHTML={{ __html: inlineHtml(cell) }} />
                  ))}
                </tr>
              </thead>
              <tbody>
                {body.map((row, ri) => (
                  <tr key={ri} className="border-b border-bg-border/50 hover:bg-bg-float/50">
                    {parseRow(row).map((cell, ci) => (
                      <td key={ci} className="px-3 py-2 text-text-secondary"
                        dangerouslySetInnerHTML={{ __html: inlineHtml(cell) }} />
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )
      }
      continue
    }

    // 标题
    if (line.startsWith('### ')) { nodes.push(<h3 key={i} className="text-sm font-semibold text-accent mt-4 mb-1">{line.slice(4)}</h3>); i++; continue }
    if (line.startsWith('## '))  { nodes.push(<h2 key={i} className="text-base font-semibold text-text-primary mt-5 mb-1 border-b border-bg-border pb-1">{line.slice(3)}</h2>); i++; continue }
    if (line.startsWith('# '))   { nodes.push(<h1 key={i} className="text-lg font-bold text-text-primary mt-4 mb-2">{line.slice(2)}</h1>); i++; continue }

    // 无序列表
    if (line.startsWith('- ') || line.startsWith('* ')) {
      const items: string[] = []
      while (i < lines.length && (lines[i].startsWith('- ') || lines[i].startsWith('* '))) {
        items.push(lines[i].slice(2))
        i++
      }
      nodes.push(
        <ul key={i} className="space-y-1 my-1 pl-1">
          {items.map((item, ii) => (
            <li key={ii} className="flex gap-2 text-text-secondary text-sm">
              <span className="text-accent mt-0.5 shrink-0 text-xs">●</span>
              <span dangerouslySetInnerHTML={{ __html: inlineHtml(item) }} />
            </li>
          ))}
        </ul>
      )
      continue
    }

    // 有序列表
    if (/^\d+\. /.test(line)) {
      const items: Array<{ num: string; text: string }> = []
      while (i < lines.length && /^\d+\. /.test(lines[i])) {
        const m = lines[i].match(/^(\d+)\. (.*)$/)!
        items.push({ num: m[1], text: m[2] })
        i++
      }
      nodes.push(
        <ol key={i} className="space-y-1 my-1 pl-1">
          {items.map((item, ii) => (
            <li key={ii} className="flex gap-2 text-text-secondary text-sm">
              <span className="text-accent font-semibold shrink-0 min-w-[1.5rem] text-xs mt-0.5">{item.num}.</span>
              <span dangerouslySetInnerHTML={{ __html: inlineHtml(item.text) }} />
            </li>
          ))}
        </ol>
      )
      continue
    }

    // 分割线
    if (line === '---' || line === '***') { nodes.push(<hr key={i} className="border-bg-border my-4" />); i++; continue }

    // 空行
    if (line.trim() === '') { nodes.push(<div key={i} className="h-2" />); i++; continue }

    // 普通段落
    nodes.push(<p key={i} className="text-text-secondary text-sm leading-relaxed" dangerouslySetInnerHTML={{ __html: inlineHtml(line) }} />)
    i++
  }

  return <div className="space-y-0.5">{nodes}</div>
}

function DataSummaryCard({ label, children, defaultOpen = false }: { label: string; children: React.ReactNode; defaultOpen?: boolean }) {
  const [open, setOpen] = useState(defaultOpen)
  return (
    <div className="card overflow-hidden">
      <button className="w-full flex items-center justify-between px-4 py-3 text-sm text-left" onClick={() => setOpen(v => !v)}>
        <span className="font-medium">{label}</span>
        {open ? <ChevronUp size={16} className="text-text-muted" /> : <ChevronDown size={16} className="text-text-muted" />}
      </button>
      {open && <div className="px-4 pb-4">{children}</div>}
    </div>
  )
}

function fmt(n: number | undefined) {
  if (n === undefined || n === null) return '—'
  if (Math.abs(n) >= 10000) return (n / 10000).toFixed(1) + ' 万'
  return n.toLocaleString() + ' 元'
}

function ProductCard({ product }: { product: ProductRecord }) {
  const typeColors: Record<string, string> = {
    '年金险': 'bg-accent/20 text-accent',
    '增额终身寿': 'bg-accent-success/20 text-accent-success',
    '教育金': 'bg-accent-warning/20 text-accent-warning',
    '定期寿险': 'bg-accent-danger/20 text-accent-danger',
    '重疾险': 'bg-purple-500/20 text-purple-400',
    '个人养老金': 'bg-blue-500/20 text-blue-400',
  }
  const colorClass = typeColors[product.productType] || 'bg-bg-float text-text-muted'
  return (
    <div className="bg-bg-float rounded-lg p-4 space-y-2">
      <div className="flex items-center justify-between">
        <span className="font-medium text-sm text-text-primary">{product.name}</span>
        <span className={`text-xs px-2 py-0.5 rounded-full ${colorClass}`}>{product.productType}</span>
      </div>
      <p className="text-xs text-text-secondary">{product.highlights}</p>
      <p className="text-xs text-text-muted">适合年龄：{product.minAge}~{product.maxAge}岁</p>
    </div>
  )
}

type ChatMessage = { role: 'user' | 'assistant'; content: string }

export default function Module5() {
  const { customer, financial, financialScore, pensionResult, educationResult, insuranceNeedsResult, scenario, scenarioParams, setActiveModule } = useStore()
  const [report, setReport] = useState('')
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [done, setDone] = useState(false)
  const [products, setProducts] = useState<ProductRecord[] | null>(null)
  const [noProducts, setNoProducts] = useState(false)
  const reportRef = useRef<HTMLDivElement>(null)

  // 对话框
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([])
  const [chatInput, setChatInput] = useState('')
  const [chatLoading, setChatLoading] = useState(false)
  const chatEndRef = useRef<HTMLDivElement>(null)

  const canGenerate = !!pensionResult
  const [pdfLoading, setPdfLoading] = useState(false)

  const handleExportPdf = async () => {
    if (!report) return
    setPdfLoading(true)
    try {
      const blob = await exportPdf({
        reportContent: report,
        customerName: customer?.name,
        customerAge: customer?.age,
        customerGender: customer?.gender,
        generatedAt: new Date().toLocaleDateString('zh-CN'),
      })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `AIX_Report_${Date.now()}.pdf`
      a.click()
      URL.revokeObjectURL(url)
    } catch {
      // Fallback to browser print if server PDF fails
      handlePrint()
    } finally {
      setPdfLoading(false)
    }
  }

  const handlePrint = () => {
    // 将报告内容注入打印区域，然后触发打印
    const printArea = document.getElementById('aix-print-area')
    if (!printArea || !report) return
    const name = customer?.age ? `客户 ${customer.age}岁${customer.gender === 'male' ? '男' : '女'}` : '客户'
    const date = new Date().toLocaleDateString('zh-CN')
    printArea.innerHTML = `
      <div class="print-header">
        <h1>AIX保险智能规划报告</h1>
        <p style="color:#666;font-size:10pt;">${name} · 生成日期：${date}</p>
      </div>
      <div id="aix-report-content"></div>
    `
    // 将 Markdown 转为可打印 HTML（直接用纯文本段落，保留换行）
    const contentDiv = printArea.querySelector('#aix-report-content')
    if (contentDiv) {
      contentDiv.innerHTML = report
        .split('\n')
        .map(line => {
          if (line.startsWith('## ')) return `<h2>${line.slice(3)}</h2>`
          if (line.startsWith('### ')) return `<h3>${line.slice(4)}</h3>`
          if (line.startsWith('# ')) return `<h1>${line.slice(2)}</h1>`
          if (line.startsWith('- ') || line.startsWith('* ')) return `<p style="padding-left:1em">• ${line.slice(2)}</p>`
          if (/^\d+\. /.test(line)) return `<p style="padding-left:1em">${line}</p>`
          if (line === '---') return '<hr/>'
          if (!line.trim()) return '<br/>'
          return `<p>${line.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')}</p>`
        })
        .join('')
    }
    window.print()
  }

  const handleGenerate = async () => {
    setLoading(true)
    setReport('')
    setDone(false)
    setError(null)
    setProducts(null)
    setNoProducts(false)

    try {
      await generateReport(
        {
          customer,
          financial: {
            ...financial,
            totalFamilyMonthlyIncome: (customer?.monthlyIncome || 0) + (customer?.spouse?.monthlyIncome || 0),
          },
          financialScore,
          pensionResult,
          educationResult,
          insuranceNeedsResult,
          scenario,
          scenarioParams,
        },
        (productsData) => {
          if (productsData.isEmpty) {
            setNoProducts(true)
            setProducts([])
          } else {
            setProducts(productsData.candidates as ProductRecord[])
          }
        },
        (chunk) => {
          setReport(prev => {
            const next = prev + chunk
            setTimeout(() => {
              reportRef.current?.scrollTo({ top: reportRef.current.scrollHeight, behavior: 'smooth' })
            }, 0)
            return next
          })
        }
      )
      setDone(true)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : '生成失败，请重试')
    } finally {
      setLoading(false)
    }
  }

  const handleChat = async () => {
    if (!chatInput.trim() || chatLoading) return
    const userMsg: ChatMessage = { role: 'user', content: chatInput.trim() }
    const newMessages = [...chatMessages, userMsg]
    setChatMessages(newMessages)
    setChatInput('')
    setChatLoading(true)

    // 构造带报告上下文的消息
    const contextMessages = [
      ...(report ? [{ role: 'assistant' as const, content: `以下是已生成的规划报告摘要：\n${report.slice(0, 2000)}` }] : []),
      ...newMessages,
    ]

    let aiContent = ''
    const assistantIdx = newMessages.length
    setChatMessages(prev => [...prev, { role: 'assistant', content: '' }])

    try {
      await chatWithAI(contextMessages, (chunk) => {
        aiContent += chunk
        setChatMessages(prev => {
          const updated = [...prev]
          updated[assistantIdx] = { role: 'assistant', content: aiContent }
          return updated
        })
        setTimeout(() => chatEndRef.current?.scrollIntoView({ behavior: 'smooth' }), 0)
      })
    } catch {
      setChatMessages(prev => {
        const updated = [...prev]
        updated[assistantIdx] = { role: 'assistant', content: '抱歉，对话请求失败，请重试。' }
        return updated
      })
    } finally {
      setChatLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">综合分析与规划报告</h1>
        <p className="text-text-secondary text-sm mt-1">AI 综合分析所有模块数据，生成个性化财务规划报告</p>
      </div>

      {!canGenerate ? (
        <div className="card p-8 text-center space-y-3">
          <FileText size={32} className="text-text-secondary mx-auto" />
          <p className="text-text-secondary">请先完成养老缺口测算，再生成综合报告</p>
          <button onClick={() => setActiveModule(5)} className="btn-primary mx-auto block px-6 py-2">前往养老测算</button>
        </div>
      ) : (
        <>
          {/* 数据摘要 */}
          <div className="space-y-2">
            {pensionResult && (
              <DataSummaryCard label="养老规划摘要" defaultOpen>
                <div className="grid grid-cols-2 gap-2 text-xs text-text-secondary">
                  <div>退休年龄：<span className="text-text-primary font-medium">{pensionResult.retirementAge} 岁</span></div>
                  <div>养老缺口：<span className="text-accent-danger font-medium">{fmt(pensionResult.pensionGap)}</span></div>
                  <div>建议月储蓄：<span className="text-accent-success font-medium">{fmt(pensionResult.monthlyPMT)}</span></div>
                  <div>预期寿命：<span className="text-text-primary font-medium">{pensionResult.expectedLifespan} 岁</span></div>
                </div>
              </DataSummaryCard>
            )}
            {financialScore && (
              <DataSummaryCard label="财务健康评分">
                <div className="grid grid-cols-2 gap-2 text-xs text-text-secondary">
                  <div>综合评分：<span className="text-text-primary font-medium">{financialScore.total} 分</span></div>
                  <div>收支结余率：<span className="text-text-primary font-medium">{(financialScore.surplusRatio * 100).toFixed(1)}%</span></div>
                  <div>负债压力比：<span className="text-text-primary font-medium">{(financialScore.debtRatio * 100).toFixed(1)}%</span></div>
                  <div>社保层级：<span className="text-text-primary font-medium">{financialScore.ssLevel === 'high' ? '高保障' : financialScore.ssLevel === 'medium' ? '中等' : '低保障'}</span></div>
                </div>
              </DataSummaryCard>
            )}
            {educationResult && educationResult.children.length > 0 && (
              <DataSummaryCard label="教育规划摘要">
                <div className="grid grid-cols-2 gap-2 text-xs text-text-secondary">
                  <div>家庭教育总费用：<span className="text-text-primary font-medium">{fmt(educationResult.familyTotal)}</span></div>
                  <div>月储蓄目标（保守）：<span className="text-accent-success font-medium">{fmt(educationResult.monthlyTargetConservative)}</span></div>
                </div>
              </DataSummaryCard>
            )}
          </div>

          {/* 生成按钮 */}
          {!report && !loading && (
            <button onClick={handleGenerate} className="btn-primary w-full py-3 text-base flex items-center justify-center gap-2">
              <Sparkles size={18} />生成 AI 综合规划报告
            </button>
          )}

          {/* 流式报告 */}
          {(report || loading) && (
            <div className="card p-6">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center gap-2">
                  <Sparkles size={16} className="text-accent" />
                  <span className="font-semibold text-sm">AI 综合规划报告</span>
                  {loading && (
                    <span className="text-xs text-text-muted flex items-center gap-1">
                      <span className="inline-block w-1.5 h-1.5 rounded-full bg-accent animate-pulse" />
                      生成中...
                    </span>
                  )}
                  {done && <span className="badge-success">已完成</span>}
                </div>
                {done && (
                  <div className="flex items-center gap-2">
                    <button onClick={handleExportPdf} disabled={pdfLoading} className="text-xs text-text-muted hover:text-accent flex items-center gap-1 px-2 py-1 rounded hover:bg-bg-float disabled:opacity-50">
                      {pdfLoading ? <RefreshCw size={12} className="animate-spin" /> : <Download size={12} />}
                      {pdfLoading ? '生成PDF...' : '导出PDF'}
                    </button>
                    <button onClick={handlePrint} className="text-xs text-text-muted hover:text-accent flex items-center gap-1 px-2 py-1 rounded hover:bg-bg-float">
                      <Printer size={12} /> 打印
                    </button>
                    <button onClick={handleGenerate} className="text-xs text-text-muted hover:text-accent flex items-center gap-1">
                      <RefreshCw size={12} /> 重新生成
                    </button>
                  </div>
                )}
              </div>
              <div ref={reportRef} className="max-h-[60vh] overflow-y-auto pr-1">
                {report ? (
                  <SimpleMarkdown text={report} />
                ) : (
                  <div className="space-y-2">
                    {[80, 60, 90, 50, 70].map((w, i) => (
                      <div key={i} className="h-3 bg-bg-float rounded animate-pulse" style={{ width: `${w}%` }} />
                    ))}
                  </div>
                )}
              </div>
            </div>
          )}

          {error && (
            <div className="card border border-accent-danger/30 bg-accent-danger/10 p-4 text-sm text-accent-danger">{error}</div>
          )}

          {/* 产品推荐区 — 报告完成后显示 */}
          {done && products !== null && (
            <div className="card p-5 space-y-3">
              <div className="flex items-center gap-2">
                <Sparkles size={16} className="text-accent" />
                <span className="font-semibold text-sm">规则引擎产品推荐</span>
              </div>
              {noProducts ? (
                <div className="text-center py-4 text-text-secondary text-sm bg-bg-float rounded-lg">
                  无符合产品（当前情景下暂无匹配产品）
                </div>
              ) : (
                <div className="grid grid-cols-1 gap-3">
                  {products.map(p => <ProductCard key={p.id} product={p} />)}
                </div>
              )}
            </div>
          )}

          {/* AI 对话框（报告生成完成后显示） */}
          {done && (
            <div className="card p-5 space-y-4">
              <div className="flex items-center gap-2">
                <Bot size={18} className="text-accent" />
                <span className="font-semibold text-sm">AI 规划顾问对话</span>
                <span className="text-xs text-text-muted">基于本次报告数据回答您的问题</span>
              </div>

              {/* 对话历史 */}
              {chatMessages.length > 0 && (
                <div className="max-h-64 overflow-y-auto space-y-3 py-2">
                  {chatMessages.map((msg, i) => (
                    <div key={i} className={`flex gap-2 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      {msg.role === 'assistant' && <Bot size={16} className="text-accent shrink-0 mt-1" />}
                      <div className={`max-w-[80%] rounded-lg px-3 py-2 text-sm ${
                        msg.role === 'user'
                          ? 'bg-accent/20 text-text-primary'
                          : 'bg-bg-float text-text-secondary'
                      }`}>
                        {msg.content || (chatLoading && i === chatMessages.length - 1
                          ? <span className="inline-block w-4 h-3 bg-accent/50 rounded animate-pulse" />
                          : '...')}
                      </div>
                      {msg.role === 'user' && <User size={16} className="text-text-muted shrink-0 mt-1" />}
                    </div>
                  ))}
                  <div ref={chatEndRef} />
                </div>
              )}

              {/* 输入框 */}
              <div className="flex gap-2">
                <input
                  type="text"
                  value={chatInput}
                  onChange={e => setChatInput(e.target.value)}
                  onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); handleChat() } }}
                  placeholder="输入您的问题，如：我的养老缺口如何补足？"
                  className="input flex-1 text-sm"
                  disabled={chatLoading}
                />
                <button
                  onClick={handleChat}
                  disabled={!chatInput.trim() || chatLoading}
                  className="btn-primary px-4 py-2 disabled:opacity-50"
                >
                  {chatLoading ? <RefreshCw size={16} className="animate-spin" /> : <Send size={16} />}
                </button>
              </div>
            </div>
          )}
        </>
      )}

      <div className="flex justify-between pt-2">
        <button onClick={() => setActiveModule(5)} className="btn-secondary px-6 py-2.5">上一步</button>
      </div>
    </div>
  )
}
