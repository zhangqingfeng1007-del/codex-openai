/**
 * 模块三：子女教育成本测算 — V1.0 完整实现
 * 4.1 快速路径选择 + 4.3 学历费用配置 + 4.4 兴趣培养 + 4.5 通胀计算 + 4.6 展示
 */
import { useState, useEffect } from 'react'
import { ChevronDown, ChevronUp, Edit3, Check } from 'lucide-react'
import { useStore } from '../../store/useStore'
// calcEducationCost API not used; cost computed client-side
import EducationChart from '../../components/charts/EducationChart'
import type { ChildInfo, EducationPath, ChildEducationPlan, EducationPlanResult, InterestCategory } from '../../types'

// ======= 常量配置 =======
const PATH_OPTIONS: { value: EducationPath; label: string; desc: string; tag: string; color: string }[] = [
  { value: 'A', label: '稳健公立路线',       desc: '全程国内公立，高考导向', tag: '经济稳健', color: 'border-accent-success bg-accent-success/10 text-accent-success' },
  { value: 'B', label: '精英公立+出国深造',  desc: '公立K12，研究生出国', tag: '高性价比国际化', color: 'border-accent bg-accent/10 text-accent' },
  { value: 'C', label: '私立精英+高考冲刺',  desc: '私立K12，国内大学+出国研究生', tag: '国内精英', color: 'border-accent-warning bg-accent-warning/10 text-accent-warning' },
  { value: 'D', label: '国内私立+本科出国',  desc: '私立K12，海外本科研究生', tag: '高净值主流', color: 'border-purple-500 bg-purple-500/10 text-purple-400' },
]

const STAGE_LABELS: Record<string, string> = {
  preschool: '幼儿园', primary: '小学', junior: '初中', senior: '高中', university: '本科', graduate: '研究生'
}
const SCHOOL_TYPE_LABELS: Record<string, string> = {
  public: '公立', private: '私立', private_top: '顶私', domestic_public: '国内双一流', overseas_us: '境外（默认美国）'
}

const INTEREST_LABELS: Record<string, { label: string; desc: string }> = {
  sports:   { label: '体育类',   desc: '游泳、篮球、足球、网球、乒乓球、高尔夫' },
  arts:     { label: '艺术类',   desc: '钢琴、小提琴、美术、舞蹈、声乐' },
  academic: { label: '学科竞赛', desc: '数学奥赛、编程、机器人竞赛' },
  language: { label: '语言类',   desc: '英语外教、小语种、托福/雅思备考' },
  travel:   { label: '国际游学', desc: '短期游学营（1-4周）' },
  tech:     { label: '科技兴趣', desc: 'Python编程、Scratch编程' },
  tutoring: { label: '校外辅导', desc: '数学辅导、语文辅导、英语辅导' },
}

const INTEREST_UNTIL_OPTIONS = [
  { value: 'primary',  label: '到小学' },
  { value: 'junior',   label: '到初中' },
  { value: 'senior',   label: '到高中' },
  { value: 'university', label: '到大学' },
]

// 路径默认勾选兴趣
const PATH_INTERESTS: Record<EducationPath, string[]> = {
  A: ['sports', 'tutoring'],
  B: ['sports', 'arts', 'language', 'travel', 'tutoring'],
  C: ['sports', 'arts', 'academic', 'tech', 'tutoring'],
  D: ['sports', 'arts', 'language', 'travel'],
}

// 默认兴趣年费（一线城市基准）
const INTEREST_DEFAULT_COST: Record<string, number> = {
  sports: 15000, arts: 20000, academic: 25000, language: 18000, travel: 30000, tech: 15000, tutoring: 24000
}
const INTEREST_DEFAULT_UNTIL: Record<string, string> = {
  sports: 'senior', arts: 'junior', academic: 'senior', language: 'university', travel: 'senior', tech: 'senior', tutoring: 'senior'
}

// 路径阶段映射
const PATH_STAGES: Record<EducationPath, Record<string, string>> = {
  A: { preschool:'public', primary:'public', junior:'public', senior:'public', university:'domestic_public', graduate:'domestic_public' },
  B: { preschool:'public', primary:'public', junior:'public', senior:'public', university:'domestic_public', graduate:'overseas_us' },
  C: { preschool:'private', primary:'private', junior:'private', senior:'private_top', university:'domestic_public', graduate:'overseas_us' },
  D: { preschool:'private', primary:'private', junior:'private', senior:'private_top', university:'overseas_us', graduate:'overseas_us' },
}

const STAGE_ORDER = ['preschool', 'primary', 'junior', 'senior', 'university', 'graduate']
const STAGE_START_AGE: Record<string, number> = { preschool:3, primary:6, junior:12, senior:15, university:18, graduate:22 }
const STAGE_DUR: Record<string, number> = { preschool:3, primary:6, junior:3, senior:3, university:4, graduate:3 }

// 一线城市基准年费
const BASE_ANNUAL_COST: Record<string, Record<string, number>> = {
  preschool:  { public: 20000, private: 60000 },
  primary:    { public: 5000,  private: 80000 },
  junior:     { public: 5000,  private: 100000 },
  senior:     { public: 10000, private: 120000, private_top: 180000 },
  university: { domestic_public: 30000, overseas_us: 400000 },
  graduate:   { domestic_public: 25000, overseas_us: 450000 },
}

function formatWan(num: number) {
  if (num >= 10000) return (num / 10000).toFixed(1) + ' 万'
  return num.toLocaleString() + ' 元'
}

// PMT公式
function pmtCalc(fv: number, rateAnnual: number, months: number): number {
  if (months <= 0 || fv <= 0) return 0
  const r = rateAnnual / 12
  if (r === 0) return fv / months
  return fv * r / (Math.pow(1 + r, months) - 1)
}

// 每个兴趣项配置
interface InterestConfig {
  category: string
  enabled: boolean
  annualCost: number
  untilStage: string
}

// 每个子女配置
interface ChildConfig {
  pathSelection: EducationPath
  interests: InterestConfig[]
  stageCostOverrides: Record<string, number>  // stage → annual cost override
}

function defaultConfig(path: EducationPath): ChildConfig {
  const interests: InterestConfig[] = Object.keys(INTEREST_LABELS).map(cat => ({
    category: cat,
    enabled: PATH_INTERESTS[path].includes(cat),
    annualCost: INTEREST_DEFAULT_COST[cat],
    untilStage: INTEREST_DEFAULT_UNTIL[cat],
  }))
  return { pathSelection: path, interests, stageCostOverrides: {} }
}

// 本地计算教育成本（用于实时预览）
function calcLocalCost(child: ChildInfo, config: ChildConfig, tierMult: number, inflRate: number, returnRate: number) {
  const stages = STAGE_ORDER.map(stage => {
    const startAge = STAGE_START_AGE[stage]
    const dur = STAGE_DUR[stage]
    const alreadyDone = Math.max(0, child.age - startAge)
    if (alreadyDone >= dur) return null
    const remaining = dur - Math.max(0, alreadyDone)
    const schoolType = PATH_STAGES[config.pathSelection][stage] || 'public'
    const baseAnnual = BASE_ANNUAL_COST[stage]?.[schoolType] ?? BASE_ANNUAL_COST[stage]?.['public'] ?? 0
    const annualCost = config.stageCostOverrides[stage] ?? (baseAnnual * tierMult)
    const yearsUntilStart = Math.max(0, startAge - child.age)
    const startYear = new Date().getFullYear() + yearsUntilStart
    let totalCost = 0
    for (let y = 0; y < remaining; y++) {
      totalCost += annualCost * Math.pow(1 + inflRate, yearsUntilStart + y)
    }
    return { stage, schoolType, remainingYears: remaining, annualCost, totalCost, startYear }
  }).filter(Boolean) as Array<{ stage: string; schoolType: string; remainingYears: number; annualCost: number; totalCost: number; startYear: number }>

  const academicTotal = stages.reduce((s, st) => s + st.totalCost, 0)

  const interests = config.interests.filter(i => i.enabled).map(i => {
    const untilAge = STAGE_START_AGE[i.untilStage] + STAGE_DUR[i.untilStage]
    const remainYrs = Math.max(0, untilAge - child.age)
    let totalCost = 0
    for (let y = 0; y < remainYrs; y++) totalCost += i.annualCost * Math.pow(1 + inflRate, y)
    return { category: i.category as InterestCategory, annualCost: i.annualCost, untilStage: i.untilStage, totalCost }
  })

  const interestTotal = interests.reduce((s, i) => s + i.totalCost, 0)
  const totalCost = academicTotal + interestTotal
  const univEndAge = 22
  const monthsToSave = Math.max(1, (univEndAge - child.age) * 12)

  return {
    stages, interests, academicTotal, interestTotal, totalCost,
    monthlyConservative: pmtCalc(totalCost, returnRate, monthsToSave),
    monthlyAggressive: pmtCalc(totalCost, returnRate + 0.02, monthsToSave),
  }
}

// 子女卡片组件
function ChildCard({
  child, idx, config, tierMult, inflRate, returnRate,
  onConfigChange,
}: {
  child: ChildInfo
  idx: number
  config: ChildConfig
  tierMult: number
  inflRate: number
  returnRate: number
  onConfigChange: (cfg: ChildConfig) => void
}) {
  const [expanded, setExpanded] = useState(true)
  const [editingStage, setEditingStage] = useState<string | null>(null)
  const [tempCost, setTempCost] = useState<string>('')
  const [pendingPath, setPendingPath] = useState<EducationPath | null>(null)
  const preview = calcLocalCost(child, config, tierMult, inflRate, returnRate)
  const currentPath = PATH_OPTIONS.find(p => p.value === config.pathSelection)!

  // 检测用户是否手动修改过配置（dirty check）
  const isDirty = (() => {
    if (Object.keys(config.stageCostOverrides).length > 0) return true
    const defaults = defaultConfig(config.pathSelection)
    return config.interests.some((i, idx) => {
      const d = defaults.interests[idx]
      return i.enabled !== d.enabled || i.annualCost !== d.annualCost || i.untilStage !== d.untilStage
    })
  })()

  const handlePathChange = (path: EducationPath) => {
    if (path === config.pathSelection) return
    if (isDirty) {
      setPendingPath(path)
      return
    }
    onConfigChange({ ...defaultConfig(path), stageCostOverrides: {} })
  }

  const confirmPathSwitch = () => {
    if (pendingPath) {
      onConfigChange({ ...defaultConfig(pendingPath), stageCostOverrides: {} })
      setPendingPath(null)
    }
  }

  const handleInterestToggle = (cat: string) => {
    const interests = config.interests.map(i => i.category === cat ? { ...i, enabled: !i.enabled } : i)
    onConfigChange({ ...config, interests })
  }

  const handleInterestCost = (cat: string, val: number) => {
    const interests = config.interests.map(i => i.category === cat ? { ...i, annualCost: val } : i)
    onConfigChange({ ...config, interests })
  }

  const handleInterestUntil = (cat: string, val: string) => {
    const interests = config.interests.map(i => i.category === cat ? { ...i, untilStage: val } : i)
    onConfigChange({ ...config, interests })
  }

  const handleStageCostEdit = (stage: string) => {
    setEditingStage(stage)
    const existing = config.stageCostOverrides[stage]
    const defaultVal = preview.stages.find(s => s.stage === stage)?.annualCost ?? 0
    setTempCost(String(Math.round(existing ?? defaultVal)))
  }

  const handleStageCostSave = (stage: string) => {
    const val = Number(tempCost)
    if (!isNaN(val) && val >= 0) {
      onConfigChange({ ...config, stageCostOverrides: { ...config.stageCostOverrides, [stage]: val } })
    }
    setEditingStage(null)
  }

  return (
    <div className="card overflow-hidden">
      {/* 卡片头部 */}
      <button className="w-full flex items-center justify-between px-5 py-4 text-left" onClick={() => setExpanded(v => !v)}>
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center text-accent text-sm font-semibold">{child.age}</div>
          <div>
            <span className="font-semibold text-sm">{child.gender === 'female' ? '女儿' : '儿子'} {idx + 1}（{child.age}岁）</span>
            <span className={`ml-2 text-xs px-2 py-0.5 rounded-full ${currentPath.color}`}>{currentPath.label}</span>
          </div>
        </div>
        <div className="flex items-center gap-3">
          <span className="text-accent font-semibold text-sm">{formatWan(preview.totalCost)}</span>
          {expanded ? <ChevronUp size={16} className="text-text-muted" /> : <ChevronDown size={16} className="text-text-muted" />}
        </div>
      </button>

      {expanded && (
        <div className="border-t border-bg-border px-5 pb-5 space-y-5 pt-4">
          {/* 4.1 路径选择 */}
          <div>
            <div className="text-xs text-text-muted mb-2 font-medium">教育路径（4.1）</div>
            <div className="grid grid-cols-2 gap-2">
              {PATH_OPTIONS.map(opt => (
                <button key={opt.value} onClick={() => handlePathChange(opt.value)}
                  className={`flex items-center justify-between px-3 py-2.5 rounded-lg border text-left transition-all text-sm ${
                    config.pathSelection === opt.value ? opt.color + ' border-2 font-medium' : 'border-bg-border text-text-secondary hover:border-accent/40'
                  }`}>
                  <div>
                    <div className="font-medium text-xs">{opt.label}</div>
                    <div className="text-xs text-text-muted mt-0.5">{opt.desc}</div>
                  </div>
                  <span className={`text-xs px-1.5 py-0.5 rounded ml-2 shrink-0 ${config.pathSelection === opt.value ? 'bg-white/20' : 'bg-bg-float text-text-muted'}`}>{opt.tag}</span>
                </button>
              ))}
            </div>
            {/* 路径切换确认弹框 */}
            {pendingPath && (
              <div className="mt-2 bg-accent-warning/10 border border-accent-warning/30 rounded-lg p-3 flex items-center justify-between gap-3">
                <p className="text-xs text-text-secondary">
                  您已修改过当前路径的费用/兴趣配置，切换到「{PATH_OPTIONS.find(p => p.value === pendingPath)?.label}」将重置所有自定义设置。
                </p>
                <div className="flex gap-2 shrink-0">
                  <button onClick={() => setPendingPath(null)} className="btn-secondary text-xs px-3 py-1">取消</button>
                  <button onClick={confirmPathSwitch} className="bg-accent-warning text-white text-xs px-3 py-1 rounded-full font-medium hover:opacity-90 transition-opacity">确认切换</button>
                </div>
              </div>
            )}
          </div>

          {/* 4.3 学历教育费用明细 */}
          <div>
            <div className="text-xs text-text-muted mb-2 font-medium">学历教育费用（4.3）<span className="text-text-placeholder ml-1">—— 点击年费可修改</span></div>
            <div className="overflow-x-auto">
              <table className="w-full text-xs">
                <thead>
                  <tr className="text-text-muted border-b border-bg-border">
                    <th className="text-left py-2 pr-3 font-medium">阶段</th>
                    <th className="text-left py-2 pr-3 font-medium">类型</th>
                    <th className="text-right py-2 pr-3 font-medium">剩余年</th>
                    <th className="text-right py-2 pr-3 font-medium">年费（可改）</th>
                    <th className="text-right py-2 font-medium">阶段合计</th>
                  </tr>
                </thead>
                <tbody>
                  {preview.stages.map(s => (
                    <tr key={s.stage} className="border-b border-bg-border/40">
                      <td className="py-2 pr-3 text-text-primary font-medium">{STAGE_LABELS[s.stage]}</td>
                      <td className="py-2 pr-3">
                        <span className={`px-1.5 py-0.5 rounded text-xs ${
                          s.schoolType.includes('overseas') ? 'bg-accent-warning/20 text-accent-warning'
                            : s.schoolType.includes('private') ? 'bg-accent/20 text-accent'
                            : 'bg-bg-float text-text-muted'
                        }`}>{SCHOOL_TYPE_LABELS[s.schoolType] ?? s.schoolType}</span>
                      </td>
                      <td className="py-2 pr-3 text-right text-text-secondary">{s.remainingYears}年</td>
                      <td className="py-2 pr-3 text-right">
                        {editingStage === s.stage ? (
                          <div className="flex items-center justify-end gap-1">
                            <input type="number" value={tempCost} onChange={e => setTempCost(e.target.value)}
                              className="input w-24 py-0.5 text-right text-xs" autoFocus
                              onKeyDown={e => { if (e.key === 'Enter') handleStageCostSave(s.stage); if (e.key === 'Escape') setEditingStage(null) }} />
                            <button onClick={() => handleStageCostSave(s.stage)} className="text-accent-success"><Check size={14} /></button>
                          </div>
                        ) : (
                          <button onClick={() => handleStageCostEdit(s.stage)}
                            className={`flex items-center gap-1 justify-end text-right hover:text-accent ${config.stageCostOverrides[s.stage] !== undefined ? 'text-accent font-medium' : 'text-text-secondary'}`}>
                            {formatWan(s.annualCost)}<Edit3 size={10} className="opacity-50" />
                          </button>
                        )}
                      </td>
                      <td className="py-2 text-right font-medium text-text-primary">{formatWan(s.totalCost)}</td>
                    </tr>
                  ))}
                </tbody>
                <tfoot>
                  <tr className="border-t border-bg-border">
                    <td colSpan={4} className="pt-2 text-sm text-text-secondary font-medium">学业小计（含4.5通胀）</td>
                    <td className="pt-2 text-right text-accent font-semibold text-sm">{formatWan(preview.academicTotal)}</td>
                  </tr>
                </tfoot>
              </table>
            </div>
          </div>

          {/* 4.4 兴趣培养 */}
          <div>
            <div className="text-xs text-text-muted mb-2 font-medium">兴趣培养（4.4）</div>
            <div className="space-y-2">
              {config.interests.map(interest => {
                const meta = INTEREST_LABELS[interest.category]
                return (
                  <div key={interest.category} className={`rounded-lg p-3 border transition-all ${interest.enabled ? 'border-accent/40 bg-accent/5' : 'border-bg-border bg-bg-float opacity-60'}`}>
                    <div className="flex items-center justify-between gap-2">
                      <label className="flex items-center gap-2 cursor-pointer flex-1">
                        <input type="checkbox" checked={interest.enabled} onChange={() => handleInterestToggle(interest.category)}
                          className="w-4 h-4 rounded accent-[var(--accent)]" />
                        <div>
                          <span className="text-sm font-medium">{meta.label}</span>
                          <span className="text-xs text-text-muted ml-2">{meta.desc}</span>
                        </div>
                      </label>
                    </div>
                    {interest.enabled && (
                      <div className="mt-2 grid grid-cols-2 gap-2 pl-6">
                        <div className="flex items-center gap-1 text-xs">
                          <span className="text-text-muted shrink-0">年费：</span>
                          <input type="number" value={interest.annualCost}
                            onChange={e => handleInterestCost(interest.category, Number(e.target.value))}
                            className="input py-1 text-xs w-full" min={0} />
                          <span className="text-text-muted shrink-0">元</span>
                        </div>
                        <div className="flex items-center gap-1 text-xs">
                          <span className="text-text-muted shrink-0 w-16">持续到：</span>
                          <select value={interest.untilStage}
                            onChange={e => handleInterestUntil(interest.category, e.target.value)}
                            className="input py-1 text-xs w-full">
                            {INTEREST_UNTIL_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
                          </select>
                        </div>
                      </div>
                    )}
                  </div>
                )
              })}
            </div>
            {preview.interests.length > 0 && (
              <div className="flex justify-between text-xs text-text-secondary mt-2 pt-2 border-t border-bg-border/50">
                <span className="font-medium">兴趣培养小计（含4.5通胀）</span>
                <span className="text-accent-warning font-semibold">{formatWan(preview.interestTotal)}</span>
              </div>
            )}
          </div>

          {/* 4.6 储蓄目标 */}
          <div className="bg-bg-float rounded-lg p-4 space-y-3">
            <div className="flex justify-between text-sm font-semibold">
              <span>教育总费用（含通胀）</span>
              <span className="text-accent text-base">{formatWan(preview.totalCost)}</span>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="text-center bg-accent-success/10 rounded-lg p-3">
                <div className="text-xs text-text-muted mb-1">保守储蓄方案（年化{(returnRate * 100).toFixed(0)}%）</div>
                <div className="font-bold text-accent-success">{formatWan(preview.monthlyConservative)}<span className="text-xs font-normal text-text-muted">/月</span></div>
              </div>
              <div className="text-center bg-accent-warning/10 rounded-lg p-3">
                <div className="text-xs text-text-muted mb-1">积极储蓄方案（年化{((returnRate + 0.02) * 100).toFixed(0)}%）</div>
                <div className="font-bold text-accent-warning">{formatWan(preview.monthlyAggressive)}<span className="text-xs font-normal text-text-muted">/月</span></div>
              </div>
            </div>
            <p className="text-xs text-text-muted">* 教育通胀率{(inflRate * 100).toFixed(1)}%（随情景参数）；储蓄计算至22岁大学结束</p>
          </div>
        </div>
      )}
    </div>
  )
}

export default function Module3() {
  const { customer, scenarioParams, setEducationResult, setActiveModule } = useStore()
  const inflRate = scenarioParams.inflationRate
  const returnRate = scenarioParams.returnRate
  const children = customer?.children || []

  // 城市tier（用于费用系数）
  const [tierMult, setTierMult] = useState(1.0)
  const [configs, setConfigs] = useState<Record<string, ChildConfig>>(() => {
    const init: Record<string, ChildConfig> = {}
    children.forEach(c => { init[c.id] = defaultConfig(c.educationPath ?? 'A') })
    return init
  })
  const [saving, setSaving] = useState(false)
  const [saved, setSaved] = useState(false)

  // 从后端获取城市tier系数
  useEffect(() => {
    if (!customer?.cityWork) return
    // tier从城市名推断
    const tierMap: Record<string, number> = {
      beijing:1, shanghai:1, guangzhou:1, shenzhen:1,
      chengdu:2, hangzhou:2, chongqing:2, wuhan:2, xian:2, suzhou:2, nanjing:2, tianjin:2,
      changsha:2, zhengzhou:2, qingdao:2, jinan:2, hefei:2, ningbo:2, dongguan:2, foshan:2, wuxi:2, shenyang:2, dalian:2, kunming:2, xiamen:2, fuzhou:2,
    }
    const t = tierMap[customer.cityWork] ?? 3
    setTierMult(t === 1 ? 1.0 : t === 2 ? 0.75 : 0.55)
  }, [customer?.cityWork])

  // 汇总所有子女数据
  const familySummary = (() => {
    let familyAcademic = 0, familyInterest = 0, conservativeSum = 0, aggressiveSum = 0
    children.forEach(child => {
      const cfg = configs[child.id] || defaultConfig('A')
      const preview = calcLocalCost(child, cfg, tierMult, inflRate, returnRate)
      familyAcademic += preview.academicTotal
      familyInterest += preview.interestTotal
      conservativeSum += preview.monthlyConservative
      aggressiveSum += preview.monthlyAggressive
    })
    return { familyAcademic, familyInterest, familyTotal: familyAcademic + familyInterest, conservativeSum, aggressiveSum }
  })()

  async function handleSaveToStore() {
    setSaving(true)
    try {
      // 将本地计算结果保存到store（也可调用后端API）
      const childPlans: ChildEducationPlan[] = children.map(child => {
        const cfg = configs[child.id] || defaultConfig('A')
        const preview = calcLocalCost(child, cfg, tierMult, inflRate, returnRate)
        return {
          childId: child.id,
          educationPath: cfg.pathSelection,
          stages: preview.stages,
          interests: preview.interests,
          academicTotal: preview.academicTotal,
          interestTotal: preview.interestTotal,
          totalCost: preview.totalCost,
          monthlyTargetConservative: preview.monthlyConservative,
          monthlyTargetAggressive: preview.monthlyAggressive,
        }
      })
      const result: EducationPlanResult = {
        children: childPlans,
        familyAcademicTotal: familySummary.familyAcademic,
        familyInterestTotal: familySummary.familyInterest,
        familyTotal: familySummary.familyTotal,
        monthlyTargetConservative: familySummary.conservativeSum,
        monthlyTargetAggressive: familySummary.aggressiveSum,
      }
      setEducationResult(result)
      setSaved(true)
      setTimeout(() => setSaved(false), 2000)
    } finally {
      setSaving(false)
    }
  }

  if (children.length === 0) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold">子女教育成本测算</h1>
          <p className="text-text-secondary text-sm mt-1">为每位子女规划教育路径，估算未来教育总费用</p>
        </div>
        <div className="card p-10 text-center space-y-3">
          <div className="text-3xl">🎓</div>
          <p className="text-text-secondary">模块一未录入子女信息</p>
          <p className="text-text-muted text-sm">如有子女教育规划需求，请返回模块一补充子女信息</p>
        </div>
        <div className="flex justify-between pt-2">
          <button onClick={() => setActiveModule(3)} className="btn-secondary px-6 py-2.5">上一步</button>
          <button onClick={() => setActiveModule(4)} className="btn-primary px-8 py-2.5">下一步：保障需求</button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">子女教育成本测算</h1>
        <p className="text-text-secondary text-sm mt-1">选择教育路径，配置学历费用和兴趣培养，实时查看含通胀的教育总成本</p>
      </div>

      {/* 4.6 每位子女独立卡片（展开/收起） */}
      {children.map((child, idx) => (
        <ChildCard
          key={child.id}
          child={child}
          idx={idx}
          config={configs[child.id] || defaultConfig('A')}
          tierMult={tierMult}
          inflRate={inflRate}
          returnRate={returnRate}
          onConfigChange={cfg => setConfigs(prev => ({ ...prev, [child.id]: cfg }))}
        />
      ))}

      {/* 4.6 家庭教育总成本汇总 */}
      {children.length > 0 && (
        <div className="card p-5 space-y-4">
          <h3 className="font-semibold">家庭教育总成本汇总（4.6）</h3>

          {/* §9.6 教育费用时间轴图 */}
          <EducationChart
            children={children.map(child => {
              const cfg = configs[child.id] || defaultConfig('A')
              const preview = calcLocalCost(child, cfg, tierMult, inflRate, returnRate)
              return {
                childId: child.id,
                educationPath: cfg.pathSelection,
                stages: preview.stages,
                interests: preview.interests,
                academicTotal: preview.academicTotal,
                interestTotal: preview.interestTotal,
                totalCost: preview.totalCost,
                monthlyTargetConservative: preview.monthlyConservative,
                monthlyTargetAggressive: preview.monthlyAggressive,
              } as ChildEducationPlan
            })}
          />

          <div className="grid grid-cols-2 gap-3">
            <div className="bg-bg-float rounded-lg p-3 text-center">
              <div className="text-xs text-text-muted mb-1">学业教育合计</div>
              <div className="text-lg font-bold">{formatWan(familySummary.familyAcademic)}</div>
            </div>
            <div className="bg-bg-float rounded-lg p-3 text-center">
              <div className="text-xs text-text-muted mb-1">兴趣培养合计</div>
              <div className="text-lg font-bold text-accent-warning">{formatWan(familySummary.familyInterest)}</div>
            </div>
            <div className="bg-accent/10 border border-accent/30 rounded-lg p-4 text-center col-span-2">
              <div className="text-xs text-text-muted mb-1">家庭教育总费用（含通胀）</div>
              <div className="text-2xl font-bold text-accent">{formatWan(familySummary.familyTotal)}</div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="bg-accent-success/10 rounded-lg p-3 text-center">
              <div className="text-xs text-text-muted mb-1">保守月储蓄目标（{(returnRate * 100).toFixed(0)}%）</div>
              <div className="font-bold text-accent-success">{formatWan(familySummary.conservativeSum)}<span className="text-xs font-normal text-text-muted">/月</span></div>
            </div>
            <div className="bg-accent-warning/10 rounded-lg p-3 text-center">
              <div className="text-xs text-text-muted mb-1">积极月储蓄目标（{((returnRate + 0.02) * 100).toFixed(0)}%）</div>
              <div className="font-bold text-accent-warning">{formatWan(familySummary.aggressiveSum)}<span className="text-xs font-normal text-text-muted">/月</span></div>
            </div>
          </div>
          <button onClick={handleSaveToStore} disabled={saving}
            className={`w-full py-2.5 rounded-lg font-medium text-sm transition-all ${saved ? 'bg-accent-success/20 text-accent-success' : 'btn-primary'}`}>
            {saved ? '✓ 已保存教育规划数据' : saving ? '保存中...' : '保存教育规划（进入下一步前须保存）'}
          </button>
        </div>
      )}

      <div className="flex justify-between pt-2">
        <button onClick={() => setActiveModule(3)} className="btn-secondary px-6 py-2.5">上一步</button>
        <div className="flex items-center gap-3">
          {children.length > 0 && !saved && (
            <span className="text-accent-warning text-xs">请先保存教育规划</span>
          )}
          <button
            onClick={() => setActiveModule(4)}
            disabled={children.length > 0 && !saved}
            className="btn-primary px-8 py-2.5 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            下一步：保障需求
          </button>
        </div>
      </div>
    </div>
  )
}
