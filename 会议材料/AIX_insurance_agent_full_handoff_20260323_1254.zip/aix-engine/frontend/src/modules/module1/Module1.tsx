/**
 * 模块一：客户基本信息录入 — V1.0
 * 注：健康状况 → 模块四录入；退休城市 → 模块四录入（文档1.3/5.1）
 */
import { useState, useEffect } from 'react'
import { motion, AnimatePresence } from 'framer-motion'
import { Plus, Trash2, User, Users, ChevronDown, ChevronUp, Info } from 'lucide-react'
import { v4 as uuidv4 } from 'uuid'
import { useStore } from '../../store/useStore'
import { RadioGroup, NumberInput, CitySelect } from '../../components/FormField'
import { fetchCities, calcRetirementAge } from '../../api/client'
import type { Gender, FemaleIdentityType, SocialSecurityType, CityOption, ChildInfo, SpouseInfo } from '../../types'

const GENDER_OPTIONS: Array<{ value: Gender; label: string }> = [
  { value: 'male', label: '男' },
  { value: 'female', label: '女' },
]
const SS_TYPE_OPTIONS: Array<{ value: SocialSecurityType; label: string }> = [
  { value: 'employee', label: '职工' },
  { value: 'civil_servant', label: '机关事业' },
  { value: 'resident', label: '城乡居民' },
  { value: 'none', label: '无' },
]
const FEMALE_IDENTITY_OPTIONS: Array<{ value: FemaleIdentityType; label: string }> = [
  { value: 'cadre', label: '女干部（管理/技术岗）' },
  { value: 'worker', label: '女工人（生产操作岗）' },
]

const currentYear = new Date().getFullYear()

function spousePatch(prev: Partial<SpouseInfo> | undefined, patch: Partial<SpouseInfo>): SpouseInfo {
  return { cityWork: '', socialSecurityType: 'employee', yearsPaid: 0, monthlyIncome: 0, age: 35, gender: 'female', isSameCity: true, ...(prev || {}), ...patch } as SpouseInfo
}

export default function Module1() {
  const { customer, updateCustomer, addChild, removeChild, setActiveModule } = useStore()
  const [cities, setCities] = useState<CityOption[]>([])
  const [legalRetirementAge, setLegalRetirementAge] = useState<number | null>(null)
  const [spouseLegalAge, setSpouseLegalAge] = useState<number | null>(null)
  const [errors, setErrors] = useState<Record<string, string>>({})

  const c = customer || {}
  const customerName = (c.name as string) || ''
  const birthYear = c.birthYear as number | undefined
  const age = c.age as number | undefined
  const gender = (c.gender as Gender) || 'male'
  const femaleIdentityType = c.femaleIdentityType as FemaleIdentityType | undefined
  const cityWork = (c.cityWork as string) || ''
  const cityRetire = (c.cityRetire as string) || ''
  const ssType = (c.socialSecurityType as SocialSecurityType) || 'employee'

  // 确保 UI 默认值同步到 store（性别、社保类型）
  useEffect(() => {
    const patch: Record<string, unknown> = {}
    if (!c.gender) patch.gender = 'male'
    if (!c.socialSecurityType) patch.socialSecurityType = 'employee'
    if (Object.keys(patch).length > 0) updateCustomer(patch)
  }, []) // eslint-disable-line react-hooks/exhaustive-deps
  const monthlyIncome = c.monthlyIncome as number | undefined
  const ssContributionBase = c.ssContributionBase as number | undefined
  const yearsPaid = c.yearsPaid as number | undefined
  const workStartYear = c.workStartYear as number | undefined
  const hasSpouse = Boolean(c.hasSpouse)
  const children = (c.children as ChildInfo[]) || []
  const sp = c.spouse as SpouseInfo | undefined

  useEffect(() => {
    fetchCities().then(setCities).catch(console.error)
  }, [])

  // 主填写人法定退休年龄
  useEffect(() => {
    if (!age || !gender) return
    if (age < 18 || age > 80) return
    calcRetirementAge({ age, gender, femaleIdentityType, socialSecurityType: ssType })
      .then(data => setLegalRetirementAge(data.legalRetirementAge))
      .catch(() => setLegalRetirementAge(null))
  }, [age, gender, femaleIdentityType, ssType])

  // 配偶法定退休年龄
  useEffect(() => {
    if (!sp?.age || !sp?.gender) return
    calcRetirementAge({ age: sp.age, gender: sp.gender, femaleIdentityType: sp.femaleIdentityType, socialSecurityType: sp.socialSecurityType || 'employee' })
      .then(data => setSpouseLegalAge(data.legalRetirementAge))
      .catch(() => setSpouseLegalAge(null))
  }, [sp?.age, sp?.gender, sp?.femaleIdentityType, sp?.socialSecurityType])

  // 实时校验：字段变化时更新对应错误
  useEffect(() => {
    setErrors(prev => {
      const e = { ...prev }
      // 年龄
      if (age !== undefined) {
        if (age < 18 || age > 80) e.age = '年龄应在18~80岁之间'
        else delete e.age
      }
      // 城市
      if (cityWork) delete e.cityWork
      // 月收入
      if (monthlyIncome !== undefined && monthlyIncome > 0) delete e.monthlyIncome
      // 社保年数
      if (yearsPaid !== undefined && yearsPaid !== null) {
        if (age && yearsPaid > age - 16) e.yearsPaid = `缴费年数不能超过${age - 16}年（${age}岁-16岁）`
        else delete e.yearsPaid
      }
      return e
    })
  }, [age, cityWork, monthlyIncome, yearsPaid])

  function validate(): boolean {
    const e: Record<string, string> = {}
    if (!age) e.age = '请输入年龄'
    else if (age < 18 || age > 80) e.age = '年龄应在18~80岁之间'
    if (!cityWork) e.cityWork = '请选择工作城市'
    if (!monthlyIncome || monthlyIncome <= 0) e.monthlyIncome = '请输入月收入'
    if (yearsPaid === undefined || yearsPaid === null) e.yearsPaid = '请输入已缴社保年数'
    else if (age && yearsPaid > age - 16) e.yearsPaid = `缴费年数不能超过${age - 16}年`
    setErrors(e)
    return Object.keys(e).length === 0
  }

  function handleNext() {
    if (!validate()) return
    setActiveModule(2)
  }

  function handleAddChild() {
    if (children.length >= 5) return
    addChild({ id: uuidv4(), birthYear: currentYear - 8, age: 8, gender: 'male' })
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold text-text-primary">客户基本信息</h1>
        <p className="text-text-secondary text-sm mt-1">填写基本信息，系统自动计算法定退休年龄。健康状况和退休城市在模块四填写。</p>
      </div>

      {/* ===== 客户本人 ===== */}
      <div className="card-accent p-6 space-y-5">
        <div className="flex items-center gap-2 mb-2">
          <User size={18} className="text-accent" />
          <h2 className="text-base font-semibold">客户本人</h2>
        </div>

        <div className="grid grid-cols-2 gap-4">
          <div className="col-span-2">
            <label className="field-label">姓名<span className="text-text-muted ml-1 font-normal">（可选，用于报告命名）</span></label>
            <input
              type="text"
              value={customerName}
              onChange={e => updateCustomer({ name: e.target.value })}
              placeholder="如：张先生"
              className="input w-full"
            />
          </div>
          <NumberInput
            label="出生年份"
            value={birthYear}
            onChange={v => {
              updateCustomer({ birthYear: v, age: v ? currentYear - v : undefined })
            }}
            min={1940} max={currentYear - 18} placeholder={`如：${currentYear - 35}`} required
            hint="用于精确计算退休年份"
          />
          <RadioGroup label="性别" value={gender} options={GENDER_OPTIONS}
            onChange={v => updateCustomer({ gender: v, femaleIdentityType: undefined })} required />
        </div>

        <div className="grid grid-cols-2 gap-4">
          <NumberInput
            label="当前年龄"
            value={age}
            onChange={v => updateCustomer({ age: v, birthYear: v ? currentYear - v : undefined })}
            unit="岁" min={18} max={80} placeholder="如：35" required error={errors.age}
          />
        </div>

        <AnimatePresence>
          {gender === 'female' && ssType === 'employee' && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden">
              <RadioGroup label="女性身份类型" value={femaleIdentityType || 'worker'}
                options={FEMALE_IDENTITY_OPTIONS}
                onChange={v => updateCustomer({ femaleIdentityType: v })} required
                hint="影响延迟退休曲线：女干部法定退休年龄高于女工人" />
            </motion.div>
          )}
        </AnimatePresence>

        <CitySelect label="工作城市" value={cityWork}
          onChange={v => updateCustomer({ cityWork: v, cityRetire: c.cityRetire || v })}
          cities={cities} required hint="影响社保基数上下限及教育费用默认值"
          error={errors.cityWork} />

        <CitySelect label="预计退休居住城市" value={cityRetire || cityWork}
          onChange={v => updateCustomer({ cityRetire: v })}
          cities={cities.filter(ct => !ct.isOverseas)}
          hint="默认与工作城市相同，可修改。用于退休后生活成本估算" />

        <RadioGroup label="社保类型" value={ssType} options={SS_TYPE_OPTIONS}
          onChange={v => updateCustomer({ socialSecurityType: v })} required />

        <AnimatePresence>
          {ssType === 'civil_servant' && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden">
              <NumberInput label="参加工作年份" value={workStartYear}
                onChange={v => updateCustomer({ workStartYear: v })}
                min={1970} max={currentYear} placeholder="如：2005"
                hint="2014年10月前参加工作者适用机关单位改革过渡办法（'中人'）" />
            </motion.div>
          )}
        </AnimatePresence>

        <div className="grid grid-cols-3 gap-4">
          <NumberInput label="税后月收入" value={monthlyIncome}
            onChange={v => updateCustomer({ monthlyIncome: v })}
            unit="元" min={0} required error={errors.monthlyIncome} />
          <NumberInput label="社保缴费基数" value={ssContributionBase}
            onChange={v => updateCustomer({ ssContributionBase: v })}
            unit="元" min={0} placeholder="留空=月收入" hint="默认=月收入，可修改" />
          <NumberInput label="已缴社保年数" value={yearsPaid}
            onChange={v => updateCustomer({ yearsPaid: v })}
            unit="年" min={0} max={50} required error={errors.yearsPaid}
            validate={v => {
              if (v === undefined) return '请输入已缴社保年数'
              if (age && v > age - 16) return `缴费年数不能超过${age - 16}年`
              return undefined
            }} />
        </div>

        {legalRetirementAge !== null && (
          <div className="flex items-center gap-2 bg-accent/8 border border-accent/20 rounded-lg px-4 py-3">
            <Info size={16} className="text-accent flex-shrink-0" />
            <div className="text-sm">
              <span className="text-text-secondary">法定退休年龄：</span>
              <span className="text-accent font-semibold">{legalRetirementAge}岁</span>
              <span className="text-text-secondary ml-3">弹性区间：</span>
              <span className="text-text-primary">{Math.max(legalRetirementAge - 3, 50)}~{legalRetirementAge + 3}岁</span>
            </div>
          </div>
        )}
      </div>

      {/* ===== 配偶信息 ===== */}
      <div className="card">
        <button type="button" className="w-full flex items-center justify-between p-5 text-left"
          onClick={() => updateCustomer({
            hasSpouse: !hasSpouse,
            spouse: !hasSpouse ? (sp || { age: 35, gender: 'female', cityWork: cityWork, socialSecurityType: 'employee', yearsPaid: 10, monthlyIncome: 0 }) : undefined
          })}>
          <div className="flex items-center gap-2">
            <Users size={18} className="text-accent" />
            <span className="font-medium">配偶信息</span>
            {!hasSpouse && <span className="text-text-secondary text-sm">（可选）</span>}
          </div>
          {hasSpouse ? <ChevronUp size={18} className="text-text-secondary" /> : <ChevronDown size={18} className="text-text-secondary" />}
        </button>

        <AnimatePresence>
          {hasSpouse && (
            <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
              exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.25 }} className="overflow-hidden">
              <div className="px-5 pb-5 space-y-4 border-t border-bg-border pt-4">
                <div className="grid grid-cols-2 gap-4">
                  <NumberInput label="配偶出生年份" value={sp?.birthYear}
                    onChange={v => updateCustomer({ spouse: spousePatch(sp, { birthYear: v, age: v ? currentYear - v : sp?.age }) })}
                    min={1940} max={currentYear - 18} placeholder={`如：${currentYear - 33}`}
                    hint="用于计算配偶退休年份" />
                  <NumberInput label="配偶年龄" value={sp?.age}
                    onChange={v => updateCustomer({ spouse: spousePatch(sp, { age: v, birthYear: v ? currentYear - v : sp?.birthYear }) })}
                    unit="岁" min={18} max={80} />
                </div>
                <RadioGroup label="配偶性别" value={sp?.gender || 'female'} options={GENDER_OPTIONS}
                  onChange={v => updateCustomer({ spouse: spousePatch(sp, { gender: v, femaleIdentityType: undefined }) })} />

                <AnimatePresence>
                  {sp?.gender === 'female' && (sp?.socialSecurityType || 'employee') === 'employee' && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden">
                      <RadioGroup label="配偶身份类型" value={sp?.femaleIdentityType || 'worker'}
                        options={FEMALE_IDENTITY_OPTIONS}
                        onChange={v => updateCustomer({ spouse: spousePatch(sp, { femaleIdentityType: v }) })} />
                    </motion.div>
                  )}
                </AnimatePresence>

                <CitySelect label="配偶工作城市" value={sp?.cityWork || cityWork}
                  onChange={v => updateCustomer({ spouse: spousePatch(sp, { cityWork: v, cityRetire: sp?.cityRetire || v }) })}
                  cities={cities} hint="用于配偶社保计算" />

                <CitySelect label="配偶退休居住城市" value={sp?.cityRetire || sp?.cityWork || cityRetire || cityWork}
                  onChange={v => updateCustomer({ spouse: spousePatch(sp, { cityRetire: v }) })}
                  cities={cities.filter(ct => !ct.isOverseas)}
                  hint="默认与配偶工作城市相同" />

                <RadioGroup label="配偶社保类型" value={sp?.socialSecurityType || 'employee'}
                  options={SS_TYPE_OPTIONS}
                  onChange={v => updateCustomer({ spouse: spousePatch(sp, { socialSecurityType: v }) })} />

                <AnimatePresence>
                  {sp?.socialSecurityType === 'civil_servant' && (
                    <motion.div initial={{ height: 0, opacity: 0 }} animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }} transition={{ duration: 0.2 }} className="overflow-hidden">
                      <NumberInput label="配偶参加工作年份" value={sp?.workStartYear}
                        onChange={v => updateCustomer({ spouse: spousePatch(sp, { workStartYear: v }) })}
                        min={1970} max={currentYear} placeholder="如：2008" />
                    </motion.div>
                  )}
                </AnimatePresence>

                <div className="grid grid-cols-3 gap-4">
                  <NumberInput label="配偶税后月收入" value={sp?.monthlyIncome}
                    onChange={v => updateCustomer({ spouse: spousePatch(sp, { monthlyIncome: v, ssContributionBase: sp?.ssContributionBase || v }) })}
                    unit="元" min={0} />
                  <NumberInput label="配偶缴费基数" value={sp?.ssContributionBase}
                    onChange={v => updateCustomer({ spouse: spousePatch(sp, { ssContributionBase: v }) })}
                    unit="元" min={0} hint="默认=月收入" />
                  <NumberInput label="配偶已缴社保年数" value={sp?.yearsPaid}
                    onChange={v => updateCustomer({ spouse: spousePatch(sp, { yearsPaid: v }) })}
                    unit="年" min={0} max={50} />
                </div>

                {spouseLegalAge !== null && (
                  <div className="flex items-center gap-2 bg-accent/8 border border-accent/20 rounded-lg px-4 py-3">
                    <Info size={16} className="text-accent flex-shrink-0" />
                    <span className="text-sm">
                      <span className="text-text-secondary">配偶法定退休年龄：</span>
                      <span className="text-accent font-semibold">{spouseLegalAge}岁</span>
                    </span>
                  </div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ===== 子女信息 ===== */}
      <div className="card p-5 space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Users size={18} className="text-accent" />
            <h2 className="font-medium">子女信息</h2>
            <span className="text-text-secondary text-sm">（教育成本测算用）</span>
          </div>
          {children.length < 5 && (
            <button type="button" onClick={handleAddChild} className="btn-secondary text-sm flex items-center gap-1 py-1.5">
              <Plus size={15} />添加子女
            </button>
          )}
        </div>
        {children.length === 0 && <p className="text-text-secondary text-sm text-center py-4">暂无子女，点击添加</p>}
        <div className="space-y-3">
          {children.map((child, idx) => (
            <div key={child.id} className="bg-bg-float rounded-lg p-4 flex items-end gap-3">
              <span className="text-text-secondary text-sm whitespace-nowrap mb-2">子女 {idx + 1}</span>
              <div className="flex-1 grid grid-cols-2 gap-3">
                <NumberInput label="当前年龄" value={child.age}
                  onChange={v => updateCustomer({ children: children.map(ch => ch.id === child.id ? { ...ch, age: v, birthYear: v !== undefined ? currentYear - v : ch.birthYear } : ch) })}
                  min={0} max={25} unit="岁" required
                  validate={v => {
                    if (v === undefined) return '请输入子女年龄'
                    if (v < 0 || v > 25) return '子女年龄应在0~25岁'
                    return undefined
                  }} />
                <RadioGroup label="性别" value={child.gender || 'male'} options={GENDER_OPTIONS}
                  onChange={v => updateCustomer({ children: children.map(ch => ch.id === child.id ? { ...ch, gender: v } : ch) })} />
              </div>
              <button type="button" onClick={() => removeChild(child.id)} className="text-text-secondary hover:text-accent-danger p-1 mb-1">
                <Trash2 size={16} />
              </button>
            </div>
          ))}
        </div>
      </div>

      <div className="flex justify-end pt-2">
        <button onClick={handleNext} className="btn-primary px-8 py-2.5">下一步：家庭财务</button>
      </div>
    </div>
  )
}
