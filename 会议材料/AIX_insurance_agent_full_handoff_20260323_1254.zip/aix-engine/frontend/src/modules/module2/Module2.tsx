/**
 * 模块二：家庭财务健康评分 — V1.0
 * 详细收集收入、支出、资产与负债
 */
import { useState } from 'react'
import { useStore } from '../../store/useStore'
import { calcFinancialScore as apiCalcScore } from '../../api/client'
import { NumberInput } from '../../components/FormField'
import GaugeChart from '../../components/charts/GaugeChart'
import type { FinancialScore, Scenario } from '../../types'
import { Sun, Cloud, CloudRain } from 'lucide-react'

const SCENARIO_STYLE: Record<Scenario, { label: string; icon: React.ReactNode; desc: string }> = {
  pessimistic: { label: '悲观', icon: <CloudRain size={18} />, desc: '—' },
  neutral:     { label: '中性', icon: <Cloud size={18} />,     desc: '—' },
  optimistic:  { label: '乐观', icon: <Sun size={18} />,       desc: '—' },
}


function ScoreBar({ label, value, pct }: { label: string; value: string; pct: number }) {
  const color = pct >= 66 ? '#34C759' : pct >= 40 ? '#FF9500' : '#FF3B30'
  return (
    <div className="space-y-1">
      <div className="flex justify-between text-xs">
        <span className="text-text-secondary">{label}</span>
        <span className="font-medium" style={{ color }}>{value}</span>
      </div>
      <div className="h-1.5 bg-bg-float rounded-full overflow-hidden">
        <div className="h-full rounded-full transition-all duration-500"
          style={{ width: `${Math.min(100, Math.max(0, pct))}%`, backgroundColor: color }} />
      </div>
    </div>
  )
}

function SummaryRow({ label, value, highlight }: { label: string; value: number; highlight?: 'income' | 'expense' | 'surplus' }) {
  const fmt = (v: number) => v.toLocaleString('zh-CN')
  const cls = highlight === 'income' ? 'text-accent font-semibold'
    : highlight === 'expense' ? 'text-accent-danger font-semibold'
    : highlight === 'surplus'
      ? (value >= 0 ? 'text-accent-success font-bold text-base' : 'text-accent-danger font-bold text-base')
      : 'font-medium'
  return (
    <div className="flex justify-between items-center py-1.5 border-b border-bg-border/40 last:border-0">
      <span className="text-sm text-text-secondary">{label}</span>
      <span className={`text-sm ${cls}`}>{fmt(value)} 元</span>
    </div>
  )
}

export default function Module2() {
  const { customer, financial, updateFinancial, setFinancialScore, setActiveModule, scenario, setScenario, scenarioParams } = useStore()
  const f = financial || {}
  const [score, setScore] = useState<FinancialScore | null>(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const hasSpouse = customer?.hasSpouse || false
  const personalSalary = customer?.monthlyIncome || 0
  const spouseSalary = customer?.spouse?.monthlyIncome || 0

  // 本人月收入汇总
  const personalTotal = personalSalary
    + (f.personalRentalIncome || 0)
    + (f.personalInvestmentIncome || 0)
    + (f.personalOtherIncome || 0)
  // 配偶月收入汇总
  const spouseTotal = hasSpouse
    ? spouseSalary + (f.spouseRentalIncome || 0) + (f.spouseInvestmentIncome || 0) + (f.spouseOtherIncome || 0)
    : 0
  // 家庭月总收入
  const familyIncome = personalTotal + spouseTotal

  // 月总支出（不含贷款）
  const fixedExpense = (f.rentMonthly || 0)
    + (f.dailyLivingMonthly || 0)
    + (f.insurancePremiumMonthly || 0)
    + (f.educationCurrentMonthly || 0)
    + (f.otherFixedMonthly || 0)
  const totalLoans = (f.mortgageMonthly || 0) + (f.otherLoanMonthly || 0)
  const totalExpense = fixedExpense + totalLoans

  // 月结余
  const monthlySurplus = familyIncome - totalExpense

  // 可变现资产合计
  const availableAssets = (f.cashAndDeposits || 0)
    + (f.investmentAssets || 0)
    + (f.insuranceCashValue || 0)
    + (f.otherFinancialAssets || 0)

  const handleScore = async () => {
    setLoading(true)
    setError(null)
    try {
      const result: FinancialScore = await apiCalcScore({
        financial: {
          personalMonthlyIncome: personalTotal,
          spouseMonthlyIncome: hasSpouse ? spouseTotal : undefined,
          totalFamilyMonthlyIncome: familyIncome,
          fixedMonthlyExpense: fixedExpense,
          mortgageMonthly: f.mortgageMonthly || 0,
          otherLoanMonthly: f.otherLoanMonthly || 0,
          availableAssets,
        },
        socialSecurityType: customer?.socialSecurityType ?? 'none',
        spouseSocialSecurityType: customer?.spouse?.socialSecurityType,
      })
      setScore(result)
      setFinancialScore(result)
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : '评分失败，请重试')
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">家庭财务健康评分</h1>
        <p className="text-text-secondary text-sm mt-1">填写家庭收支、资产和负债情况，系统自动生成财务健康评分</p>
      </div>

      {/* 月收入 */}
      <div className="card-accent p-6 space-y-5">
        <h2 className="font-semibold text-base">月收入明细</h2>

        {/* 本人收入 */}
        <div className="space-y-3">
          <div className="text-sm font-medium text-text-secondary border-b border-bg-border pb-1">
            {hasSpouse ? '本人收入' : '月收入'}
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="flex flex-col gap-1">
              <label className="field-label">工资薪资</label>
              <div className="flex items-center gap-2">
                <span className="input flex-1 bg-bg-float/60 text-text-secondary cursor-not-allowed text-sm">
                  {personalSalary.toLocaleString()} 元
                </span>
                <span className="text-xs text-text-muted">来自模块一</span>
              </div>
            </div>
            <NumberInput label="租金收入" value={f.personalRentalIncome} unit="元" min={0}
              onChange={v => updateFinancial({ personalRentalIncome: v })} hint="月均租金净收入" />
            <NumberInput label="投资理财收益" value={f.personalInvestmentIncome} unit="元" min={0}
              onChange={v => updateFinancial({ personalInvestmentIncome: v })} hint="股息、基金分红等月均值" />
            <NumberInput label="其他收入" value={f.personalOtherIncome} unit="元" min={0}
              onChange={v => updateFinancial({ personalOtherIncome: v })} hint="副业、兼职等" />
          </div>
          <div className="flex justify-end text-sm">
            <span className="text-text-muted mr-2">本人月收入合计：</span>
            <span className="font-semibold text-accent">{personalTotal.toLocaleString()} 元</span>
          </div>
        </div>

        {/* 配偶收入 */}
        {hasSpouse && (
          <div className="space-y-3">
            <div className="text-sm font-medium text-text-secondary border-b border-bg-border pb-1">配偶收入</div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-1">
                <label className="field-label">工资薪资</label>
                <div className="flex items-center gap-2">
                  <span className="input flex-1 bg-bg-float/60 text-text-secondary cursor-not-allowed text-sm">
                    {spouseSalary.toLocaleString()} 元
                  </span>
                  <span className="text-xs text-text-muted">来自模块一</span>
                </div>
              </div>
              <NumberInput label="租金收入" value={f.spouseRentalIncome} unit="元" min={0}
                onChange={v => updateFinancial({ spouseRentalIncome: v })} />
              <NumberInput label="投资理财收益" value={f.spouseInvestmentIncome} unit="元" min={0}
                onChange={v => updateFinancial({ spouseInvestmentIncome: v })} />
              <NumberInput label="其他收入" value={f.spouseOtherIncome} unit="元" min={0}
                onChange={v => updateFinancial({ spouseOtherIncome: v })} />
            </div>
            <div className="flex justify-end text-sm">
              <span className="text-text-muted mr-2">配偶月收入合计：</span>
              <span className="font-semibold text-accent">{spouseTotal.toLocaleString()} 元</span>
            </div>
          </div>
        )}

        {/* 家庭收入合计 */}
        <div className="bg-accent/8 rounded-lg px-4 py-3 flex justify-between items-center">
          <span className="text-sm font-medium">家庭月总收入</span>
          <span className="text-lg font-bold text-accent">{familyIncome.toLocaleString()} 元</span>
        </div>
      </div>

      {/* 月度支出 */}
      <div className="card-accent p-6 space-y-5">
        <h2 className="font-semibold text-base">月度支出明细</h2>
        <div className="grid grid-cols-2 gap-4">
          <NumberInput label="住房租金" value={f.rentMonthly} unit="元" min={0}
            onChange={v => updateFinancial({ rentMonthly: v })} hint="租房者填写，自有住房填0" />
          <NumberInput label="房贷月供" value={f.mortgageMonthly} unit="元" min={0}
            onChange={v => updateFinancial({ mortgageMonthly: v })} hint="无则填0" />
          <NumberInput label="其他贷款月还款" value={f.otherLoanMonthly} unit="元" min={0}
            onChange={v => updateFinancial({ otherLoanMonthly: v })} hint="消费贷、车贷等" />
          <NumberInput label="日常生活支出" value={f.dailyLivingMonthly} unit="元" min={0}
            onChange={v => updateFinancial({ dailyLivingMonthly: v })} hint="餐饮、交通、购物、水电等" />
          <NumberInput label="保险保费" value={f.insurancePremiumMonthly} unit="元" min={0}
            onChange={v => updateFinancial({ insurancePremiumMonthly: v })} hint="月均保费支出" />
          <NumberInput label="子女现阶段教育支出" value={f.educationCurrentMonthly} unit="元" min={0}
            onChange={v => updateFinancial({ educationCurrentMonthly: v })} hint="学费、兴趣班等月均值" />
          <NumberInput label="其他固定支出" value={f.otherFixedMonthly} unit="元" min={0}
            onChange={v => updateFinancial({ otherFixedMonthly: v })} />
        </div>

        {/* 支出汇总 */}
        <div className="bg-bg-float rounded-lg p-4 space-y-0.5">
          <SummaryRow label="固定生活支出（不含还贷）" value={fixedExpense} />
          <SummaryRow label="每月还贷合计" value={totalLoans} />
          <div className="pt-1 mt-1 border-t border-bg-border/60 flex justify-between items-center">
            <span className="text-sm font-medium">月总支出</span>
            <span className="font-semibold text-accent-danger">{totalExpense.toLocaleString()} 元</span>
          </div>
        </div>
      </div>

      {/* 月度收支汇总 */}
      <div className={`card p-5 border-2 ${monthlySurplus >= 0 ? 'border-accent-success/30 bg-accent-success/5' : 'border-accent-danger/30 bg-accent-danger/5'}`}>
        <div className="grid grid-cols-3 gap-4 text-center">
          <div>
            <div className="text-xs text-text-muted mb-1">月总收入</div>
            <div className="text-lg font-bold text-accent">{familyIncome.toLocaleString()}</div>
            <div className="text-xs text-text-muted">元</div>
          </div>
          <div className="border-x border-bg-border">
            <div className="text-xs text-text-muted mb-1">月总支出</div>
            <div className="text-lg font-bold text-accent-danger">{totalExpense.toLocaleString()}</div>
            <div className="text-xs text-text-muted">元</div>
          </div>
          <div>
            <div className="text-xs text-text-muted mb-1">月结余</div>
            <div className={`text-lg font-bold ${monthlySurplus >= 0 ? 'text-accent-success' : 'text-accent-danger'}`}>
              {monthlySurplus >= 0 ? '+' : ''}{monthlySurplus.toLocaleString()}
            </div>
            <div className="text-xs text-text-muted">元</div>
          </div>
        </div>
        {familyIncome > 0 && (
          <div className="mt-3 text-center text-xs text-text-secondary">
            结余率 {((monthlySurplus / familyIncome) * 100).toFixed(1)}%
            {monthlySurplus / familyIncome >= 0.20
              ? ' · 结余状况良好' : monthlySurplus / familyIncome >= 0
              ? ' · 结余偏低，建议提升至20%以上' : ' · 月度入不敷出，需优化支出'}
          </div>
        )}
      </div>

      {/* 资产情况 */}
      <div className="card-accent p-6 space-y-5">
        <h2 className="font-semibold text-base">资产明细</h2>
        <div className="grid grid-cols-2 gap-4">
          <NumberInput label="银行存款/货币基金" value={f.cashAndDeposits} unit="元" min={0}
            onChange={v => updateFinancial({ cashAndDeposits: v })} hint="活期、定期、货币基金等" />
          <NumberInput label="股票/基金/债券/理财" value={f.investmentAssets} unit="元" min={0}
            onChange={v => updateFinancial({ investmentAssets: v })} hint="按当前市值估算" />
          <NumberInput label="保险现金价值" value={f.insuranceCashValue} unit="元" min={0}
            onChange={v => updateFinancial({ insuranceCashValue: v })} hint="已购保险的累计现金价值" />
          <NumberInput label="其他金融资产" value={f.otherFinancialAssets} unit="元" min={0}
            onChange={v => updateFinancial({ otherFinancialAssets: v })} />
          <NumberInput label="房产市值（参考）" value={f.propertyValue} unit="元" min={0}
            onChange={v => updateFinancial({ propertyValue: v })} hint="仅供参考，不计入可变现资产" />
        </div>

        {/* 资产合计 */}
        <div className="bg-bg-float rounded-lg px-4 py-3 flex justify-between items-center">
          <div>
            <span className="text-sm font-medium">可变现金融资产合计</span>
            <p className="text-xs text-text-muted mt-0.5">不含房产，用于评估应急储备充足度</p>
          </div>
          <span className="text-lg font-bold text-accent">{availableAssets.toLocaleString()} 元</span>
        </div>
      </div>

      {/* 情景假设（§3.4） */}
      <div className="card-accent p-6 space-y-5">
        <div>
          <h2 className="font-semibold text-base">情景假设（§5.7）</h2>
          <p className="text-text-secondary text-xs mt-1">选择不同假设情景，测算结果实时更新。默认中性情景。</p>
        </div>

        <div className="grid grid-cols-3 gap-3">
          {(['pessimistic', 'neutral', 'optimistic'] as Scenario[]).map(s => {
            const st = SCENARIO_STYLE[s]
            const active = scenario === s
            return (
              <button key={s} onClick={() => setScenario(s)}
                className={`select-card flex flex-col items-center gap-2 py-4 transition-all
                  ${active ? 'ring-2 ring-accent bg-accent/5' : ''}`}>
                <span className={active ? 'text-accent' : 'text-text-muted'}>{st.icon}</span>
                <span className={`font-medium text-sm ${active ? 'text-accent' : 'text-text-primary'}`}>{st.label}</span>
                <span className="text-text-muted text-xs">—</span>
              </button>
            )
          })}
        </div>

        <div className="bg-bg-float rounded-lg px-4 py-3 grid grid-cols-3 gap-4 text-sm">
          <div>
            <span className="text-text-muted text-xs">工资增速：</span>
            <span className="font-semibold">{(scenarioParams.wageGrowthRate * 100).toFixed(1)}%</span>
          </div>
          <div>
            <span className="text-text-muted text-xs">通胀率：</span>
            <span className="font-semibold">{(scenarioParams.inflationRate * 100).toFixed(1)}%</span>
          </div>
          <div>
            <span className="text-text-muted text-xs">投资收益：</span>
            <span className="font-semibold">{(scenarioParams.returnRate * 100).toFixed(1)}%</span>
          </div>
        </div>
      </div>

      {/* 生成评分 */}
      {!score && (
        <button
          onClick={handleScore}
          disabled={loading || familyIncome === 0}
          className="btn-primary w-full py-3 text-base disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {loading ? '评分中...' : '生成财务健康评分'}
        </button>
      )}

      {error && (
        <div className="card border border-accent-danger/30 bg-accent-danger/10 p-4 text-sm text-accent-danger">{error}</div>
      )}

      {/* 评分结果 */}
      {score && (
        <div className="card p-6 space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="font-semibold">财务健康评分</h3>
            <button onClick={() => setScore(null)} className="text-xs text-text-muted hover:text-accent underline">重新评分</button>
          </div>

          {/* §9.6 圆形进度环仪表盘 */}
          <GaugeChart score={score.total} grade={score.grade} />

          <div className="space-y-3">
            <ScoreBar label="收支结余率" value={`${(score.surplusRatio * 100).toFixed(1)}%`} pct={score.surplusRatio / 0.20 * 100} />
            <ScoreBar label="负债压力比" value={`${(score.debtRatio * 100).toFixed(1)}%`} pct={(1 - score.debtRatio / 0.50) * 100} />
            <ScoreBar label="资产储备充足度" value={`${score.assetAdequacy.toFixed(2)}x`} pct={score.assetAdequacy * 100} />
          </div>

          <div className="flex items-center gap-2 text-sm">
            <span className="text-text-muted">社保保障层级：</span>
            <span className={`badge-${score.ssLevel === 'high' ? 'success' : score.ssLevel === 'medium' ? 'warning' : 'danger'}`}>
              {score.ssLevel === 'high' ? '高保障' : score.ssLevel === 'medium' ? '中等保障' : '低保障'}
            </span>
            <span className="ml-3 text-text-muted text-xs">{score.grade}</span>
          </div>

          {score.detail && (
            <div className="bg-bg-float rounded-lg p-4 text-sm text-text-secondary leading-relaxed">{score.detail}</div>
          )}
        </div>
      )}

      <div className="flex justify-between pt-2">
        <button onClick={() => setActiveModule(1)} className="btn-secondary px-6 py-2.5">上一步</button>
        <div className="flex items-center gap-3">
          {!score && familyIncome > 0 && (
            <span className="text-text-muted text-xs">建议先生成财务评分</span>
          )}
          <button onClick={() => setActiveModule(3)} className="btn-primary px-8 py-2.5">下一步：保障需求</button>
        </div>
      </div>
    </div>
  )
}
