/**
 * 模块六：产品推荐
 * 规则引擎匹配 + 缺口可视化 + 产品详情卡
 */
import { useEffect, useState } from 'react'
import { motion } from 'framer-motion'
import { Sparkles, RefreshCw, Target, ShieldCheck, BookOpen, Heart, Stethoscope, ArrowRight } from 'lucide-react'
import { useStore } from '../../store/useStore'
import { fetchProductRecommendations } from '../../api/client'
import type { ProductRecord } from '../../types'

// ── 标签元数据 ────────────────────────────────────────────
const TAG_META: Record<string, { label: string; color: string; bg: string; Icon: React.ElementType }> = {
  pension:    { label: '养老储备',   color: 'text-accent',         bg: 'bg-accent/15',         Icon: Target },
  education:  { label: '教育储备',   color: 'text-accent-warning', bg: 'bg-accent-warning/15', Icon: BookOpen },
  protection: { label: '风险保障',   color: 'text-accent-danger',  bg: 'bg-accent-danger/15',  Icon: ShieldCheck },
  life:       { label: '家庭保障',   color: 'text-purple-400',     bg: 'bg-purple-500/15',     Icon: Heart },
  medical:    { label: '医疗保障',   color: 'text-accent-success', bg: 'bg-accent-success/15', Icon: Stethoscope },
}

const TYPE_COLORS: Record<string, string> = {
  '年金险':     'bg-accent/20 text-accent',
  '增额终身寿': 'bg-accent-success/20 text-accent-success',
  '教育金':     'bg-accent-warning/20 text-accent-warning',
  '定期寿险':   'bg-accent-danger/20 text-accent-danger',
  '重疾险':     'bg-purple-500/20 text-purple-400',
  '个人养老金': 'bg-blue-500/20 text-blue-400',
  '百万医疗':   'bg-teal-500/20 text-teal-400',
  '小额医疗':   'bg-teal-400/20 text-teal-300',
}

// ── 缺口摘要数据 ──────────────────────────────────────────
function GapSummary() {
  const { pensionResult, educationResult, financialScore } = useStore()

  const items = [
    pensionResult && {
      label: '养老缺口',
      value: pensionResult.pensionGap > 0
        ? `${(pensionResult.pensionGap / 10000).toFixed(0)} 万`
        : '已覆盖',
      ok: pensionResult.pensionGap <= 0,
      color: 'text-accent',
    },
    educationResult && {
      label: '教育费用',
      value: `${(educationResult.familyTotal / 10000).toFixed(0)} 万`,
      ok: false,
      color: 'text-accent-warning',
    },
    financialScore && {
      label: '财务评分',
      value: `${financialScore.total} 分`,
      ok: financialScore.total >= 75,
      color: financialScore.total >= 75 ? 'text-accent-success' : 'text-accent-danger',
    },
  ].filter(Boolean) as { label: string; value: string; ok: boolean; color: string }[]

  if (items.length === 0) return null

  return (
    <div className="grid grid-cols-3 gap-3">
      {items.map(item => (
        <div key={item.label} className="bg-bg-card border border-bg-border rounded-xl p-4 text-center">
          <div className="text-text-muted text-xs mb-1">{item.label}</div>
          <div className={`text-xl font-bold ${item.color}`}>{item.value}</div>
        </div>
      ))}
    </div>
  )
}

// ── 产品卡片 ──────────────────────────────────────────────
function ProductCard({
  product, matchedTags, tagReasons, index,
}: {
  product: ProductRecord
  matchedTags: string[]
  tagReasons: Record<string, string>
  index: number
}) {
  const [expanded, setExpanded] = useState(false)
  const colorClass = TYPE_COLORS[product.productType] || 'bg-bg-float text-text-muted'

  // 找出此产品匹配了哪些触发标签
  const myTags = product.scenarioTags.filter(t => matchedTags.includes(t))

  return (
    <motion.div
      className="bg-bg-card border border-bg-border rounded-xl overflow-hidden"
      initial={{ opacity: 0, y: 16 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.07, duration: 0.35, ease: 'easeOut' }}
    >
      {/* 头部 */}
      <div className="p-5">
        <div className="flex items-start justify-between gap-3 mb-3">
          <h3 className="text-text-primary font-semibold text-base leading-snug">{product.name}</h3>
          <span className={`shrink-0 text-xs px-2.5 py-1 rounded-full font-medium ${colorClass}`}>
            {product.productType}
          </span>
        </div>

        {/* 匹配标签 */}
        <div className="flex flex-wrap gap-1.5 mb-3">
          {myTags.map(tag => {
            const meta = TAG_META[tag]
            if (!meta) return null
            const Icon = meta.Icon
            return (
              <span key={tag} className={`inline-flex items-center gap-1 text-xs px-2 py-0.5 rounded-full ${meta.bg} ${meta.color}`}>
                <Icon size={10} />
                {meta.label}
              </span>
            )
          })}
        </div>

        {/* 亮点 */}
        <p className="text-text-secondary text-sm leading-relaxed">{product.highlights}</p>

        {/* 展开详情 */}
        <button
          onClick={() => setExpanded(v => !v)}
          className="mt-3 flex items-center gap-1 text-xs text-text-muted hover:text-accent transition-colors"
        >
          {expanded ? '收起' : '查看详情'}
          <ArrowRight size={10} className={`transition-transform ${expanded ? 'rotate-90' : ''}`} />
        </button>
      </div>

      {/* 展开区域 */}
      {expanded && (
        <div className="border-t border-bg-border px-5 py-4 space-y-3 bg-bg-float/40">
          <div className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <span className="text-text-muted">适合年龄</span>
              <span className="ml-2 text-text-primary font-medium">{product.minAge}~{product.maxAge} 岁</span>
            </div>
            <div>
              <span className="text-text-muted">产品类型</span>
              <span className="ml-2 text-text-primary font-medium">{product.productType}</span>
            </div>
          </div>

          {/* 匹配原因 */}
          {myTags.map(tag => tagReasons[tag] && (
            <div key={tag} className="flex gap-2 text-xs">
              <span className={`shrink-0 ${TAG_META[tag]?.color ?? 'text-text-muted'}`}>●</span>
              <span className="text-text-secondary">{tagReasons[tag]}</span>
            </div>
          ))}
        </div>
      )}
    </motion.div>
  )
}

// ── 主组件 ────────────────────────────────────────────────
export default function Module6() {
  const { customer, financial, financialScore, pensionResult, educationResult, setActiveModule } = useStore()

  const [loading, setLoading]       = useState(false)
  const [result, setResult]         = useState<{
    candidates: ProductRecord[]
    matchedTags: string[]
    tagReasons: Record<string, string>
    isEmpty: boolean
  } | null>(null)
  const [error, setError]           = useState<string | null>(null)

  const canLoad = !!pensionResult

  const load = async () => {
    setLoading(true)
    setError(null)
    try {
      const data = await fetchProductRecommendations({
        customer,
        financial,
        financialScore,
        pensionResult,
        educationResult,
      })
      setResult(data)
    } catch (e) {
      setError(e instanceof Error ? e.message : '加载失败，请重试')
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    if (canLoad) load()
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // ── 未完成前置模块 ──────────────────────────────────────
  if (!canLoad) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold text-text-primary">产品推荐</h1>
          <p className="text-text-secondary text-sm mt-1">基于您的测算数据，匹配最适合的保险产品</p>
        </div>
        <div className="card p-10 text-center space-y-4">
          <span className="text-5xl">🎯</span>
          <p className="text-text-secondary">请先完成养老缺口测算，系统将根据您的具体数据匹配产品</p>
          <button onClick={() => setActiveModule(5)} className="btn-primary mx-auto block px-8 py-2.5">
            前往养老测算
          </button>
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      {/* 标题 */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold text-text-primary">产品推荐</h1>
          <p className="text-text-secondary text-sm mt-1">基于规则引擎自动匹配，AI报告中有更详细的个性化分析</p>
        </div>
        <button
          onClick={load}
          disabled={loading}
          className="btn-secondary flex items-center gap-1.5 px-3 py-2 text-sm disabled:opacity-50"
        >
          <RefreshCw size={14} className={loading ? 'animate-spin' : ''} />
          刷新
        </button>
      </div>

      {/* 缺口摘要 */}
      <GapSummary />

      {/* 加载中 */}
      {loading && (
        <div className="space-y-3">
          {[1, 2, 3].map(i => (
            <div key={i} className="card p-5 space-y-3 animate-pulse">
              <div className="flex justify-between">
                <div className="h-4 bg-bg-float rounded w-40" />
                <div className="h-5 bg-bg-float rounded-full w-16" />
              </div>
              <div className="h-3 bg-bg-float rounded w-full" />
              <div className="h-3 bg-bg-float rounded w-3/4" />
            </div>
          ))}
        </div>
      )}

      {/* 错误 */}
      {error && (
        <div className="card border border-accent-danger/30 bg-accent-danger/10 p-4 text-sm text-accent-danger">{error}</div>
      )}

      {/* 触发标签说明 */}
      {result && !result.isEmpty && (
        <div className="bg-bg-card border border-bg-border rounded-xl p-5 space-y-3">
          <div className="flex items-center gap-2 text-sm font-semibold text-text-primary">
            <Sparkles size={15} className="text-accent" />
            匹配依据
          </div>
          <div className="space-y-2">
            {result.matchedTags.map(tag => {
              const meta = TAG_META[tag]
              const reason = result.tagReasons[tag]
              if (!meta || !reason) return null
              const Icon = meta.Icon
              return (
                <div key={tag} className="flex items-start gap-2.5 text-sm">
                  <span className={`shrink-0 mt-0.5 ${meta.color}`}><Icon size={14} /></span>
                  <div>
                    <span className={`font-medium ${meta.color}`}>{meta.label}</span>
                    <span className="text-text-secondary mx-1.5">—</span>
                    <span className="text-text-secondary">{reason}</span>
                  </div>
                </div>
              )
            })}
          </div>
        </div>
      )}

      {/* 无产品 */}
      {result?.isEmpty && (
        <div className="card p-10 text-center space-y-3">
          <span className="text-4xl">✅</span>
          <p className="text-text-secondary text-sm">当前保障状况较为完善，暂无需优先配置的产品</p>
          <p className="text-text-muted text-xs">如有具体需求，可前往 AI报告 模块与顾问AI详细沟通</p>
        </div>
      )}

      {/* 产品卡片列表 */}
      {result && !result.isEmpty && (
        <div className="space-y-3">
          <div className="text-text-muted text-xs">共匹配 {result.candidates.length} 款产品</div>
          {result.candidates.map((product, i) => (
            <ProductCard
              key={product.id}
              product={product}
              matchedTags={result.matchedTags}
              tagReasons={result.tagReasons}
              index={i}
            />
          ))}
        </div>
      )}

      {/* 底部提示 + 跳转 AI 报告 */}
      {result && !result.isEmpty && (
        <div className="bg-accent/8 border border-accent/20 rounded-xl p-4 flex items-center justify-between gap-4">
          <p className="text-text-secondary text-sm">
            想了解每款产品的个性化推荐理由和保费估算？AI 报告可给出更详细的分析。
          </p>
          <button
            onClick={() => setActiveModule(6)}
            className="btn-primary shrink-0 flex items-center gap-1.5 px-4 py-2 text-sm"
          >
            生成AI报告
            <ArrowRight size={14} />
          </button>
        </div>
      )}

      <div className="flex justify-between pt-2">
        <button onClick={() => setActiveModule(6)} className="btn-secondary px-6 py-2.5">上一步</button>
        <button onClick={() => setActiveModule(6)} className="btn-primary px-6 py-2.5">AI综合报告</button>
      </div>
    </div>
  )
}
