/**
 * 数据管理后台 — §8.1~8.10 完整实现
 */
import { useState, useEffect, useCallback, useRef } from 'react'
import { Settings, Database, MapPin, GraduationCap, Globe, Package, Plus, Edit2, Check, X, ChevronDown, ChevronUp, ToggleLeft, AlertCircle } from 'lucide-react'
import { api } from '../api/client'

// ── 类型 ──────────────────────────────────────────────
interface CityRecord {
  code: string; name: string; tier: number
  socialAvgWageMonthly: number; socialAvgWageGrowthRate: number
  ssWageFloor: number; ssWageCeiling: number
  residentBasicPension: number; civilServantTransitionCoeff: number
  monthlyCost: number; dataYear: number; isEstimated: boolean
  isOverseas?: boolean
}

interface SchoolRecord {
  id: string; name: string; qsRank: number | null
  city?: string; type?: string; note?: string
  [key: string]: unknown
}

interface ProductRecord {
  id: string; name: string; productType: string
  scenarioTags: string[]; minAge: number; maxAge: number
  highlights: string; isActive?: boolean
}

interface AdminConfig {
  scenarioParams?: Record<string, Record<string, number>>
  actuarialParams?: Record<string, unknown>
  educationSavingsRate?: { conservative: number; aggressive: number }
  educationInflation?: Record<string, number>
  exchangeRates?: Record<string, number>
  financialScoringRules?: { weights: Record<string, number>; thresholds: Record<string, number> }
  interestCategories?: { categories: Array<{ key: string; label: string; description: string; defaultAnnualCostByTier: Record<string, number> }> }
}

// ── 工具组件 ──────────────────────────────────────────
const fmt = (n: number) => n?.toLocaleString('zh-CN') ?? '—'

function TabBtn({ label, icon, active, onClick }: { label: string; icon: React.ReactNode; active: boolean; onClick: () => void }) {
  return (
    <button onClick={onClick} className={`flex items-center gap-2 px-3 py-2 text-sm rounded-lg transition-colors whitespace-nowrap
      ${active ? 'bg-accent text-white font-medium' : 'text-text-secondary hover:text-text-primary hover:bg-bg-float'}`}>
      {icon}{label}
    </button>
  )
}

function SectionCard({ title, children }: { title: string; children: React.ReactNode }) {
  const [open, setOpen] = useState(true)
  return (
    <div className="card overflow-hidden">
      <button className="w-full flex items-center justify-between px-5 py-3.5 text-left" onClick={() => setOpen(v => !v)}>
        <span className="font-semibold text-sm">{title}</span>
        {open ? <ChevronUp size={15} className="text-text-muted" /> : <ChevronDown size={15} className="text-text-muted" />}
      </button>
      {open && <div className="px-5 pb-5">{children}</div>}
    </div>
  )
}

// ── Tab: 城市社保 ─────────────────────────────────────
function CitiesTab() {
  const [cities, setCities] = useState<CityRecord[]>([])
  const [editing, setEditing] = useState<string | null>(null)
  const [draft, setDraft] = useState<Partial<CityRecord>>({})
  const [saving, setSaving] = useState(false)

  useEffect(() => { api.get('/admin/cities').then(r => setCities(r.data.data)) }, [])

  const startEdit = (c: CityRecord) => { setEditing(c.code); setDraft({ ...c }) }
  const cancelEdit = () => { setEditing(null); setDraft({}) }
  const saveEdit = async () => {
    if (!editing) return
    setSaving(true)
    try {
      const res = await api.put(`/admin/cities/${editing}`, draft)
      setCities(prev => prev.map(c => c.code === editing ? res.data.data : c))
      setEditing(null)
    } finally { setSaving(false) }
  }

  const domestic = cities.filter(c => !c.isOverseas)
  const overseas = cities.filter(c => c.isOverseas)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-xs text-text-secondary">数据来源：各省市人社局2024年度公告。⚠️ 标注为估算值，建议核查。</p>
        <span className="text-xs text-text-muted">{domestic.length}个国内 · {overseas.length}个境外</span>
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-bg-border text-text-muted">
              {['城市','T','社平工资','缴费下限','缴费上限','居民养老金','工资增速','月均生活费',''].map((h, i) => (
                <th key={i} className={`py-2 px-2 font-medium ${i > 0 ? 'text-right' : 'text-left'}`}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {domestic.map(c => (
              <tr key={c.code} className={`border-b border-bg-border/30 ${c.isEstimated ? 'bg-accent-warning/5' : ''}`}>
                {editing === c.code ? (
                  <>
                    <td className="py-1 px-2 font-medium">{c.name}</td>
                    <td className="py-1 px-1"><input type="number" value={draft.tier ?? ''} onChange={e => setDraft(d => ({ ...d, tier: +e.target.value }))} className="input w-10 text-xs py-0.5 text-right" /></td>
                    <td className="py-1 px-1"><input type="number" value={draft.socialAvgWageMonthly ?? ''} onChange={e => setDraft(d => ({ ...d, socialAvgWageMonthly: +e.target.value }))} className="input w-20 text-xs py-0.5 text-right" /></td>
                    <td className="py-1 px-1"><input type="number" value={draft.ssWageFloor ?? ''} onChange={e => setDraft(d => ({ ...d, ssWageFloor: +e.target.value }))} className="input w-18 text-xs py-0.5 text-right" /></td>
                    <td className="py-1 px-1"><input type="number" value={draft.ssWageCeiling ?? ''} onChange={e => setDraft(d => ({ ...d, ssWageCeiling: +e.target.value }))} className="input w-18 text-xs py-0.5 text-right" /></td>
                    <td className="py-1 px-1"><input type="number" value={draft.residentBasicPension ?? ''} onChange={e => setDraft(d => ({ ...d, residentBasicPension: +e.target.value }))} className="input w-16 text-xs py-0.5 text-right" /></td>
                    <td className="py-1 px-1"><input type="number" step="0.001" value={draft.socialAvgWageGrowthRate ?? ''} onChange={e => setDraft(d => ({ ...d, socialAvgWageGrowthRate: +e.target.value }))} className="input w-14 text-xs py-0.5 text-right" /></td>
                    <td className="py-1 px-1"><input type="number" value={draft.monthlyCost ?? ''} onChange={e => setDraft(d => ({ ...d, monthlyCost: +e.target.value }))} className="input w-18 text-xs py-0.5 text-right" /></td>
                    <td className="py-1 px-2 flex gap-1">
                      <button onClick={saveEdit} disabled={saving} className="p-1 text-accent-success hover:bg-accent-success/10 rounded"><Check size={13} /></button>
                      <button onClick={cancelEdit} className="p-1 text-text-muted hover:bg-bg-float rounded"><X size={13} /></button>
                    </td>
                  </>
                ) : (
                  <>
                    <td className="py-2 px-2 font-medium">{c.name}{c.isEstimated && <span className="ml-1 text-accent-warning" title="估算值">⚠️</span>}</td>
                    <td className="py-2 px-2 text-right text-text-secondary">{c.tier}</td>
                    <td className="py-2 px-2 text-right font-mono">{fmt(c.socialAvgWageMonthly)}</td>
                    <td className="py-2 px-2 text-right font-mono">{fmt(c.ssWageFloor)}</td>
                    <td className="py-2 px-2 text-right font-mono">{fmt(c.ssWageCeiling)}</td>
                    <td className="py-2 px-2 text-right font-mono">{fmt(c.residentBasicPension)}</td>
                    <td className="py-2 px-2 text-right text-text-secondary">{(c.socialAvgWageGrowthRate * 100).toFixed(1)}%</td>
                    <td className="py-2 px-2 text-right font-mono">{fmt(c.monthlyCost)}</td>
                    <td className="py-2 px-2">
                      <button onClick={() => startEdit(c)} className="p-1 text-text-muted hover:text-accent hover:bg-bg-float rounded"><Edit2 size={13} /></button>
                    </td>
                  </>
                )}
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <SectionCard title={`境外目的地 (${overseas.length})`}>
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-bg-border text-text-muted">
              <th className="text-left py-1.5 px-2">目的地</th>
              <th className="text-right py-1.5 px-2">参考月均生活费(人民币)</th>
            </tr>
          </thead>
          <tbody>
            {overseas.map(c => (
              <tr key={c.code} className="border-b border-bg-border/30">
                <td className="py-1.5 px-2 font-medium">{c.name}</td>
                <td className="py-1.5 px-2 text-right font-mono">{fmt(c.monthlyCost)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </SectionCard>
    </div>
  )
}

// ── Tab: 国内学校 ─────────────────────────────────────
function DomesticSchoolsTab() {
  const [db, setDb] = useState<{ privateHighSchools: SchoolRecord[]; domesticUniversities: SchoolRecord[]; domesticGradSchools: SchoolRecord[] } | null>(null)
  const [section, setSection] = useState<'domesticUniversities' | 'domesticGradSchools' | 'privateHighSchools'>('domesticUniversities')
  const [filter, setFilter] = useState('')

  useEffect(() => { api.get('/admin/schools/domestic').then(r => setDb(r.data.data)) }, [])
  if (!db) return <div className="text-text-muted text-sm">加载中...</div>

  const tabs = [
    { key: 'domesticUniversities' as const, label: `本科 (${db.domesticUniversities.length})` },
    { key: 'domesticGradSchools' as const, label: `研究生 (${db.domesticGradSchools.length})` },
    { key: 'privateHighSchools' as const, label: `私立高中 (${db.privateHighSchools.length})` },
  ]
  const list = db[section].filter(s => !filter || s.name.includes(filter) || String(s.qsRank).includes(filter))

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-3 flex-wrap">
        <div className="flex gap-1 bg-bg-float rounded-lg p-1">
          {tabs.map(t => (
            <button key={t.key} onClick={() => setSection(t.key)}
              className={`px-3 py-1.5 text-xs rounded-md transition-colors ${section === t.key ? 'bg-accent text-white font-medium' : 'text-text-secondary hover:text-text-primary'}`}>
              {t.label}
            </button>
          ))}
        </div>
        <input value={filter} onChange={e => setFilter(e.target.value)} placeholder="搜索学校名称 / QS排名..."
          className="input text-sm py-1.5 max-w-52" />
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-bg-border text-text-muted">
              <th className="text-left py-2 px-2 font-medium">学校名称</th>
              {section !== 'privateHighSchools' && <th className="text-right py-2 px-2 font-medium">QS排名</th>}
              <th className="text-right py-2 px-2 font-medium">城市/类型</th>
              <th className="text-right py-2 px-2 font-medium">年学费(元)</th>
              <th className="text-right py-2 px-2 font-medium">年生活费(元)</th>
              {section === 'privateHighSchools' && <th className="text-left py-2 px-2 font-medium">备注</th>}
            </tr>
          </thead>
          <tbody>
            {list.map(s => (
              <tr key={s.id} className="border-b border-bg-border/30 hover:bg-bg-float/50">
                <td className="py-2 px-2 font-medium">{s.name}</td>
                {section !== 'privateHighSchools' && (
                  <td className="py-2 px-2 text-right">
                    {s.qsRank ? <span className="text-accent font-mono">#{s.qsRank}</span> : <span className="text-text-muted">—</span>}
                  </td>
                )}
                <td className="py-2 px-2 text-right text-text-secondary">{(s.city ?? s.type) as string}</td>
                <td className="py-2 px-2 text-right font-mono">{fmt((s.annualTuition as number) ?? 0)}</td>
                <td className="py-2 px-2 text-right font-mono">{s.annualLiving ? fmt(s.annualLiving as number) : '—'}</td>
                {section === 'privateHighSchools' && <td className="py-2 px-2 text-text-muted">{s.note as string}</td>}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ── Tab: 海外院校 ─────────────────────────────────────
function OverseasSchoolsTab() {
  type OverseasDB = { countries: Record<string, { name: string; currency: string; exchangeRate: number; educationInflationRate: number; universities: SchoolRecord[]; gradSchools: SchoolRecord[] }> }
  const [db, setDb] = useState<OverseasDB | null>(null)
  const [country, setCountry] = useState('us')
  const [type, setType] = useState<'universities' | 'gradSchools'>('universities')

  useEffect(() => { api.get('/admin/schools/overseas').then(r => setDb(r.data.data)) }, [])
  if (!db) return <div className="text-text-muted text-sm">加载中...</div>

  const c = db.countries[country]
  const list = c?.[type] ?? []

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap gap-1.5">
        {Object.entries(db.countries).map(([code, ct]) => (
          <button key={code} onClick={() => setCountry(code)}
            className={`px-3 py-1.5 text-xs rounded-lg border transition-colors ${country === code ? 'border-accent bg-accent/10 text-accent font-medium' : 'border-bg-border text-text-secondary hover:border-accent/50'}`}>
            {ct.name}
          </button>
        ))}
      </div>

      {c && (
        <div className="flex gap-4 text-xs text-text-secondary bg-bg-float rounded-lg px-4 py-2">
          <span>货币: <strong className="text-text-primary">{c.currency}</strong></span>
          <span>汇率: <strong className="text-text-primary">1{c.currency} = ¥{c.exchangeRate}</strong></span>
          <span>教育通胀率: <strong className="text-text-primary">{(c.educationInflationRate * 100).toFixed(1)}%/年</strong></span>
        </div>
      )}

      <div className="flex gap-1 bg-bg-float rounded-lg p-1 w-fit">
        {(['universities', 'gradSchools'] as const).map(t => (
          <button key={t} onClick={() => setType(t)}
            className={`px-3 py-1.5 text-xs rounded-md transition-colors ${type === t ? 'bg-accent text-white font-medium' : 'text-text-secondary hover:text-text-primary'}`}>
            {t === 'universities' ? `本科 (${c?.[t]?.length ?? 0})` : `研究生 (${c?.[t]?.length ?? 0})`}
          </button>
        ))}
      </div>

      <div className="overflow-x-auto">
        <table className="w-full text-xs">
          <thead>
            <tr className="border-b border-bg-border text-text-muted">
              <th className="text-left py-2 px-2 font-medium">学校名称</th>
              <th className="text-right py-2 px-2 font-medium">QS排名</th>
              <th className="text-right py-2 px-2 font-medium">年学费(原币)</th>
              <th className="text-right py-2 px-2 font-medium">年生活费(原币)</th>
              <th className="text-right py-2 px-2 font-medium">年总费用(人民币)</th>
              <th className="text-left py-2 px-2 font-medium">备注</th>
            </tr>
          </thead>
          <tbody>
            {list.map(s => {
              const cur = c.currency
              const rate = c.exchangeRate
              const tKey = `annualTuition${cur}`
              const lKey = `annualLiving${cur}` in s ? `annualLiving${cur}` : `annualLivingAnnual${cur}`
              const t = (s[tKey] as number) ?? 0
              const l = (s[lKey] as number) ?? 0
              const cny = Math.round((t + l) * rate)
              return (
                <tr key={s.id} className="border-b border-bg-border/30 hover:bg-bg-float/50">
                  <td className="py-2 px-2 font-medium">{s.name}</td>
                  <td className="py-2 px-2 text-right">{s.qsRank ? <span className="text-accent font-mono">#{s.qsRank}</span> : <span className="text-text-muted">专项</span>}</td>
                  <td className="py-2 px-2 text-right font-mono">{t ? `${cur} ${t.toLocaleString()}` : '—'}</td>
                  <td className="py-2 px-2 text-right font-mono">{l ? `${cur} ${l.toLocaleString()}` : '—'}</td>
                  <td className="py-2 px-2 text-right font-mono text-accent">¥{cny.toLocaleString()}</td>
                  <td className="py-2 px-2 text-text-muted">{(s.note as string) ?? ''}</td>
                </tr>
              )
            })}
          </tbody>
        </table>
      </div>
    </div>
  )
}

// ── Tab: 系统参数 ─────────────────────────────────────
function SystemConfigTab() {
  const [cfg, setCfg] = useState<AdminConfig | null>(null)
  const [local, setLocal] = useState<AdminConfig | null>(null)
  const [saving, setSaving] = useState<string | null>(null)

  useEffect(() => { api.get('/admin/config').then(r => { setCfg(r.data.data); setLocal(r.data.data) }) }, [])

  const save = useCallback(async (section: string) => {
    if (!local) return
    setSaving(section)
    try { await api.patch(`/admin/config/${section}`, (local as Record<string, unknown>)[section]); setCfg({ ...local }) }
    finally { setSaving(null) }
  }, [local])

  if (!cfg || !local) return <div className="text-text-muted text-sm">加载中...</div>

  return (
    <div className="space-y-4">
      {/* §8.5 三情景 */}
      <SectionCard title="§8.5 养老三情景参数">
        <div className="space-y-3">
          {(['pessimistic', 'neutral', 'optimistic'] as const).map(s => {
            const sc = (local.scenarioParams?.[s] ?? {}) as Record<string, number>
            const label = s === 'pessimistic' ? '悲观' : s === 'neutral' ? '中性' : '乐观'
            const color = s === 'pessimistic' ? 'text-accent-danger' : s === 'neutral' ? 'text-text-primary' : 'text-accent-success'
            return (
              <div key={s} className="grid grid-cols-4 gap-3 items-end">
                <div className={`text-sm font-medium pb-1 ${color}`}>{label}</div>
                {[['wageGrowthRate','工资增速%'],['inflationRate','通胀率%'],['returnRate','投资收益率%']].map(([k,lbl]) => (
                  <div key={k}>
                    <div className="text-xs text-text-muted mb-1">{lbl}</div>
                    <input type="number" step="0.1" value={((sc[k] ?? 0) * 100).toFixed(1)}
                      onChange={e => setLocal(c => ({ ...c!, scenarioParams: { ...c!.scenarioParams, [s]: { ...sc, [k]: Number(e.target.value) / 100 } } }))}
                      className="input text-xs py-1 w-full text-right" />
                  </div>
                ))}
              </div>
            )
          })}
          <button onClick={() => save('scenarioParams')} disabled={saving === 'scenarioParams'} className="btn-primary text-xs px-4 py-1.5 mt-1">
            {saving === 'scenarioParams' ? '保存中...' : '保存三情景参数'}
          </button>
        </div>
      </SectionCard>

      {/* §8.6 精算参数 */}
      <SectionCard title="§8.6 精算参数">
        <div className="grid grid-cols-2 gap-4">
          <div>
            <div className="text-xs text-text-muted mb-1">城镇职工个人账户记账利率 %</div>
            <input type="number" step="0.01" value={(((local.actuarialParams?.employeeAccountInterestRate as number) ?? 0) * 100).toFixed(2)}
              onChange={e => setLocal(c => ({ ...c!, actuarialParams: { ...c!.actuarialParams, employeeAccountInterestRate: Number(e.target.value) / 100 } }))}
              className="input text-xs py-1 w-28 text-right" />
          </div>
          <div>
            <div className="text-xs text-text-muted mb-1">城乡居民默认记账利率 %</div>
            <input type="number" step="0.1" value={(((local.actuarialParams?.residentAccountInterestRateDefault as number) ?? 0) * 100).toFixed(1)}
              onChange={e => setLocal(c => ({ ...c!, actuarialParams: { ...c!.actuarialParams, residentAccountInterestRateDefault: Number(e.target.value) / 100 } }))}
              className="input text-xs py-1 w-28 text-right" />
          </div>
          <div className="col-span-2">
            <div className="text-xs text-text-muted mb-1">健康死亡率调整系数（良好/一般/较差）</div>
            <div className="flex gap-4">
              {(['good', 'average', 'poor'] as const).map((h, i) => {
                const adj = (local.actuarialParams?.healthMortalityAdjustment as Record<string, number>) ?? {}
                return (
                  <div key={h} className="flex items-center gap-1">
                    <span className="text-xs text-text-secondary">{['良好','一般','较差'][i]}:</span>
                    <input type="number" step="0.01" value={adj[h] ?? ''}
                      onChange={e => setLocal(c => ({ ...c!, actuarialParams: { ...c!.actuarialParams, healthMortalityAdjustment: { ...(c!.actuarialParams?.healthMortalityAdjustment as object), [h]: Number(e.target.value) } } }))}
                      className="input text-xs py-1 w-16 text-right" />
                  </div>
                )
              })}
            </div>
          </div>
          <div className="col-span-2">
            <button onClick={() => save('actuarialParams')} disabled={saving === 'actuarialParams'} className="btn-primary text-xs px-4 py-1.5">
              {saving === 'actuarialParams' ? '保存中...' : '保存精算参数'}
            </button>
          </div>
        </div>
      </SectionCard>

      {/* §8.4 汇率 */}
      <SectionCard title="§8.4 外币汇率（人民币/外币）">
        <div className="grid grid-cols-5 gap-3 mb-3">
          {Object.entries(local.exchangeRates ?? {}).map(([cur, rate]) => (
            <div key={cur}>
              <div className="text-xs text-text-muted mb-0.5">1 {cur} =</div>
              <div className="flex items-center gap-1">
                <input type="number" step="0.001" value={rate}
                  onChange={e => setLocal(c => ({ ...c!, exchangeRates: { ...c!.exchangeRates, [cur]: Number(e.target.value) } }))}
                  className="input text-xs py-1 flex-1 text-right" />
                <span className="text-xs text-text-muted">¥</span>
              </div>
            </div>
          ))}
        </div>
        <button onClick={() => save('exchangeRates')} disabled={saving === 'exchangeRates'} className="btn-primary text-xs px-4 py-1.5">
          {saving === 'exchangeRates' ? '保存中...' : '保存汇率'}
        </button>
      </SectionCard>

      {/* §8.4 教育通胀率 */}
      <SectionCard title="§8.4 各国/地区教育通胀率">
        <div className="grid grid-cols-6 gap-3 mb-3">
          {Object.entries(local.educationInflation ?? {}).map(([country, rate]) => (
            <div key={country}>
              <div className="text-xs text-text-muted mb-0.5">{country === 'domestic' ? '国内' : country.toUpperCase()}</div>
              <div className="flex items-center gap-0.5">
                <input type="number" step="0.1" value={(rate * 100).toFixed(1)}
                  onChange={e => setLocal(c => ({ ...c!, educationInflation: { ...c!.educationInflation, [country]: Number(e.target.value) / 100 } }))}
                  className="input text-xs py-1 flex-1 text-right" />
                <span className="text-xs text-text-muted">%</span>
              </div>
            </div>
          ))}
        </div>
        <button onClick={() => save('educationInflation')} disabled={saving === 'educationInflation'} className="btn-primary text-xs px-4 py-1.5">
          {saving === 'educationInflation' ? '保存中...' : '保存通胀率'}
        </button>
      </SectionCard>

      {/* §8.7 教育储蓄收益率 */}
      <SectionCard title="§8.7 教育储蓄收益率假设">
        <div className="flex items-end gap-6 mb-3">
          {[['conservative', '保守'], ['aggressive', '积极']].map(([k, lbl]) => (
            <div key={k}>
              <div className="text-xs text-text-muted mb-1">{lbl}</div>
              <div className="flex items-center gap-1">
                <input type="number" step="0.1" value={((local.educationSavingsRate?.[k as 'conservative' | 'aggressive'] ?? 0) * 100).toFixed(1)}
                  onChange={e => setLocal(c => ({ ...c!, educationSavingsRate: { ...c!.educationSavingsRate!, [k]: Number(e.target.value) / 100 } }))}
                  className="input text-xs py-1 w-20 text-right" />
                <span className="text-xs text-text-muted">%</span>
              </div>
            </div>
          ))}
          <button onClick={() => save('educationSavingsRate')} disabled={saving === 'educationSavingsRate'} className="btn-primary text-xs px-4 py-1.5">
            {saving === 'educationSavingsRate' ? '保存中...' : '保存'}
          </button>
        </div>
      </SectionCard>

      {/* §8.8 财务评分 */}
      <SectionCard title="§8.8 财务评分规则">
        {local.financialScoringRules && (
          <div className="grid grid-cols-2 gap-6">
            <div>
              <div className="text-xs font-medium text-text-secondary mb-2">评分权重</div>
              {Object.entries(local.financialScoringRules.weights).map(([k, v]) => {
                const labels: Record<string, string> = { surplusRatio:'收支结余率', debtRatio:'负债压力比', assetAdequacy:'资产储备充足度', ssLevel:'社保保障层级' }
                return (
                  <div key={k} className="flex items-center gap-2 mb-2">
                    <span className="text-xs text-text-secondary w-24">{labels[k] ?? k}</span>
                    <input type="number" step="1" min="0" max="100" value={Math.round(v * 100)}
                      onChange={e => setLocal(c => ({ ...c!, financialScoringRules: { ...c!.financialScoringRules!, weights: { ...c!.financialScoringRules!.weights, [k]: Number(e.target.value) / 100 } } }))}
                      className="input text-xs py-1 w-14 text-right" />
                    <span className="text-xs text-text-muted">%</span>
                  </div>
                )
              })}
            </div>
            <div>
              <div className="text-xs font-medium text-text-secondary mb-2">分档阈值</div>
              {[['gradeHigh','优秀线(分)'],['gradeMedium','良好线(分)'],['gradeLow','警戒线(分)'],['debtRatioSafe','负债安全线'],['debtRatioDanger','负债危险线']].map(([k,lbl]) => (
                <div key={k} className="flex items-center gap-2 mb-2">
                  <span className="text-xs text-text-secondary w-24">{lbl}</span>
                  <input type="number" value={local.financialScoringRules!.thresholds[k]}
                    onChange={e => setLocal(c => ({ ...c!, financialScoringRules: { ...c!.financialScoringRules!, thresholds: { ...c!.financialScoringRules!.thresholds, [k]: Number(e.target.value) } } }))}
                    className="input text-xs py-1 w-16 text-right" />
                </div>
              ))}
            </div>
            <div className="col-span-2">
              <button onClick={() => save('financialScoringRules')} disabled={saving === 'financialScoringRules'} className="btn-primary text-xs px-4 py-1.5">
                {saving === 'financialScoringRules' ? '保存中...' : '保存评分规则'}
              </button>
            </div>
          </div>
        )}
      </SectionCard>
    </div>
  )
}

// ── Tab: 兴趣类目 ─────────────────────────────────────
function InterestCategoriesTab() {
  const [cats, setCats] = useState<AdminConfig['interestCategories']>(undefined)
  const [saving, setSaving] = useState(false)

  useEffect(() => { api.get('/admin/config').then(r => setCats(r.data.data.interestCategories)) }, [])

  const save = async () => {
    setSaving(true)
    try { await api.patch('/admin/config/interestCategories', cats) }
    finally { setSaving(false) }
  }

  if (!cats) return <div className="text-text-muted text-sm">加载中...</div>

  return (
    <div className="space-y-4">
      <p className="text-sm text-text-secondary">§8.9 兴趣培养7大类别名称、说明及各城市tier默认年费。</p>
      <div className="space-y-3">
        {cats.categories.map((cat, i) => (
          <div key={cat.key} className="card p-4 space-y-3">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="text-xs text-text-muted mb-1">类目名称</div>
                <input value={cat.label} onChange={e => setCats(c => ({ categories: c!.categories.map((x, j) => j === i ? { ...x, label: e.target.value } : x) }))}
                  className="input text-sm py-1.5 w-full" />
              </div>
              <div>
                <div className="text-xs text-text-muted mb-1">包含项目说明</div>
                <input value={cat.description} onChange={e => setCats(c => ({ categories: c!.categories.map((x, j) => j === i ? { ...x, description: e.target.value } : x) }))}
                  className="input text-sm py-1.5 w-full" />
              </div>
            </div>
            <div className="flex gap-4">
              {(['1','2','3'] as const).map((tier) => {
                const label = tier === '1' ? '一线' : tier === '2' ? '新一线' : '三线'
                return (
                <div key={tier}>
                  <div className="text-xs text-text-muted mb-1">{label}默认年费(元)</div>
                  <input type="number" value={cat.defaultAnnualCostByTier[tier]}
                    onChange={e => setCats(c => ({ categories: c!.categories.map((x, j) => j === i ? { ...x, defaultAnnualCostByTier: { ...x.defaultAnnualCostByTier, [tier]: Number(e.target.value) } } : x) }))}
                    className="input text-xs py-1 w-24 text-right" />
                </div>
                )
              })}
            </div>
          </div>
        ))}
      </div>
      <button onClick={save} disabled={saving} className="btn-primary px-6 py-2">{saving ? '保存中...' : '保存所有类目'}</button>
    </div>
  )
}

// ── Tab: 产品管理 ─────────────────────────────────────
function ProductsTab() {
  const [products, setProducts] = useState<ProductRecord[]>([])
  const [showForm, setShowForm] = useState(false)
  const [draft, setDraft] = useState<Partial<ProductRecord>>({ scenarioTags: [], minAge: 18, maxAge: 70 })
  const [saving, setSaving] = useState(false)

  useEffect(() => { api.get('/admin/products').then(r => setProducts(r.data.data)) }, [])

  const discontinue = async (id: string) => {
    await api.patch(`/admin/products/${id}/discontinue`, {})
    setProducts(prev => prev.map(p => p.id === id ? { ...p, isActive: false } : p))
  }

  const add = async () => {
    setSaving(true)
    try {
      const res = await api.post('/admin/products', { ...draft, id: `prod_${Date.now()}` })
      setProducts(prev => [...prev, res.data.data])
      setShowForm(false)
      setDraft({ scenarioTags: [], minAge: 18, maxAge: 70 })
    } finally { setSaving(false) }
  }

  const active = products.filter(p => p.isActive !== false)
  const disc = products.filter(p => p.isActive === false)

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <p className="text-sm text-text-secondary">§8.10 在售 {active.length} 个 · 停售 {disc.length} 个</p>
        <button onClick={() => setShowForm(v => !v)} className="btn-primary text-xs px-3 py-1.5 flex items-center gap-1.5">
          <Plus size={13} />新增产品
        </button>
      </div>

      {showForm && (
        <div className="card p-5 space-y-4 border border-accent/30">
          <h3 className="font-medium text-sm">新增产品</h3>
          <div className="grid grid-cols-2 gap-3">
            {[['name','产品名称'],['productType','产品类型']].map(([k,lbl]) => (
              <div key={k}>
                <div className="text-xs text-text-muted mb-1">{lbl}</div>
                <input value={(draft[k as keyof ProductRecord] as string) ?? ''}
                  onChange={e => setDraft(d => ({ ...d, [k]: e.target.value }))}
                  className="input text-sm py-1.5 w-full" />
              </div>
            ))}
            <div className="col-span-2">
              <div className="text-xs text-text-muted mb-1">核心亮点</div>
              <input value={draft.highlights ?? ''} onChange={e => setDraft(d => ({ ...d, highlights: e.target.value }))} className="input text-sm py-1.5 w-full" />
            </div>
            <div>
              <div className="text-xs text-text-muted mb-1">适用年龄</div>
              <div className="flex items-center gap-2">
                <input type="number" value={draft.minAge ?? ''} onChange={e => setDraft(d => ({ ...d, minAge: +e.target.value }))} className="input text-xs py-1 w-14 text-right" />
                <span className="text-xs">~</span>
                <input type="number" value={draft.maxAge ?? ''} onChange={e => setDraft(d => ({ ...d, maxAge: +e.target.value }))} className="input text-xs py-1 w-14 text-right" />
                <span className="text-xs text-text-muted">岁</span>
              </div>
            </div>
            <div>
              <div className="text-xs text-text-muted mb-1">场景标签（逗号分隔）</div>
              <input value={(draft.scenarioTags ?? []).join(',')}
                onChange={e => setDraft(d => ({ ...d, scenarioTags: e.target.value.split(',').map(s => s.trim()).filter(Boolean) }))}
                className="input text-sm py-1.5 w-full" placeholder="pension,education" />
            </div>
          </div>
          <div className="flex gap-2">
            <button onClick={add} disabled={saving || !draft.name} className="btn-primary text-xs px-4 py-1.5">{saving ? '保存中...' : '确认新增'}</button>
            <button onClick={() => setShowForm(false)} className="btn-secondary text-xs px-4 py-1.5">取消</button>
          </div>
        </div>
      )}

      <div className="space-y-2">
        {active.map(p => (
          <div key={p.id} className="card p-4 flex items-start gap-4">
            <div className="flex-1">
              <div className="font-medium text-sm">{p.name}</div>
              <div className="text-xs text-text-secondary mt-0.5">{p.productType} · {p.minAge}~{p.maxAge}岁</div>
              <div className="text-xs text-text-muted mt-1">{p.highlights}</div>
              {p.scenarioTags?.length > 0 && (
                <div className="flex gap-1 mt-2 flex-wrap">
                  {p.scenarioTags.map(t => <span key={t} className="text-xs px-2 py-0.5 rounded-full bg-accent/10 text-accent">{t}</span>)}
                </div>
              )}
            </div>
            <button onClick={() => discontinue(p.id)} className="flex items-center gap-1 text-xs text-text-muted hover:text-accent-danger hover:bg-accent-danger/10 rounded px-2 py-1 transition-colors shrink-0">
              <ToggleLeft size={13} />停售
            </button>
          </div>
        ))}
        {disc.length > 0 && (
          <details className="mt-2">
            <summary className="text-xs text-text-muted cursor-pointer hover:text-text-secondary">已停售产品 ({disc.length})</summary>
            <div className="mt-2 space-y-1">
              {disc.map(p => (
                <div key={p.id} className="card p-3 opacity-50 flex items-center justify-between">
                  <span className="text-sm text-text-secondary line-through">{p.name}</span>
                  <span className="text-xs text-accent-danger">已停售</span>
                </div>
              ))}
            </div>
          </details>
        )}
      </div>
    </div>
  )
}

// ── Tab: 问题反馈 ──────────────────────────────────────
const ISSUE_TYPE_LABELS: Record<string, string> = {
  unknown_product: '未知产品',
  unanswerable_question: '无法回答',
  data_missing: '数据缺失',
}

function IssuesTab() {
  const [items, setItems] = useState<Record<string, unknown>[]>([])
  const [total, setTotal] = useState(0)
  const [filter, setFilter] = useState('')
  const [loading, setLoading] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const params = new URLSearchParams({ limit: '100' })
      if (filter) params.set('type', filter)
      const res = await api.get(`/admin/issues?${params}`)
      setItems(res.data.data.items)
      setTotal(res.data.data.total)
    } catch { /* ignore */ } finally {
      setLoading(false)
    }
  }, [filter])

  useEffect(() => { load() }, [load])

  const markResolved = async (id: number) => {
    await api.patch(`/admin/issues/${id}`)
    setItems(prev => prev.map(i => i.id === id ? { ...i, is_resolved: 1 } : i))
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center gap-2 flex-wrap">
        <span className="text-text-secondary text-sm">共 {total} 条</span>
        <select
          className="text-xs border border-bg-border rounded-lg px-2 py-1.5 bg-bg-float"
          value={filter}
          onChange={e => setFilter(e.target.value)}
        >
          <option value="">全部类型</option>
          <option value="unknown_product">未知产品</option>
          <option value="unanswerable_question">无法回答</option>
          <option value="data_missing">数据缺失</option>
        </select>
        <button onClick={load} className="text-xs text-accent hover:underline">刷新</button>
      </div>

      {loading && <div className="text-text-muted text-sm text-center py-8">加载中…</div>}

      {!loading && items.length === 0 && (
        <div className="text-center py-12 text-text-muted text-sm">暂无问题反馈</div>
      )}

      <div className="space-y-2">
        {items.map((item) => {
          const resolved = Boolean(item.is_resolved)
          return (
            <div
              key={String(item.id)}
              className={`card p-4 ${resolved ? 'opacity-50' : ''}`}
            >
              <div className="flex items-start justify-between gap-3">
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className={`text-xs font-medium px-2 py-0.5 rounded-full ${
                      item.issue_type === 'unknown_product'
                        ? 'bg-accent-warning/10 text-accent-warning'
                        : item.issue_type === 'data_missing'
                        ? 'bg-accent-danger/10 text-accent-danger'
                        : 'bg-accent-purple/10 text-accent-purple'
                    }`}>
                      {ISSUE_TYPE_LABELS[String(item.issue_type)] ?? String(item.issue_type)}
                    </span>
                    <span className="text-xs text-text-muted">
                      {String(item.created_at).slice(0, 16)}
                    </span>
                    {item.profile_id ? (
                      <span className="text-xs text-text-muted">档案 {String(item.profile_id).slice(0, 8)}…</span>
                    ) : null}
                  </div>
                  {item.user_query ? (
                    <p className="text-xs text-text-secondary mb-1">
                      <span className="font-medium text-text-primary">用户问：</span>
                      {String(item.user_query).slice(0, 120)}
                    </p>
                  ) : null}
                  <p className="text-xs text-text-muted">{String(item.description).slice(0, 200)}</p>
                </div>
                {!resolved && (
                  <button
                    onClick={() => markResolved(Number(item.id))}
                    className="shrink-0 text-xs text-accent-success hover:underline flex items-center gap-1"
                  >
                    <Check size={12} /> 标记处理
                  </button>
                )}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

// ── 主组件 ────────────────────────────────────────────
// ── Tab: 精算配置 ────────────────────────────────────────
interface ActuarialConfig {
  productId: string
  mortalityTableM: string
  mortalityTableF: string
  ciTableM: string
  ciTableF: string
  pricingRate: number
  loadingRate: number
  benefitDeath: boolean
  benefitCi: boolean
  benefitMinorCi: boolean
  benefitWaiver: boolean
  benefitMultipleCi: boolean
  sumAssured: number
  premPayPeriod: number
}

const DEFAULT_ACTUARIAL_CONFIG: Omit<ActuarialConfig, 'productId'> = {
  mortalityTableM: 'CL1_1013_M', mortalityTableF: 'CL2_1013_F',
  ciTableM: 'CI25_Male', ciTableF: 'CI25_Female',
  pricingRate: 0.035, loadingRate: 0.25,
  benefitDeath: true, benefitCi: true,
  benefitMinorCi: false, benefitWaiver: false, benefitMultipleCi: false,
  sumAssured: 500000, premPayPeriod: 20,
}

// ActuarialConfigTab replaced by ActuarialWorkbenchTab below
// eslint-disable-next-line @typescript-eslint/no-unused-vars
// @ts-ignore
function _ActuarialConfigTab_UNUSED() {
  const [configs, setConfigs] = useState<ActuarialConfig[]>([])
  const [tables, setTables] = useState<{ mortalityTables: string[]; ciTables: string[] }>({ mortalityTables: [], ciTables: [] })
  const [editing, setEditing] = useState<string | null>(null)
  const [draft, setDraft] = useState<Partial<ActuarialConfig>>({})
  const [isNew, setIsNew] = useState(false)
  const [testResult, setTestResult] = useState<string>('')
  const [saving, setSaving] = useState(false)
  const [loading, setLoading] = useState(false)

  const load = useCallback(async () => {
    setLoading(true)
    try {
      const [cfgRes, tblRes] = await Promise.all([
        api.get('/admin/actuarial/configs'),
        api.get('/admin/actuarial/tables'),
      ])
      setConfigs(cfgRes.data ?? [])
      setTables(tblRes.data ?? { mortalityTables: [], ciTables: [] })
    } catch { /* ignore */ } finally { setLoading(false) }
  }, [])

  useEffect(() => { load() }, [load])

  const startEdit = (c: ActuarialConfig) => { setEditing(c.productId); setDraft({ ...c }); setIsNew(false); setTestResult('') }
  const startNew = () => { setEditing('__new__'); setDraft({ productId: '', ...DEFAULT_ACTUARIAL_CONFIG }); setIsNew(true); setTestResult('') }
  const cancelEdit = () => { setEditing(null); setDraft({}) }

  const saveEdit = async () => {
    setSaving(true)
    try {
      if (isNew) {
        const res = await api.post('/admin/actuarial/configs', draft)
        setConfigs(prev => [...prev, res.data])
      } else {
        const res = await api.put(`/admin/actuarial/configs/${editing}`, draft)
        setConfigs(prev => prev.map(c => c.productId === editing ? res.data : c))
      }
      setEditing(null)
    } catch (e: any) {
      alert('保存失败：' + (e.response?.data?.error ?? e.message))
    } finally { setSaving(false) }
  }

  const deleteConfig = async (productId: string) => {
    if (!confirm(`确认删除产品 ${productId} 的精算配置？`)) return
    await api.delete(`/admin/actuarial/configs/${productId}`)
    setConfigs(prev => prev.filter(c => c.productId !== productId))
  }

  const testFairPrice = async (productId: string) => {
    setTestResult('计算中…')
    try {
      const res = await api.get(`/admin/actuarial/fair-price?productId=${productId}&age=35&gender=male`)
      setTestResult(`35岁男性公允年保费：¥${Number(res.data.fairPremium).toLocaleString('zh-CN', { minimumFractionDigits: 2 })}`)
    } catch {
      setTestResult('计算失败，请检查精算表数据是否已导入')
    }
  }

  const setDraftField = (field: keyof ActuarialConfig, val: unknown) =>
    setDraft(d => ({ ...d, [field]: val }))

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-xs text-text-secondary">配置各产品的精算定价参数，用于计算市场公允保费和性价比评分。</p>
          {tables.mortalityTables.length === 0 && (
            <p className="text-xs text-accent-warning mt-1">⚠️ 精算表数据未导入，请先执行 db/migration/06-actuarial-tables.sql 并导入死亡率数据。</p>
          )}
        </div>
        <button onClick={startNew} className="flex items-center gap-1.5 btn-primary text-xs px-3 py-1.5">
          <Plus size={13} /> 新增配置
        </button>
      </div>

      {loading && <div className="text-center py-8 text-text-muted text-sm">加载中…</div>}

      {editing && (
        <div className="card p-5 space-y-4 border-2 border-accent/30">
          <h3 className="text-sm font-semibold">{isNew ? '新增产品精算配置' : `编辑：${editing}`}</h3>

          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {isNew && (
              <div className="col-span-2 md:col-span-3">
                <label className="text-xs text-text-muted block mb-1">产品ID（cmb_product.product_id）</label>
                <input className="input w-full text-xs" value={draft.productId ?? ''} onChange={e => setDraftField('productId', e.target.value)} placeholder="如 1010003919" />
              </div>
            )}
            <div>
              <label className="text-xs text-text-muted block mb-1">男性死亡率表</label>
              <select className="input w-full text-xs" value={draft.mortalityTableM ?? ''} onChange={e => setDraftField('mortalityTableM', e.target.value)}>
                {(tables.mortalityTables.length ? tables.mortalityTables : ['CL1_1013_M','CL1_0003_M']).map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-text-muted block mb-1">女性死亡率表</label>
              <select className="input w-full text-xs" value={draft.mortalityTableF ?? ''} onChange={e => setDraftField('mortalityTableF', e.target.value)}>
                {(tables.mortalityTables.length ? tables.mortalityTables : ['CL2_1013_F','CL2_0003_F']).map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-text-muted block mb-1">男性重疾发病率表</label>
              <select className="input w-full text-xs" value={draft.ciTableM ?? ''} onChange={e => setDraftField('ciTableM', e.target.value)}>
                {(tables.ciTables.length ? tables.ciTables : ['CI25_Male']).map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-text-muted block mb-1">女性重疾发病率表</label>
              <select className="input w-full text-xs" value={draft.ciTableF ?? ''} onChange={e => setDraftField('ciTableF', e.target.value)}>
                {(tables.ciTables.length ? tables.ciTables : ['CI25_Female']).map(t => <option key={t}>{t}</option>)}
              </select>
            </div>
            <div>
              <label className="text-xs text-text-muted block mb-1">预定利率</label>
              <input type="number" step="0.001" className="input w-full text-xs" value={draft.pricingRate ?? 0.035} onChange={e => setDraftField('pricingRate', +e.target.value)} />
            </div>
            <div>
              <label className="text-xs text-text-muted block mb-1">附加费用率</label>
              <input type="number" step="0.01" className="input w-full text-xs" value={draft.loadingRate ?? 0.25} onChange={e => setDraftField('loadingRate', +e.target.value)} />
            </div>
            <div>
              <label className="text-xs text-text-muted block mb-1">基准保额（元）</label>
              <input type="number" className="input w-full text-xs" value={draft.sumAssured ?? 500000} onChange={e => setDraftField('sumAssured', +e.target.value)} />
            </div>
            <div>
              <label className="text-xs text-text-muted block mb-1">缴费年期（年）</label>
              <input type="number" className="input w-full text-xs" value={draft.premPayPeriod ?? 20} onChange={e => setDraftField('premPayPeriod', +e.target.value)} />
            </div>
          </div>

          <div className="flex flex-wrap gap-4 text-xs">
            {(['benefitDeath','benefitCi','benefitMinorCi','benefitWaiver','benefitMultipleCi'] as const).map(field => (
              <label key={field} className="flex items-center gap-1.5 cursor-pointer">
                <input type="checkbox" checked={Boolean(draft[field])} onChange={e => setDraftField(field, e.target.checked)} className="rounded" />
                {{ benefitDeath:'含身故', benefitCi:'含重疾', benefitMinorCi:'含轻症', benefitWaiver:'含豁免', benefitMultipleCi:'多次重疾' }[field]}
              </label>
            ))}
          </div>

          <div className="flex items-center gap-3">
            <button onClick={saveEdit} disabled={saving} className="btn-primary text-xs px-4 py-1.5 flex items-center gap-1">
              <Check size={13} />{saving ? '保存中…' : '保存'}
            </button>
            <button onClick={cancelEdit} className="text-xs text-text-muted hover:text-text-primary">取消</button>
          </div>
        </div>
      )}

      {testResult && (
        <div className="text-xs text-accent bg-accent/5 border border-accent/20 rounded-lg px-4 py-2">{testResult}</div>
      )}

      {!loading && configs.length === 0 && !editing && (
        <div className="text-center py-12 text-text-muted text-sm">暂无精算配置，点击"新增配置"添加产品</div>
      )}

      <div className="space-y-2">
        {configs.map(c => (
          <div key={c.productId} className="card p-4">
            <div className="flex items-center justify-between gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-sm font-medium">{c.productId}</span>
                  <span className="text-xs text-text-muted">利率 {(c.pricingRate * 100).toFixed(1)}% · 费用率 {(c.loadingRate * 100).toFixed(0)}% · {c.premPayPeriod}年缴</span>
                  <span className="text-xs text-text-muted">{c.mortalityTableM} / {c.ciTableM}</span>
                </div>
                <div className="flex gap-2 mt-1 flex-wrap">
                  {c.benefitDeath && <span className="text-xs bg-bg-float px-1.5 py-0.5 rounded">身故</span>}
                  {c.benefitCi && <span className="text-xs bg-bg-float px-1.5 py-0.5 rounded">重疾</span>}
                  {c.benefitMinorCi && <span className="text-xs bg-bg-float px-1.5 py-0.5 rounded">轻症</span>}
                  {c.benefitWaiver && <span className="text-xs bg-bg-float px-1.5 py-0.5 rounded">豁免</span>}
                  {c.benefitMultipleCi && <span className="text-xs bg-bg-float px-1.5 py-0.5 rounded">多次重疾</span>}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button onClick={() => { setTestResult(''); testFairPrice(c.productId) }} className="text-xs text-accent hover:underline">测试定价</button>
                <button onClick={() => startEdit(c)} className="p-1 text-text-muted hover:text-accent rounded"><Edit2 size={13} /></button>
                <button onClick={() => deleteConfig(c.productId)} className="p-1 text-text-muted hover:text-accent-danger rounded"><X size={13} /></button>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

// ── Tab: 精算计算器 ──────────────────────────────────────────────────────────

interface CalcForm {
  label:           string
  issueAge:        number
  gender:          'male' | 'female'
  actualPremium:   number
  pricingRate:     number
  loadingRate:     number
  premPayPeriod:   number
  sumAssured:      number
  maxAge:          number
  benefitDeath:    boolean
  benefitCi:       boolean
  // 精算率来源
  rateMode:        'constant' | 'table'
  qdConstant:      number
  qciConstant:     number
  mortalityTableName: string
  ciTableName:     string
}

interface CalcResult {
  fairPremium:   number | null
  breakdown:     { pvfb: number; annuityDue: number; pvLoading: number; denominator: number; gp_calc: string }
  inputParams:   Record<string, unknown>
  yearlyDetail:  Array<{ age: number; t: number; px: number; qd: number; qci: number; pvfbT: number; annT: number }>
  error?:        string
}

function valueScore(ratio: number): { score: number; label: string; color: string } {
  if (ratio <= 0.90) return { score: 20,                                  label: `低于公允价 ${((1-ratio)*100).toFixed(0)}%，性价比满分`, color: 'text-green-600' }
  if (ratio <= 1.00) return { score: +(20 - (ratio-0.90)/0.10*8).toFixed(1), label: `低于公允价 ${((1-ratio)*100).toFixed(1)}%`,             color: 'text-green-500' }
  if (ratio <= 1.20) return { score: +Math.max(0, 12-(ratio-1.00)/0.20*12).toFixed(1), label: `高于公允价 ${((ratio-1)*100).toFixed(1)}%`, color: 'text-orange-500' }
  return { score: 0, label: `高于公允价 ${((ratio-1)*100).toFixed(0)}%，性价比不足`, color: 'text-red-500' }
}

const DEFAULT_FORM: CalcForm = {
  label: '测试重疾险', issueAge: 35, gender: 'male', actualPremium: 7800,
  pricingRate: 0.035, loadingRate: 0.25, premPayPeriod: 20, sumAssured: 500000, maxAge: 105,
  benefitDeath: true, benefitCi: true,
  rateMode: 'constant', qdConstant: 0.002, qciConstant: 0.003,
  mortalityTableName: 'CL1_1013_M', ciTableName: 'CI25_Male',
}

/** 合并精算工作台：计算器 + 产品配置管理 */
function ActuarialWorkbenchTab() {
  // ── 计算器状态 ──
  const [form, setForm] = useState<CalcForm>({ ...DEFAULT_FORM })
  const [result, setResult] = useState<CalcResult | null>(null)
  const [loading, setLoading] = useState(false)
  const [err, setErr] = useState('')
  const [showDetail, setShowDetail] = useState(false)

  // ── 产品配置状态 ──
  const [configs, setConfigs] = useState<ActuarialConfig[]>([])
  const [tables, setTables] = useState<{ mortalityTables: string[]; ciTables: string[] }>({ mortalityTables: [], ciTables: [] })
  const [editing, setEditing] = useState<string | null>(null)
  const [draft, setDraft] = useState<Partial<ActuarialConfig>>({})
  const [isNew, setIsNew] = useState(false)
  const [cfgSaving, setCfgSaving] = useState(false)
  const [cfgLoading, setCfgLoading] = useState(false)

  const calcRef = useRef<HTMLDivElement>(null)

  // 加载产品配置和精算表
  const loadConfigs = useCallback(async () => {
    setCfgLoading(true)
    try {
      const [cfgRes, tblRes] = await Promise.all([
        api.get('/admin/actuarial/configs'),
        api.get('/admin/actuarial/tables'),
      ])
      setConfigs(cfgRes.data ?? [])
      setTables(tblRes.data ?? { mortalityTables: [], ciTables: [] })
    } catch { /* ignore */ } finally { setCfgLoading(false) }
  }, [])

  useEffect(() => { loadConfigs() }, [loadConfigs])

  // 加载产品配置参数到计算器
  const loadToCalculator = (c: ActuarialConfig) => {
    setForm(f => ({
      ...f,
      label:              c.productId,
      pricingRate:        c.pricingRate,
      loadingRate:        c.loadingRate,
      premPayPeriod:      c.premPayPeriod,
      sumAssured:         c.sumAssured,
      benefitDeath:       c.benefitDeath,
      benefitCi:          c.benefitCi,
      rateMode:           'table',
      mortalityTableName: f.gender === 'male' ? c.mortalityTableM : c.mortalityTableF,
      ciTableName:        f.gender === 'male' ? c.ciTableM        : c.ciTableF,
    }))
    setResult(null)
    calcRef.current?.scrollIntoView({ behavior: 'smooth' })
  }

  const set = <K extends keyof CalcForm>(k: K, v: CalcForm[K]) =>
    setForm(f => ({ ...f, [k]: v }))

  // ── 产品配置 CRUD ──
  const startNew = () => { setEditing('__new__'); setDraft({ productId: '', ...DEFAULT_ACTUARIAL_CONFIG }); setIsNew(true) }
  const cancelEdit = () => { setEditing(null); setDraft({}) }
  const setDraftField = (field: keyof ActuarialConfig, val: unknown) =>
    setDraft(d => ({ ...d, [field]: val }))

  const saveConfig = async () => {
    setCfgSaving(true)
    try {
      if (isNew) {
        const res = await api.post('/admin/actuarial/configs', draft)
        setConfigs(prev => [...prev, res.data])
      } else {
        const res = await api.put(`/admin/actuarial/configs/${editing}`, draft)
        setConfigs(prev => prev.map(c => c.productId === editing ? res.data : c))
      }
      setEditing(null)
    } catch (e: any) {
      alert('保存失败：' + (e.response?.data?.error ?? e.message))
    } finally { setCfgSaving(false) }
  }

  const deleteConfig = async (productId: string) => {
    if (!confirm(`确认删除 ${productId} 的精算配置？`)) return
    await api.delete(`/admin/actuarial/configs/${productId}`)
    setConfigs(prev => prev.filter(c => c.productId !== productId))
  }

  // ── 计算器 ──
  const calculate = async () => {
    setLoading(true); setErr(''); setResult(null)
    try {
      const body: Record<string, unknown> = {
        issueAge:      form.issueAge,
        gender:        form.gender,
        pricingRate:   form.pricingRate,
        loadingRate:   form.loadingRate,
        premPayPeriod: form.premPayPeriod,
        sumAssured:    form.sumAssured,
        maxAge:        form.maxAge,
        benefitDeath:  form.benefitDeath,
        benefitCi:     form.benefitCi,
      }
      if (form.rateMode === 'table') {
        body.mortalityTableName = form.mortalityTableName
        body.ciTableName        = form.ciTableName
      } else {
        body.qdConstant  = form.qdConstant
        body.qciConstant = form.qciConstant
      }
      const res = await api.post('/admin/actuarial/calculate', body)
      setResult(res.data)
    } catch (e: any) {
      setErr(e.response?.data?.error ?? e.message ?? '计算失败')
    } finally { setLoading(false) }
  }

  const ratio = result?.fairPremium && result.fairPremium > 0 && form.actualPremium > 0
    ? form.actualPremium / result.fairPremium : null
  const vs = ratio !== null ? valueScore(ratio) : null

  return (
    <div className="space-y-6">
      {/* 页头 */}
      <div ref={calcRef}>
        <p className="text-[11px] uppercase tracking-widest text-text-muted mb-1">AIX Pricing Prototype</p>
        <h2 className="text-xl font-bold text-text-primary">精算定价工作台</h2>
        <p className="text-sm text-text-secondary mt-1">
          手动输入精算参数验证公式 · 管理产品精算配置 · 一键加载产品参数到计算器
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        {/* ── 左栏：输入 ───────────────────────────────── */}
        <div className="card p-6 space-y-5">
          {/* 基础信息 */}
          <div>
            <label className="text-xs font-medium text-text-muted block mb-1">测试名称（仅用于显示）</label>
            <input className="input w-full" value={form.label} onChange={e => set('label', e.target.value)} placeholder="如：测试重疾险A" />
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-medium text-text-muted block mb-1">投保年龄</label>
              <input type="number" min={1} max={99} className="input w-full"
                value={form.issueAge} onChange={e => set('issueAge', +e.target.value)} />
            </div>
            <div>
              <label className="text-xs font-medium text-text-muted block mb-1">性别</label>
              <select className="input w-full" value={form.gender} onChange={e => set('gender', e.target.value as 'male' | 'female')}>
                <option value="male">男</option>
                <option value="female">女</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-medium text-text-muted block mb-1">最高保障年龄</label>
              <input type="number" min={60} max={120} className="input w-full"
                value={form.maxAge} onChange={e => set('maxAge', +e.target.value)} />
            </div>
          </div>

          <div>
            <label className="text-xs font-medium text-text-muted block mb-1">保险公司实际年保费（元）</label>
            <input type="number" min={0} className="input w-full"
              value={form.actualPremium} onChange={e => set('actualPremium', +e.target.value)}
              placeholder="输入市场实际年保费，用于计算性价比" />
          </div>

          {/* 精算参数 */}
          <div className="border-t border-black/[0.06] pt-4">
            <p className="text-xs font-semibold text-text-muted mb-3">精算参数</p>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-text-muted block mb-1">预定利率</label>
                <div className="flex items-center gap-1">
                  <input type="number" step="0.001" min="0.01" max="0.2" className="input w-full"
                    value={form.pricingRate} onChange={e => set('pricingRate', +e.target.value)} />
                  <span className="text-xs text-text-muted shrink-0">
                    {(form.pricingRate * 100).toFixed(1)}%
                  </span>
                </div>
              </div>
              <div>
                <label className="text-xs text-text-muted block mb-1">附加费用率</label>
                <div className="flex items-center gap-1">
                  <input type="number" step="0.01" min="0" max="0.5" className="input w-full"
                    value={form.loadingRate} onChange={e => set('loadingRate', +e.target.value)} />
                  <span className="text-xs text-text-muted shrink-0">
                    {(form.loadingRate * 100).toFixed(0)}%
                  </span>
                </div>
              </div>
              <div>
                <label className="text-xs text-text-muted block mb-1">缴费年期（年）</label>
                <input type="number" min={1} max={40} className="input w-full"
                  value={form.premPayPeriod} onChange={e => set('premPayPeriod', +e.target.value)} />
              </div>
              <div>
                <label className="text-xs text-text-muted block mb-1">保额（元）</label>
                <input type="number" step={10000} min={10000} className="input w-full"
                  value={form.sumAssured} onChange={e => set('sumAssured', +e.target.value)} />
              </div>
            </div>
          </div>

          {/* 精算率来源 */}
          <div className="border-t border-black/[0.06] pt-4">
            <div className="flex items-center gap-4 mb-3">
              <p className="text-xs font-semibold text-text-muted">精算率来源</p>
              <div className="flex gap-3 text-xs">
                {(['constant','table'] as const).map(m => (
                  <label key={m} className="flex items-center gap-1 cursor-pointer">
                    <input type="radio" checked={form.rateMode === m} onChange={() => set('rateMode', m)} />
                    {m === 'constant' ? '常数率（快速测试）' : '精算表（DB）'}
                  </label>
                ))}
              </div>
            </div>

            {form.rateMode === 'constant' ? (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-text-muted block mb-1">死亡率（qd，常数）</label>
                  <input type="number" step="0.0001" min="0" max="0.1" className="input w-full"
                    value={form.qdConstant} onChange={e => set('qdConstant', +e.target.value)} />
                  <p className="text-[10px] text-text-muted mt-0.5">如 0.002 = 每年0.2%</p>
                </div>
                <div>
                  <label className="text-xs text-text-muted block mb-1">重疾发病率（qci，常数）</label>
                  <input type="number" step="0.0001" min="0" max="0.1" className="input w-full"
                    value={form.qciConstant} onChange={e => set('qciConstant', +e.target.value)} />
                  <p className="text-[10px] text-text-muted mt-0.5">如 0.003 = 每年0.3%</p>
                </div>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="text-xs text-text-muted block mb-1">死亡率表名</label>
                  {tables.mortalityTables.length > 0 ? (
                    <select className="input w-full" value={form.mortalityTableName}
                      onChange={e => set('mortalityTableName', e.target.value)}>
                      {tables.mortalityTables.map(t => <option key={t}>{t}</option>)}
                    </select>
                  ) : (
                    <input className="input w-full" value={form.mortalityTableName}
                      onChange={e => set('mortalityTableName', e.target.value)} placeholder="CL1_1013_M" />
                  )}
                </div>
                <div>
                  <label className="text-xs text-text-muted block mb-1">重疾发病率表名</label>
                  {tables.ciTables.length > 0 ? (
                    <select className="input w-full" value={form.ciTableName}
                      onChange={e => set('ciTableName', e.target.value)}>
                      {tables.ciTables.map(t => <option key={t}>{t}</option>)}
                    </select>
                  ) : (
                    <input className="input w-full" value={form.ciTableName}
                      onChange={e => set('ciTableName', e.target.value)} placeholder="CI25_Male" />
                  )}
                </div>
                {tables.mortalityTables.length === 0 && (
                  <p className="col-span-2 text-[10px] text-orange-500">精算表数据未导入，请先执行 06-actuarial-tables.sql</p>
                )}
              </div>
            )}
          </div>

          {/* 责任项 */}
          <div className="flex gap-4 text-xs">
            {(['benefitDeath','benefitCi'] as const).map(f => (
              <label key={f} className="flex items-center gap-1.5 cursor-pointer">
                <input type="checkbox" checked={form[f]} onChange={e => set(f, e.target.checked)} />
                {{ benefitDeath: '含身故责任', benefitCi: '含重疾责任' }[f]}
              </label>
            ))}
          </div>

          {err && <p className="text-xs text-red-500 bg-red-50 rounded-lg px-3 py-2">{err}</p>}

          <button
            onClick={calculate} disabled={loading}
            className="w-full btn-primary py-2.5 text-sm font-medium disabled:opacity-50"
          >
            {loading ? '计算中…' : '计算公允定价'}
          </button>
        </div>

        {/* ── 右栏：结果 ───────────────────────────────── */}
        <div className={`card p-6 transition-opacity ${result ? 'opacity-100' : 'opacity-40 pointer-events-none'}`}>
          {!result ? (
            <div className="flex flex-col items-center justify-center h-full text-text-muted text-sm gap-2 py-20">
              <p>填写左侧参数后点击"计算公允定价"</p>
              <p className="text-xs">结果将在此显示</p>
            </div>
          ) : (
            <div className="space-y-5">
              <h3 className="text-base font-bold text-text-primary">结果概览</h3>

              {/* 产品名 + 核心数字 */}
              <div className="space-y-2">
                <p className="text-sm font-semibold text-accent">{form.label}</p>

                <div className="grid grid-cols-2 gap-x-6 gap-y-2 text-sm">
                  <div>
                    <span className="text-text-muted text-xs">公允年保费</span>
                    <p className="font-bold text-text-primary">
                      {result.fairPremium != null
                        ? `${result.fairPremium.toLocaleString('zh-CN', { minimumFractionDigits: 2 })} 元`
                        : '—'}
                    </p>
                  </div>
                  <div>
                    <span className="text-text-muted text-xs">实际年保费</span>
                    <p className="font-bold text-text-primary">
                      {form.actualPremium > 0 ? `${form.actualPremium.toLocaleString('zh-CN', { minimumFractionDigits: 2 })} 元` : '未填写'}
                    </p>
                  </div>
                  {ratio !== null && (
                    <>
                      <div>
                        <span className="text-text-muted text-xs">定价比值</span>
                        <p className="font-bold text-text-primary">{(ratio * 100).toFixed(2)}%</p>
                      </div>
                      <div>
                        <span className="text-text-muted text-xs">性价比得分</span>
                        <p className={`font-bold ${vs?.color}`}>{vs?.score} 分</p>
                      </div>
                    </>
                  )}
                </div>

                {vs && (
                  <p className={`text-xs ${vs.color} bg-opacity-10 rounded-lg px-3 py-1.5 border ${vs.score >= 15 ? 'border-green-200 bg-green-50' : vs.score >= 5 ? 'border-orange-200 bg-orange-50' : 'border-red-200 bg-red-50'}`}>
                    说明：{vs.label}
                  </p>
                )}
              </div>

              {/* 计算拆解 */}
              <div className="border-t border-black/[0.06] pt-4 space-y-1.5 text-xs text-text-secondary">
                {result.breakdown && (
                  <>
                    <p>
                      <span className="font-medium text-text-primary">责任成本 PVFB：</span>
                      {result.breakdown.pvfb.toLocaleString('zh-CN', { minimumFractionDigits: 2 })} 元
                    </p>
                    <p>
                      <span className="font-medium text-text-primary">缴费年金 AnnuityDue：</span>
                      {result.breakdown.annuityDue.toFixed(4)}
                    </p>
                    <p>
                      <span className="font-medium text-text-primary">费用现值 PV_Loading：</span>
                      {result.breakdown.pvLoading.toFixed(4)}
                    </p>
                    <p>
                      <span className="font-medium text-text-primary">计算式：</span>
                      {result.breakdown.gp_calc}
                    </p>
                  </>
                )}
              </div>

              {/* 参数摘要 */}
              <div className="border-t border-black/[0.06] pt-3 text-xs text-text-muted space-y-0.5">
                <p>精算参数：利率 {((result.inputParams?.pricingRate as number) * 100).toFixed(1)}%，费用率 {((result.inputParams?.loadingRate as number) * 100).toFixed(0)}%</p>
                <p>精算率来源：{form.rateMode === 'table'
                  ? `${form.mortalityTableName} / ${form.ciTableName}`
                  : `死亡率常数 ${form.qdConstant} / 重疾率常数 ${form.qciConstant}`}
                </p>
                <p>保障年限：{(form.maxAge - form.issueAge)} 年，缴费期：{form.premPayPeriod} 年，保额：{form.sumAssured.toLocaleString()} 元</p>
              </div>

              {/* 逐年明细（可展开） */}
              {result.yearlyDetail?.length > 0 && (
                <div className="border-t border-black/[0.06] pt-3">
                  <button onClick={() => setShowDetail(v => !v)}
                    className="text-xs text-accent hover:underline flex items-center gap-1">
                    {showDetail ? <ChevronUp size={12} /> : <ChevronDown size={12} />}
                    {showDetail ? '收起' : '查看'}逐年明细（前30年 + 末5年）
                  </button>
                  {showDetail && (
                    <div className="mt-2 overflow-x-auto">
                      <table className="text-[10px] w-full border-collapse">
                        <thead>
                          <tr className="text-text-muted border-b border-black/[0.08]">
                            {['年龄','第t年','生存概率px','死亡率qd','重疾率qci','PVFB贡献','年金贡献'].map(h => (
                              <th key={h} className="text-right py-1 pr-2 font-medium">{h}</th>
                            ))}
                          </tr>
                        </thead>
                        <tbody>
                          {result.yearlyDetail.map((row, i) => (
                            <tr key={i} className="border-b border-black/[0.04] hover:bg-bg-float">
                              <td className="py-0.5 pr-2 text-right">{row.age}</td>
                              <td className="py-0.5 pr-2 text-right">{row.t}</td>
                              <td className="py-0.5 pr-2 text-right">{row.px.toFixed(4)}</td>
                              <td className="py-0.5 pr-2 text-right">{(row.qd * 1000).toFixed(2)}‰</td>
                              <td className="py-0.5 pr-2 text-right">{(row.qci * 1000).toFixed(2)}‰</td>
                              <td className="py-0.5 pr-2 text-right">{row.pvfbT.toFixed(2)}</td>
                              <td className="py-0.5 pr-2 text-right">{row.annT.toFixed(4)}</td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  )}
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* 说明 */}
      <div className="card p-5">
        <h4 className="text-sm font-semibold mb-2">公式说明</h4>
        <div className="text-xs text-text-secondary space-y-1 leading-relaxed">
          <p>• <b>常数率模式</b>：固定死亡率/重疾率填充所有年龄，快速验证公式逻辑，无需导入数据。</p>
          <p>• <b>精算表模式</b>：从数据库读取标准生命表（需先执行 06-actuarial-tables.sql 并导入数据）。</p>
          <p>• <b>公允保费公式</b>：GP = PVFB ÷ (AnnuityDue − PV_Loading)，PVFB 为死亡+重疾赔付精算现值。</p>
          <p>• <b>性价比评分</b>：实际/公允 ≤90% → 满分20；=100% → 基准12分；≥120% → 0分。</p>
        </div>
      </div>

      {/* ── 产品精算配置管理 ─────────────────────────── */}
      <div className="border-t-2 border-black/[0.06] pt-6">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h3 className="text-base font-bold">产品精算配置</h3>
            <p className="text-xs text-text-secondary mt-0.5">配置产品精算参数后，可一键加载到上方计算器进行测试。</p>
          </div>
          <button onClick={startNew} className="flex items-center gap-1.5 btn-primary text-xs px-3 py-1.5">
            <Plus size={13} /> 新增配置
          </button>
        </div>

        {cfgLoading && <div className="text-center py-6 text-text-muted text-sm">加载中…</div>}

        {/* 编辑/新增表单 */}
        {editing && (
          <div className="card p-5 space-y-4 border-2 border-accent/30 mb-4">
            <h4 className="text-sm font-semibold">{isNew ? '新增产品精算配置' : `编辑：${editing}`}</h4>

            <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
              {isNew && (
                <div className="col-span-2 md:col-span-3">
                  <label className="text-xs text-text-muted block mb-1">产品ID（cmb_product.product_id）</label>
                  <input className="input w-full text-xs" value={draft.productId ?? ''}
                    onChange={e => setDraftField('productId', e.target.value)} placeholder="如 1010003919" />
                </div>
              )}
              {[
                { key: 'mortalityTableM', label: '男性死亡率表', opts: tables.mortalityTables.length ? tables.mortalityTables : ['CL1_1013_M'] },
                { key: 'mortalityTableF', label: '女性死亡率表', opts: tables.mortalityTables.length ? tables.mortalityTables : ['CL2_1013_F'] },
                { key: 'ciTableM',        label: '男性重疾表',   opts: tables.ciTables.length ? tables.ciTables : ['CI25_Male'] },
                { key: 'ciTableF',        label: '女性重疾表',   opts: tables.ciTables.length ? tables.ciTables : ['CI25_Female'] },
              ].map(({ key, label, opts }) => (
                <div key={key}>
                  <label className="text-xs text-text-muted block mb-1">{label}</label>
                  <select className="input w-full text-xs"
                    value={(draft as Record<string, string>)[key] ?? ''}
                    onChange={e => setDraftField(key as keyof ActuarialConfig, e.target.value)}>
                    {opts.map(t => <option key={t}>{t}</option>)}
                  </select>
                </div>
              ))}
              <div>
                <label className="text-xs text-text-muted block mb-1">预定利率</label>
                <input type="number" step="0.001" className="input w-full text-xs"
                  value={draft.pricingRate ?? 0.035} onChange={e => setDraftField('pricingRate', +e.target.value)} />
              </div>
              <div>
                <label className="text-xs text-text-muted block mb-1">附加费用率</label>
                <input type="number" step="0.01" className="input w-full text-xs"
                  value={draft.loadingRate ?? 0.25} onChange={e => setDraftField('loadingRate', +e.target.value)} />
              </div>
              <div>
                <label className="text-xs text-text-muted block mb-1">基准保额（元）</label>
                <input type="number" className="input w-full text-xs"
                  value={draft.sumAssured ?? 500000} onChange={e => setDraftField('sumAssured', +e.target.value)} />
              </div>
              <div>
                <label className="text-xs text-text-muted block mb-1">缴费年期（年）</label>
                <input type="number" className="input w-full text-xs"
                  value={draft.premPayPeriod ?? 20} onChange={e => setDraftField('premPayPeriod', +e.target.value)} />
              </div>
            </div>

            <div className="flex flex-wrap gap-4 text-xs">
              {(['benefitDeath','benefitCi','benefitMinorCi','benefitWaiver','benefitMultipleCi'] as const).map(field => (
                <label key={field} className="flex items-center gap-1.5 cursor-pointer">
                  <input type="checkbox" checked={Boolean(draft[field])}
                    onChange={e => setDraftField(field, e.target.checked)} />
                  {{ benefitDeath:'含身故', benefitCi:'含重疾', benefitMinorCi:'含轻症', benefitWaiver:'含豁免', benefitMultipleCi:'多次重疾' }[field]}
                </label>
              ))}
            </div>

            <div className="flex items-center gap-3">
              <button onClick={saveConfig} disabled={cfgSaving}
                className="btn-primary text-xs px-4 py-1.5 flex items-center gap-1">
                <Check size={13} />{cfgSaving ? '保存中…' : '保存'}
              </button>
              <button onClick={cancelEdit} className="text-xs text-text-muted hover:text-text-primary">取消</button>
            </div>
          </div>
        )}

        {!cfgLoading && configs.length === 0 && !editing && (
          <div className="text-center py-10 text-text-muted text-sm">
            暂无精算配置，点击"新增配置"添加产品
          </div>
        )}

        <div className="space-y-2">
          {configs.map(c => (
            <div key={c.productId} className="card p-4 flex items-center gap-3">
              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="font-mono text-sm font-medium">{c.productId}</span>
                  <span className="text-xs text-text-muted">
                    利率 {(c.pricingRate*100).toFixed(1)}% · 费用率 {(c.loadingRate*100).toFixed(0)}% · {c.premPayPeriod}年缴 · {c.sumAssured.toLocaleString()}元
                  </span>
                </div>
                <div className="flex gap-1.5 mt-1 flex-wrap">
                  <span className="text-[10px] text-text-muted">{c.mortalityTableM} / {c.ciTableM}</span>
                  {c.benefitDeath && <span className="text-[10px] bg-bg-float px-1.5 py-0.5 rounded">身故</span>}
                  {c.benefitCi    && <span className="text-[10px] bg-bg-float px-1.5 py-0.5 rounded">重疾</span>}
                  {c.benefitMinorCi && <span className="text-[10px] bg-bg-float px-1.5 py-0.5 rounded">轻症</span>}
                </div>
              </div>
              <div className="flex items-center gap-2 shrink-0">
                <button
                  onClick={() => loadToCalculator(c)}
                  className="text-xs text-white bg-accent hover:bg-accent-light px-2.5 py-1 rounded-lg transition-colors"
                  title="将此产品的精算参数加载到上方计算器"
                >
                  加载到计算器 ↑
                </button>
                <button onClick={() => { setEditing(c.productId); setDraft({ ...c }); setIsNew(false) }}
                  className="p-1 text-text-muted hover:text-accent rounded"><Edit2 size={13} /></button>
                <button onClick={() => deleteConfig(c.productId)}
                  className="p-1 text-text-muted hover:text-accent-danger rounded"><X size={13} /></button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}

export default function AdminPanel() {
  const [tab, setTab] = useState<'cities' | 'domestic' | 'overseas' | 'config' | 'interests' | 'products' | 'issues' | 'actuarial'>('cities')

  const tabs = [
    { key: 'cities' as const,    label: '城市社保',   icon: <MapPin size={14} /> },
    { key: 'domestic' as const,  label: '国内学校',   icon: <GraduationCap size={14} /> },
    { key: 'overseas' as const,  label: '海外院校',   icon: <Globe size={14} /> },
    { key: 'config' as const,    label: '系统参数',   icon: <Settings size={14} /> },
    { key: 'interests' as const, label: '兴趣类目',   icon: <Database size={14} /> },
    { key: 'products' as const,  label: '产品管理',   icon: <Package size={14} /> },
    { key: 'issues' as const,    label: '问题反馈',   icon: <AlertCircle size={14} /> },
    { key: 'actuarial' as const, label: '精算工作台', icon: <Database size={14} /> },
  ]

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold">数据管理后台</h1>
        <p className="text-text-secondary text-sm mt-1">城市社保参数 · 国内外学校数据库 · 系统精算参数 · 产品库 · AI问题反馈 · 精算定价工作台</p>
      </div>

      <div className="flex gap-1 flex-wrap bg-bg-float rounded-xl p-1.5">
        {tabs.map(t => <TabBtn key={t.key} label={t.label} icon={t.icon} active={tab === t.key} onClick={() => setTab(t.key)} />)}
      </div>

      <div>
        {tab === 'cities'    && <CitiesTab />}
        {tab === 'domestic'  && <DomesticSchoolsTab />}
        {tab === 'overseas'  && <OverseasSchoolsTab />}
        {tab === 'config'    && <SystemConfigTab />}
        {tab === 'interests' && <InterestCategoriesTab />}
        {tab === 'products'  && <ProductsTab />}
        {tab === 'issues'    && <IssuesTab />}
        {tab === 'actuarial' && <ActuarialWorkbenchTab />}
      </div>
    </div>
  )
}
