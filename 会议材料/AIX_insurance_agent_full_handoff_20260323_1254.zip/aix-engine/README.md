# AIX 保险智能测算引擎

微服务架构：Nginx + Node.js BFF + Java Spring Boot 精算服务 + Python FastAPI AI服务 + MySQL 8 + RabbitMQ

## 快速启动

```bash
# 1. 配置环境变量
cp .env.example .env
# 编辑 .env，填入 KIMI_API_KEY

# 2. 一键启动全部服务
docker compose up --build -d

# 3. 访问
# 前端：http://localhost
# RabbitMQ管理：http://localhost:15672 (guest/guest)
```

## 环境变量 (.env)

| 变量 | 说明 | 默认值 |
|------|------|--------|
| `MYSQL_ROOT_PASSWORD` | MySQL root密码 | `root_secret` |
| `MYSQL_PASSWORD` | MySQL应用密码 | `aix_secret` |
| `KIMI_API_KEY` | 月之暗面 Kimi API Key | 必填 |

## 服务架构

```
Nginx :80  →  BFF :3001  →  Java精算 :8080
                          →  Python AI :8000
                          →  MySQL :3306
                          →  RabbitMQ :5672
```

| 服务 | 技术栈 | 职责 |
|------|--------|------|
| `nginx` | Nginx Alpine | 反向代理、静态文件、SSE流配置 |
| `bff` | Node.js + Express + TypeScript | API聚合、Session/Profile CRUD、SSE透传 |
| `actuarial` | Java 17 + Spring Boot 3 | 养老/教育/保障精算计算、产品规则引擎 |
| `ai` | Python + FastAPI | Kimi AI报告生成、对话（SSE流式） |
| `mysql` | MySQL 8.0 | 配置数据、客户档案、会话存储 |
| `rabbitmq` | RabbitMQ 3 | 异步任务队列 |

## 目录结构

```
aix-engine/
├── aix-bff/                 # Node.js BFF
│   ├── src/routes/          # API路由（与前端契约一致）
│   ├── src/proxy/           # Java/Python代理客户端
│   ├── src/db/              # MySQL连接、Profile/Session存储
│   └── data/schools/        # 学校数据JSON
├── aix-actuarial-service/   # Java Spring Boot 精算服务
│   └── src/main/java/com/aix/actuarial/
│       ├── controller/      # REST控制器
│       ├── service/         # 计算服务
│       └── config/          # 配置读取 + 缓存
├── aix-ai-service/          # Python FastAPI AI服务
│   └── app/
│       ├── routers/         # 报告生成/对话端点
│       └── services/        # Kimi客户端、提示词构建
├── frontend/                # React + TypeScript + Tailwind
│   └── src/
│       ├── modules/         # 7个业务模块
│       ├── admin/           # 数据管理后台
│       └── api/             # 接口调用层
├── nginx/                   # Nginx配置
├── db/init/                 # MySQL建表 + 种子数据
├── docker-compose.yml
└── .env
```

## 常用命令

```bash
docker compose up --build -d    # 构建并启动
docker compose down              # 停止
docker compose down -v           # 停止并清除数据
docker compose logs -f bff       # 查看BFF日志
docker compose logs -f actuarial # 查看精算服务日志
docker compose logs -f ai        # 查看AI服务日志
```
