#!/usr/bin/env node
/**
 * gen-actuarial-sql.js
 * 从 docs/actuarial-data.js 生成 db/migration/07-actuarial-data.sql
 *
 * 用法：node scripts/gen-actuarial-sql.js
 */

const fs   = require('fs');
const path = require('path');

// ── 加载精算数据 ─────────────────────────────────────────────────────────────
const dataFile = path.join(__dirname, '../docs/actuarial-data.js');
const raw      = fs.readFileSync(dataFile, 'utf8');

// 用 Function 构造器代替全局 eval，避免 lint 警告；数据文件可信
const sandbox = new Function(raw + '\nreturn { MORTALITY, CI_AGG };')();
const { MORTALITY, CI_AGG } = sandbox;

if (!MORTALITY || !CI_AGG) {
  console.error('未能从 actuarial-data.js 中提取 MORTALITY / CI_AGG，请检查文件格式');
  process.exit(1);
}

// ── 生成 SQL ─────────────────────────────────────────────────────────────────
const lines = [
  '-- ============================================================',
  '-- 07-actuarial-data.sql',
  '-- 由 scripts/gen-actuarial-sql.js 自动生成',
  '-- 数据源：docs/actuarial-data.js（从 保险产品定价20200923.xlsm 提取）',
  '-- 导入目标库：aix_engine',
  '-- 导入命令：',
  '--   docker compose exec mysql \\',
  "--     mysql -u aix -p aix_engine < db/migration/07-actuarial-data.sql",
  '-- ============================================================',
  '',
  'USE aix_engine;',
  '',
  '-- 幂等：先清空再插入，避免重复执行报主键冲突',
  "DELETE FROM actuarial_qx_table WHERE table_name IN ('CL1_1013_M', 'CL2_1013_F');",
  "DELETE FROM actuarial_ci_table  WHERE table_name IN ('CI25_Male',  'CI25_Female');",
  '',
];

// ── actuarial_qx_table（死亡率） ──────────────────────────────────────────────
lines.push('-- ========== actuarial_qx_table：死亡率 ==========');
lines.push('-- CL1_1013_M = 2013年中国人身保险业经验生命表（男）');
lines.push('-- CL2_1013_F = 2013年中国人身保险业经验生命表（女）');
lines.push(`-- 行数：${MORTALITY.male.length * 2} 行（男/女各 ${MORTALITY.male.length} 行，age 0~${MORTALITY.male.length - 1}）`);
lines.push('');

const qxRows = [];
MORTALITY.male.forEach((qx, age) => {
  qxRows.push(`('CL1_1013_M', ${age}, ${qx.toFixed(10)})`);
});
MORTALITY.female.forEach((qx, age) => {
  qxRows.push(`('CL2_1013_F', ${age}, ${qx.toFixed(10)})`);
});

lines.push('INSERT INTO actuarial_qx_table (table_name, age, qx) VALUES');
lines.push(qxRows.map((r, i) => (i < qxRows.length - 1 ? `  ${r},` : `  ${r}`)).join('\n'));
lines.push(';');
lines.push('');

// ── actuarial_ci_table（重疾发病率） ──────────────────────────────────────────
lines.push('-- ========== actuarial_ci_table：重疾发病率 ==========');
lines.push('-- CI25_Male   = 25种重疾合计发病率（男）');
lines.push('-- CI25_Female = 25种重疾合计发病率（女）');
lines.push(`-- 行数：${CI_AGG.male.length * 2} 行（男/女各 ${CI_AGG.male.length} 行，age 0~${CI_AGG.male.length - 1}）`);
lines.push('');

const ciRows = [];
CI_AGG.male.forEach((qx, age) => {
  ciRows.push(`('CI25_Male', ${age}, ${qx.toFixed(10)})`);
});
CI_AGG.female.forEach((qx, age) => {
  ciRows.push(`('CI25_Female', ${age}, ${qx.toFixed(10)})`);
});

lines.push('INSERT INTO actuarial_ci_table (table_name, age, qx) VALUES');
lines.push(ciRows.map((r, i) => (i < ciRows.length - 1 ? `  ${r},` : `  ${r}`)).join('\n'));
lines.push(';');
lines.push('');

// ── 验证查询（可选） ───────────────────────────────────────────────────────────
lines.push('-- ========== 导入验证（执行后检查行数）==========');
lines.push("SELECT 'actuarial_qx_table' AS tbl, COUNT(*) AS rows FROM actuarial_qx_table");
lines.push("UNION ALL");
lines.push("SELECT 'actuarial_ci_table', COUNT(*) FROM actuarial_ci_table;");
lines.push('');
lines.push("-- 预期结果：actuarial_qx_table = 212 行，actuarial_ci_table = 212 行");
lines.push('');
lines.push('-- ========== 导入完成 ==========');

// ── 写出 SQL 文件 ─────────────────────────────────────────────────────────────
const outFile = path.join(__dirname, '../db/migration/07-actuarial-data.sql');
fs.writeFileSync(outFile, lines.join('\n'), 'utf8');

const totalRows = qxRows.length + ciRows.length;
console.log(`✓ 已生成：db/migration/07-actuarial-data.sql`);
console.log(`  actuarial_qx_table：${qxRows.length} 行`);
console.log(`  actuarial_ci_table：${ciRows.length} 行`);
console.log(`  合计：${totalRows} 行`);
